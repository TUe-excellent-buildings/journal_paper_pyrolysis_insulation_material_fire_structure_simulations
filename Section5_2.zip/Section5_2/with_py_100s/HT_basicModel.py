###########################################################################
## Name:        HT_basicModel.py 									 	 ##
##																		 ##
## Description: Basic Heat Transfer (HT) Model for a self supporting     ##
## 				sandwich panel facade system, including main structure,  ##
##				framework and connections. This model can be used in 	 ##
##				a two-way coupled thermo-mechanical CFD-FEM Analysis.	 ##
##						 												 ##
## Additional	This script is INCOMPLETE additional python code is      ##
## Info:		appended by geometric update program upGeomHT based on   ##
##				the current iteration in the coupling analysis.          ##
##				The complete coupling procedure is managed by 			 ##
## 				Master Program FDS-2-Abaqus.							 ##
## 																		 ##
## Input :		AST_Amp_Data.py											 ##
##				(code running this script is appende by upGeomHT)        ##
##																		 ##
## Output:      Requires a \\_outputHT\\ folder to store *.odb output    ##
##																		 ##
###########################################################################
## Version 3.0                                       by Qingfeng Xu      ##
## MARCH 2022                                   xqf0620@outlook.com      ##
###########################################################################

############################## Begin Script ###############################
# -*- coding: mbcs -*-
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
### use this line when launching script from Abaqus CEA (direct path)
# specify output directory (exclude '_outputHT' folder)
#currentPath = 'C:\\' 
## Change Working Directory ##
# don't forget to create a '_outputHT' folder in output directory
os.chdir(currentPath + '\\_outputHT\\') 
## Name Model ##
mod = mdb.models['Model-1']
modRa = mod.rootAssembly
## Specify-Attributes ##
mod.setValues(absoluteZero=-273.15, stefanBoltzmann=5.67e-08)	
### CREATE PARTS ###
## Insulation ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
    point2=(0.9, 0.08))
mod.Part(dimensionality=THREE_D, name='Insulation', type=
    DEFORMABLE_BODY)
mod.parts['Insulation'].BaseSolidExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Inner plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.9, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.45, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.45, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Inner_plate', type=
    DEFORMABLE_BODY)
mod.parts['Inner_plate'].BaseShellExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Outer plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.9, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.45, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.45, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Outer_plate', type=
    DEFORMABLE_BODY)
mod.parts['Outer_plate'].BaseShellExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Steel column ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(-0.1, 0.0), point2=(
    0.1, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0), 
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.0, 0.19))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.095))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.095), 
    ))
mod.sketches['__profile__'].Line(point1=(-0.1, 0.19), point2=
    (0.1, 0.19))
mod.sketches['__profile__'].geometry.findAt((-0.09, 0.19))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((-0.09, 
    0.19), ))
mod.Part(dimensionality=THREE_D, name='HEA_200', type=
    DEFORMABLE_BODY)
mod.parts['HEA_200'].BaseShellExtrude(depth=2.71, sketch=
    mod.sketches['__profile__'])
## Frame ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.15), point2=(
    0.0, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075), 
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.15, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.075, 0.0), 
    ))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075), 
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.075, 0.0), ))
mod.Part(dimensionality=THREE_D, name='Frame', type=
    DEFORMABLE_BODY)
mod.parts['Frame'].BaseShellExtrude(depth=2.71, sketch=
    mod.sketches['__profile__'])
## Connection plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.1, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.05, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.05, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Welded_plate', type=
    DEFORMABLE_BODY)
mod.parts['Welded_plate'].BaseShellExtrude(depth=0.15, 
    sketch=mod.sketches['__profile__'])
### CREATE MATERIAL PROPERTIES ###
## Steel properties ## including temperature dependant properties ##
mod.Material(name='Steel_S355')
mod.materials['Steel_S355'].Elastic(table=((
    210000000000.0, 0.3, 20.0), (210000000000.0, 0.3, 100.0), (189000000000.0,
    0.3, 200.0), (168000000000.0, 0.3, 300.0), (147000000000.0, 0.3, 400.0), (
    126000000000.0, 0.3, 500.0), (65100000000.0, 0.3, 600.0), (27300000000.0,
    0.3, 700.0), (18900000000.0, 0.3, 800.0), (14175000000.0, 0.3, 900.0), (
    9450000000.0, 0.3, 1000.0), (4725000000.0, 0.3, 1100.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Density(table=((7850.0, ), ))
mod.materials['Steel_S355'].Expansion(table=((1.51e-05, 20.0), (
    1.51e-05, 750.0), (1.31e-05, 760.0), (1.31e-05, 860.0), (1.51e-05, 870.0), 
    (1.51e-05, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].SpecificHeat(table=((440.0, 20.0), (
    760.0, 600.0), (5000.0, 735.0), (650.4, 900.0), (650.0, 1200.0)), 
    temperatureDependency=ON)
mod.materials['Steel_S355'].Conductivity(table=((53.3, 20.0), (
    27.4, 800.0), (27.3, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Plastic(table=((355599612.4,
    0.0, 20.0), (357218145.0, 0.004566937, 20.0), (358829331.8, 0.009113111,
    20.0), (360433239.2, 0.013638711, 20.0), (362029932.7, 0.018143923, 20.0),
    (404615489.5, 0.138290882, 20.0), (355599612.4, 0.0, 100.0), (357218145.0,
    0.004566937, 100.0), (358829331.8, 0.009113111, 100.0), (360433239.2,
    0.013638711, 100.0), (362029932.7, 0.018143923, 100.0), (404615489.5,
    0.138290882, 100.0), (286875560.6, 0.0, 200.0), (333319059.6, 0.004610407,
    200.0), (349284030.0, 0.009199656, 200.0), (358112290.5, 0.01376794,
    200.0), (361977173.2, 0.01831545, 200.0), (404568694.6, 0.138442992,
    200.0), (217840389.4, 0.0, 300.0), (308131318.1, 0.004665269, 300.0), (
    339225541.8, 0.009308874, 300.0), (355678058.7, 0.013931016, 300.0), (
    361939756.3, 0.018531891, 300.0), (404535508.1, 0.138634936, 300.0), (
    149205823.4, 0.0, 400.0), (281382163.9, 0.0047352, 400.0), (328533487.9,
    0.009448083, 400.0), (353104758.7, 0.014138859, 400.0), (361924013.5,
    0.018807735, 400.0), (404521545.4, 0.138879566, 400.0), (99731307.34, 0.0,
    500.0), (213381375.5, 0.00479072, 500.0), (253814286.9, 0.009558599,
    500.0), (274829284.2, 0.014303853, 500.0), (282297425.4, 0.019026696,
    500.0), (315523874.0, 0.139073755, 500.0), (30037294.84, 0.0, 600.0), (
    115714763.5, 0.004872775, 600.0), (147777119.4, 0.00972192, 600.0), (
    164362320.5, 0.014547665, 600.0), (170101989.6, 0.019350234, 600.0), (
    190123089.3, 0.1393607, 600.0), (6123928.57, 0.0, 700.0), (52377488.91,
    0.004931741, 700.0), (70599467.17, 0.009839279, 700.0), (80026210.08,
    0.01472285, 700.0), (83251261.26, 0.019582688, 700.0), (93047705.59,
    0.139566868, 700.0), (1952518.154, 0.0, 800.0), (25283029.45, 0.004961843,
    800.0), (33873342.85, 0.009899188, 800.0), (38302736.71, 0.014812274,
    800.0), (39819693.35, 0.019701341, 800.0), (44504511.49, 0.139672106,
    800.0), (798753.0381, 0.0, 900.0), (13896838.39, 0.004973524, 900.0), (
    18522040.26, 0.009922435, 900.0), (20904066.71, 0.014846974, 900.0), (
    21720698.66, 0.019747381, 900.0), (24275956.11, 0.139712942, 900.0), (
    355000.6001, 0.0, 1000.0), (9194998.354, 0.004978197, 1000.0), (
    12320356.23, 0.009931734, 1000.0), (13929587.95, 0.014860854, 1000.0), (
    14480697.85, 0.019765797, 1000.0), (16184176.59, 0.139729276, 1000.0), (
    88750.03751, 0.0, 1100.0), (4562665.473, 0.004982869, 1100.0), (
    6146323.829, 0.009941032, 1100.0), (6961565.569, 0.014874733, 1100.0), (
    7240470.85, 0.019784212, 1100.0), (8092196.434, 0.139745609, 1100.0)),
    temperatureDependency=ON)
## Insulation properties ##
mod.Material(name='Insulation')
modMatIns = mod.materials['Insulation']
modMatIns.Density(dependencies=1, table=((1.0, 0.0), (1.0, 1.0)))
modMatIns.Depvar(n=1)
modMatIns.UserDefinedField()
modMatIns.UserMaterial(thermalConstants=(1.0, ), type=THERMAL)
### CREATE & ASSIGN SECTION ###
## Inner plate ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Inner_steel_plate', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.0004, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['Inner_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 
    2.4), (0.0, -1.0, 0.0)), )), sectionName='Inner_steel_plate', 
    thicknessAssignment=FROM_SECTION)
## Outer plate ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Outer_steel_plate', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.0005, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['Outer_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Outer_plate'].faces.findAt(((0.6, 0.0, 
    2.4), (0.0, -1.0, 0.0)), )), sectionName='Outer_steel_plate', 
    thicknessAssignment=FROM_SECTION)
## Insulation ##
mod.HomogeneousSolidSection(material='Insulation', name=
    'Insulation', thickness=None)
mod.parts['Insulation'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Insulation'].cells.findAt(((0.9, 
    0.053333, 2.4), ), )), sectionName='Insulation', thicknessAssignment=
    FROM_SECTION)
## Column ##
# Web # 
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='HEA_200_web', numIntPts=5, 
    poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=GRADIENT, 
    thickness=0.0065, thicknessField='', thicknessModulus=None, thicknessType=
    UNIFORM, useDensity=OFF)
mod.parts['HEA_200'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['HEA_200'].faces.findAt(((0.0, 0.126667, 
    1.806667), (1.0, 0.0, 0.0)), )), sectionName='HEA_200_web', 
    thicknessAssignment=FROM_SECTION)
# Flench #
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='HEA_200_flench', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.01, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['HEA_200'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['HEA_200'].faces.findAt(((0.033333, 0.0, 
    0.903333), (0.0, -1.0, 0.0)), ((-0.033333, 0.0, 1.806667), (0.0, -1.0, 
    0.0)), ((-0.033333, 0.19, 1.806667), (0.0, -1.0, 0.0)), ((0.033333, 0.19, 
    0.903333), (0.0, -1.0, 0.0)), )), sectionName='HEA_200_flench', 
    thicknessAssignment=FROM_SECTION)
mod.parts['Welded_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Welded_plate'].faces.findAt(((0.066667, 
    0.0, 0.1), (0.0, -1.0, 0.0)), )), sectionName='HEA_200_flench', 
    thicknessAssignment=FROM_SECTION)
## Frame ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Steel_frame', numIntPts=5, 
    poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=GRADIENT, 
    thickness=0.003, thicknessField='', thicknessModulus=None, thicknessType=
    UNIFORM, useDensity=OFF)
mod.parts['Frame'].SectionAssignment(offset=0.0, offsetField=
    '', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Frame'].faces.findAt(((0.1, 0.0, 
    1.806667), (0.0, -1.0, 0.0)), ((0.0, 0.05, 1.806667), (-1.0, 0.0, 0.0)), ))
    , sectionName='Steel_frame', thicknessAssignment=FROM_SECTION)
### CREATE SURFACES ###
## Temperature at plates ##
mod.parts['Outer_plate'].Surface(name='Outer_side', 
    side1Faces=mod.parts['Outer_plate'].faces.findAt(((0.6, 
    0.0, 2.4), )))
### CREATE PARTITIONS ###
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 0.9), ), 
    point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 0.9), ), 
    MIDDLE))
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 2.25), )
    , point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 2.25), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 0.45), )
    , point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 0.45), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 0.9), ), 
    point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 0.9), ), 
    MIDDLE))
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 2.25), )
    , point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 2.25), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionEdgeByPoint(edge=
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 0.45), )
    , point=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 0.45), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), point1=mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.675, 0.0, 3.6), 
    ), MIDDLE), point2=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.225, 0.0, 0.0), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 0.3), 
    ), ((0.15, 0.0, 3.3), ), ), point1=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 2.925), 
    ), MIDDLE), point2=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 2.925), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 3.0), 
    ), ((0.15, 0.0, 3.0), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((0.0, 0.0, 2.7), 
    ), point2=mod.parts['Inner_plate'].vertices.findAt((0.9, 
    0.0, 2.7), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 2.4), 
    ), ((0.15, 0.0, 2.4), ), ), point1=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 2.025), 
    ), MIDDLE), point2=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 2.025), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 2.1), 
    ), ((0.15, 0.0, 2.1), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((0.0, 0.0, 1.8), 
    ), point2=mod.parts['Inner_plate'].vertices.findAt((0.9, 
    0.0, 1.8), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 1.5), 
    ), ((0.15, 0.0, 1.5), ), ), point1=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 1.125), 
    ), MIDDLE), point2=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 1.125), 
    ), MIDDLE))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 1.2), 
    ), ((0.15, 0.0, 1.2), ), ), point1=
    mod.parts['Inner_plate'].vertices.findAt((0.0, 0.0, 0.9), 
    ), point2=mod.parts['Inner_plate'].vertices.findAt((0.9, 
    0.0, 0.9), ))
mod.parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 0.6), 
    ), ((0.3, 0.0, 0.6), ), ), point1=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.0, 0.0, 0.225), 
    ), MIDDLE), point2=
    mod.parts['Inner_plate'].InterestingPoint(
    mod.parts['Inner_plate'].edges.findAt((0.9, 0.0, 0.225), 
    ), MIDDLE))
mod.parts['Inner_plate'].Surface(name='Surf-1', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 3.3), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-2', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 2.85), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-3', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 2.4), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-4', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 1.95), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-5', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 1.5), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-6', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 1.05), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-7', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 0.6), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-8', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.3, 0.0, 0.3), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-9', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 3.3), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-10', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.85), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-11', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-12', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 1.95), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-13', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 1.5), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-14', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 1.05), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-15', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 0.6), 
    )))
mod.parts['Inner_plate'].Surface(name='Surf-16', side1Faces=
    mod.parts['Inner_plate'].faces.findAt(((0.75, 0.0, 0.3), 
    )))
mod.parts['Inner_plate'].Surface(name='_frame', 
    side1Faces=mod.parts['Inner_plate'].faces.findAt(((0.15, 
    0.0, 0.6), ), ((0.6, 0.0, 0.6), ), ((0.15, 0.0, 1.05), ), ((0.6, 0.0, 
    1.05), ), ((0.15, 0.0, 1.5), ), ((0.6, 0.0, 1.5), ), ((0.15, 0.0, 1.95), ), 
    ((0.6, 0.0, 1.95), ), ((0.15, 0.0, 2.4), ), ((0.6, 0.0, 2.4), ), ((0.15, 
    0.0, 2.85), ), ((0.6, 0.0, 2.85), ), ((0.15, 0.0, 3.3), ), ((0.6, 0.0, 
    3.3), ), ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ))
mod.parts['Inner_plate'].Surface(name='_insulation', 
    side2Faces=mod.parts['Inner_plate'].faces.findAt(((0.15, 
    0.0, 0.6), ), ((0.6, 0.0, 0.6), ), ((0.15, 0.0, 1.05), ), ((0.6, 0.0, 
    1.05), ), ((0.15, 0.0, 1.5), ), ((0.6, 0.0, 1.5), ), ((0.15, 0.0, 1.95), ), 
    ((0.6, 0.0, 1.95), ), ((0.15, 0.0, 2.4), ), ((0.6, 0.0, 2.4), ), ((0.15, 
    0.0, 2.85), ), ((0.6, 0.0, 2.85), ), ((0.15, 0.0, 3.3), ), ((0.6, 0.0, 
    3.3), ), ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ))
### ASSEMBLY FACADE ###
## Create Kingspan panel ##
# Create instances # inner plate, outer plate, insulation #
modRa.DatumCsysByDefault(CARTESIAN)
modRa.Instance(dependent=ON, name='Inner_plate-1', 
    part=mod.parts['Inner_plate'])
modRa.Instance(dependent=ON, name='Insulation-1', 
    part=mod.parts['Insulation'])
modRa.Instance(dependent=ON, name='Outer_plate-1', 
    part=mod.parts['Outer_plate'])
modRa.instances['Insulation-1'].translate(vector=(
    0.99, 0.0, 0.0))
modRa.instances['Outer_plate-1'].translate(vector=
    (1.98002, 0.0, 0.0))
# Built panel #
modRa.translate(instanceList=('Insulation-1', ), 
    vector=(-0.99, 0.0, 0.0))
modRa.translate(instanceList=('Outer_plate-1', ), 
    vector=(-1.98002, 0.08, 0.0))
## Duplicate panel ##
modRa.LinearInstancePattern(direction1=(1.0, 0.0, 
    0.0), direction2=(0.0, 1.0, 0.0), instanceList=('Inner_plate-1', 
    'Insulation-1', 'Outer_plate-1'), number1=3, number2=1, spacing1=0.905, 
    spacing2=0.0802)
## Rename instances ##
modRa.features.changeKey(fromName=
    'Inner_plate-1-lin-2-1', toName='Inner_plate-2')
modRa.features.changeKey(fromName=
    'Inner_plate-1-lin-3-1', toName='Inner_plate-3')
modRa.features.changeKey(fromName=
    'Insulation-1-lin-2-1', toName='Insulation-2')
modRa.features.changeKey(fromName=
    'Insulation-1-lin-3-1', toName='Insulation-3')
modRa.features.changeKey(fromName=
    'Outer_plate-1-lin-2-1', toName='Outer_plate-2')
modRa.features.changeKey(fromName=
    'Outer_plate-1-lin-3-1', toName='Outer_plate-3')
## Create steel frame ##
# Create instance # frame #
modRa.Instance(dependent=ON, name='Frame-1', part=
    mod.parts['Frame'])
modRa.instances['Frame-1'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15, 
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-1', ))
modRa.rotate(angle=180.0, axisDirection=(2.71, 
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-1', ))
modRa.translate(instanceList=('Frame-1', ), 
    vector=(-2.7252, -0.3, 0.0))
# Create instance # frame #
modRa.Instance(dependent=ON, name='Frame-2', part=
    mod.parts['Frame'])
modRa.instances['Frame-2'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15, 
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-2', ))
modRa.rotate(angle=180.0, axisDirection=(2.71, 
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-2', ))
modRa.translate(instanceList=('Frame-2', ), 
    vector=(-2.7252, -0.3, 3.45))
# Create instance # column #
modRa.Instance(dependent=ON, name='HEA_200-1', 
    part=mod.parts['HEA_200'])
modRa.instances['HEA_200-1'].translate(vector=(
    2.8302, 0.0, 0.0))
# Positioning column #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.19, 
    0.0), axisPoint=(2.8302, 0.0, 2.71), instanceList=('HEA_200-1', ))
modRa.translate(instanceList=('HEA_200-1', ), 
    vector=(-0.1202, -0.34, -2.71))
# Create instance # connection plate #
modRa.Instance(dependent=ON, name='Welded_plate-1'
    , part=mod.parts['Welded_plate'])
modRa.instances['Welded_plate-1'].translate(
    vector=(2.7202, 0.0, 0.0))
# Positioning connection plate #
modRa.rotate(angle=90.0, axisDirection=(0.1, 0.0, 
    0.0), axisPoint=(2.7202, 0.0, 0.0), instanceList=('Welded_plate-1', ))
modRa.translate(instanceList=('Welded_plate-1', ), 
    vector=(-0.1102, 0.0, 0.0))
modRa.translate(instanceList=('Welded_plate-1', ), 
    vector=(-0.2, 0.0, 0.0))
# Create instance # connection plate #
modRa.Instance(dependent=ON, name='Welded_plate-2'
    , part=mod.parts['Welded_plate'])
modRa.instances['Welded_plate-2'].translate(
    vector=(2.7202, 0.0, 0.0))
# Positioning connection plate #
modRa.rotate(angle=90.0, axisDirection=(-0.05, 
    0.0, 0.0), axisPoint=(2.8202, 0.0, 0.0), instanceList=('Welded_plate-2', ))
modRa.translate(instanceList=('Welded_plate-2', ), 
    vector=(-2.7202, -0.15, 0.0))
modRa.translate(instanceList=('Welded_plate-2', ), 
    vector=(0.2, 0.0, 0.0))
# Merge column & conection plates # create part #
modRa.InstanceFromBooleanMerge(domain=GEOMETRY, 
    instances=(modRa.instances['Welded_plate-2'], 
    modRa.instances['HEA_200-1'], 
    modRa.instances['Welded_plate-1']), name=
    'HEA_incl_connection', originalInstances=SUPPRESS)
# Create instance # Column including connection plates #
modRa.Instance(dependent=ON, name=
    'HEA_incl_connection-2', part=
    mod.parts['HEA_incl_connection'])
modRa.instances['HEA_incl_connection-2'].translate(
    vector=(2.9812, 0.0, 0.0))
# Positioning column including connection plates #
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(-2.9812, 0.0, 3.45))
### CREATE MESH ###
## Column including connection plate ##
mod.parts['HEA_incl_connection'].seedEdgeByNumber(constraint=
    FINER, edges=
    mod.parts['HEA_incl_connection'].edges.findAt(((2.41, 
    -0.0375, 0.0), ), ((2.51, -0.0375, 0.0), ), ((0.2, -0.1125, 0.0), ), ((0.3, 
    -0.1125, 0.0), ), ), number=3)
mod.parts['HEA_incl_connection'].seedEdgeByNumber(constraint=
    FINER, edges=
    mod.parts['HEA_incl_connection'].edges.findAt(((2.435, 
    0.0, 0.0), ), ((0.275, 0.0, 0.0), ), ), number=2)
mod.parts['HEA_incl_connection'].seedPart(deviationFactor=0.1
    , minSizeFactor=0.1, size=0.05)
mod.parts['HEA_incl_connection'].setElementType(elemTypes=(
    ElemType(elemCode=DS8, elemLibrary=STANDARD), ElemType(elemCode=DS6, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['HEA_incl_connection'].faces.findAt(((2.476667, 
    -0.1, 0.0), ), ((0.903333, -0.34, -0.033333), ), ((1.806667, -0.34, 
    0.033333), ), ((2.643333, -0.213333, 0.0), ), ((2.643333, -0.15, 0.033333), 
    ), ((2.643333, -0.15, -0.033333), ), ((0.266667, -0.05, 0.0), ), ), ))
mod.parts['HEA_incl_connection'].generateMesh()
## Frame ##
mod.parts['Frame'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['Frame'].setElementType(elemTypes=(ElemType(
    elemCode=DS8, elemLibrary=STANDARD), ElemType(elemCode=DS6, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Frame'].faces.findAt(((0.1, 0.0, 1.806667), ), 
    ((0.0, 0.05, 1.806667), ), ), ))
mod.parts['Frame'].generateMesh()
## Inner plate ##
mod.parts['Inner_plate'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['Inner_plate'].setElementType(elemTypes=(ElemType(
    elemCode=DS8, elemLibrary=STANDARD), ElemType(elemCode=DS6, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), ))
mod.parts['Inner_plate'].setElementType(elemTypes=(ElemType(
    elemCode=DS8, elemLibrary=STANDARD), ElemType(elemCode=DS6, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Inner_plate'].faces.findAt(((0.15, 0.0, 0.6), 
    ), ((0.6, 0.0, 0.6), ), ((0.15, 0.0, 1.05), ), ((0.6, 0.0, 1.05), ), ((
    0.15, 0.0, 1.5), ), ((0.6, 0.0, 1.5), ), ((0.15, 0.0, 1.95), ), ((0.6, 0.0, 
    1.95), ), ((0.15, 0.0, 2.4), ), ((0.6, 0.0, 2.4), ), ((0.15, 0.0, 2.85), ), 
    ((0.6, 0.0, 2.85), ), ((0.15, 0.0, 3.3), ), ((0.6, 0.0, 3.3), ), ((0.75, 
    0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ), ))
mod.parts['Inner_plate'].generateMesh()
## Insulation ##
mod.parts['Insulation'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['Insulation'].seedEdgeByNumber(constraint=FINER, 
    edges=mod.parts['Insulation'].edges.findAt(((0.0, 0.02, 
    3.6), ), ((0.0, 0.02, 0.0), ), ((0.9, 0.06, 3.6), ), ((0.9, 0.06, 0.0), ), 
    ), number=4)
mod.parts['Insulation'].setElementType(elemTypes=(ElemType(
    elemCode=DC3D8, elemLibrary=STANDARD), ElemType(elemCode=DC3D6,
    elemLibrary=STANDARD), ElemType(elemCode=DC3D4, elemLibrary=STANDARD)),
    regions=(mdb.models['Model-1'].parts['Insulation'].cells.findAt(((0.9,
    0.053333, 2.4), )), ))
mod.parts['Insulation'].generateMesh()
## Outer plate ##
mod.parts['Outer_plate'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.1)
mod.parts['Outer_plate'].setElementType(elemTypes=(ElemType(
    elemCode=DS8, elemLibrary=STANDARD), ElemType(elemCode=DS6, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Outer_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), ))
mod.parts['Outer_plate'].generateMesh()
### CREATE CONVECTION BETWEEN SURFACES ###
mod.ContactProperty('Conductance')
mod.interactionProperties['Conductance'].ThermalConductance(
    clearanceDepTable=((100000.0, 0.0), (0.0, 0.015)), clearanceDependency=ON, 
    definition=TABULAR, dependenciesC=0, massFlowRateDependencyC=OFF, 
    pressureDependency=OFF, temperatureDependencyC=OFF)
modRa.Surface(name='CP-1-Insulation-1', 
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (0.6, 0.0, 2.4), )))
modRa.Surface(name='CP-1-Inner_plate-1', 
    side2Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.6, 0.0, 2.4), )))
modRa.Surface(name='CP-2-Frame-1', side2Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, 0.0, 0.1), )))
modRa.Surface(name='CP-2-Inner_plate-1', 
    side2Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.6, 0.0, 2.4), )))
modRa.Surface(name='CP-3-Frame-2', side2Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, 0.0, 3.55), )))
modRa.Surface(name='CP-3-Inner_plate-1', 
    side2Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.6, 0.0, 2.4), )))
modRa.Surface(name='CP-4-Insulation-1', 
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (0.3, 0.08, 2.4), )))
modRa.Surface(name='CP-4-Outer_plate-1', 
    side1Faces=
    modRa.instances['Outer_plate-1'].faces.findAt(
    ((0.6, 0.08, 2.4), )))
modRa.Surface(name='CP-5-Insulation-1', 
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (0.9, 0.053333, 2.4), )))
modRa.Surface(name='CP-5-Insulation-2', 
    side1Faces=
    modRa.instances['Insulation-2'].faces.findAt((
    (0.905, 0.026667, 2.4), )))
modRa.Surface(name='CP-6-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, 0.0, 0.1), )))
modRa.Surface(name='CP-6-Insulation-1', 
    side1Faces=
    modRa.instances['Insulation-1'].faces.findAt((
    (0.6, 0.0, 2.4), )))
modRa.Surface(name='CP-10-Insulation-2', 
    side1Faces=
    modRa.instances['Insulation-2'].faces.findAt((
    (1.505, 0.0, 2.4), )))
modRa.Surface(name='CP-10-Inner_plate-2', 
    side2Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.505, 0.0, 2.4), )))
modRa.Surface(name='CP-11-Frame-1', side2Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, 0.0, 0.1), )))
modRa.Surface(name='CP-11-Inner_plate-2', 
    side2Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.505, 0.0, 2.4), )))
modRa.Surface(name='CP-12-Frame-2', side2Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, 0.0, 3.55), )))
modRa.Surface(name='CP-12-Inner_plate-2', 
    side2Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.505, 0.0, 2.4), )))
modRa.Surface(name='CP-13-Insulation-3', 
    side1Faces=
    modRa.instances['Insulation-3'].faces.findAt((
    (2.41, 0.0, 2.4), )))
modRa.Surface(name='CP-13-Inner_plate-3', 
    side2Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((2.41, 0.0, 2.4), )))
modRa.Surface(name='CP-14-Frame-1', side2Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, 0.0, 0.1), )))
modRa.Surface(name='CP-14-Inner_plate-3', 
    side2Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((2.41, 0.0, 2.4), )))
modRa.Surface(name='CP-15-Frame-2', side2Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, 0.0, 3.55), )))
modRa.Surface(name='CP-15-Inner_plate-3', 
    side2Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((2.41, 0.0, 2.4), )))
modRa.Surface(name='CP-16-Insulation-2', 
    side1Faces=
    modRa.instances['Insulation-2'].faces.findAt((
    (1.805, 0.053333, 2.4), )))
modRa.Surface(name='CP-16-Insulation-3', 
    side1Faces=
    modRa.instances['Insulation-3'].faces.findAt((
    (1.81, 0.026667, 2.4), )))
modRa.Surface(name='CP-17-Insulation-2', 
    side1Faces=
    modRa.instances['Insulation-2'].faces.findAt((
    (1.205, 0.08, 2.4), )))
modRa.Surface(name='CP-17-Outer_plate-2', 
    side1Faces=
    modRa.instances['Outer_plate-2'].faces.findAt(
    ((1.505, 0.08, 2.4), )))
modRa.Surface(name='CP-21-Insulation-3', 
    side1Faces=
    modRa.instances['Insulation-3'].faces.findAt((
    (2.11, 0.08, 2.4), )))
modRa.Surface(name='CP-21-Outer_plate-3', 
    side1Faces=
    modRa.instances['Outer_plate-3'].faces.findAt(
    ((2.41, 0.08, 2.4), )))
modRa.Surface(name='CP-26-Frame-1', side2Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.05, 0.0), )))
modRa.Surface(name='CP-26-HEA_incl_connection-1', 
    side2Faces=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    ((2.476667, -0.1, 0.0), ), ((2.643333, -0.213333, 0.0), ), ((0.266667, 
    -0.05, 0.0), ), ))
modRa.Surface(name='CP-27-Frame-2', side2Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.05, 3.45), )))
modRa.Surface(name='CP-27-HEA_incl_connection-2', 
    side1Faces=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    ((2.476667, -0.1, 3.45), ), ((2.643333, -0.213333, 3.45), ), ((0.266667, 
    -0.05, 3.45), ), ))
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-1-Insulation-1'], name=
    'CP-1-Insulation-1-Inner_plate-1', slave=
    modRa.surfaces['CP-1-Inner_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-2-Frame-1'], name=
    'CP-2-Frame-1-Inner_plate-1', slave=
    modRa.surfaces['CP-2-Inner_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-3-Frame-2'], name=
    'CP-3-Frame-2-Inner_plate-1', slave=
    modRa.surfaces['CP-3-Inner_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-4-Insulation-1'], name=
    'CP-4-Insulation-1-Outer_plate-1', slave=
    modRa.surfaces['CP-4-Outer_plate-1'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-5-Insulation-1'], name=
    'CP-5-Insulation-1-Insulation-2', slave=
    modRa.surfaces['CP-5-Insulation-2'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-10-Insulation-2'], name=
    'CP-10-Insulation-2-Inner_plate-2', slave=
    modRa.surfaces['CP-10-Inner_plate-2'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-11-Frame-1'], name=
    'CP-11-Frame-1-Inner_plate-2', slave=
    modRa.surfaces['CP-11-Inner_plate-2'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-12-Frame-2'], name=
    'CP-12-Frame-2-Inner_plate-2', slave=
    modRa.surfaces['CP-12-Inner_plate-2'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-13-Insulation-3'], name=
    'CP-13-Insulation-3-Inner_plate-3', slave=
    modRa.surfaces['CP-13-Inner_plate-3'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-14-Frame-1'], name=
    'CP-14-Frame-1-Inner_plate-3', slave=
    modRa.surfaces['CP-14-Inner_plate-3'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-15-Frame-2'], name=
    'CP-15-Frame-2-Inner_plate-3', slave=
    modRa.surfaces['CP-15-Inner_plate-3'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-16-Insulation-2'], name=
    'CP-16-Insulation-2-Insulation-3', slave=
    modRa.surfaces['CP-16-Insulation-3'], sliding=
    FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-17-Insulation-2'], name=
    'CP-17-Insulation-2-Outer_plate-2', slave=
    modRa.surfaces['CP-17-Outer_plate-2'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-21-Insulation-3'], name=
    'CP-21-Insulation-3-Outer_plate-3', slave=
    modRa.surfaces['CP-21-Outer_plate-3'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-26-Frame-1'], name=
    'CP-26-Frame-1-HEA_incl_connection-1', slave=
    modRa.surfaces['CP-26-HEA_incl_connection-1'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
mod.SurfaceToSurfaceContactStd(adjustMethod=OVERCLOSED, 
    createStepName='Initial', enforcement=SURFACE_TO_SURFACE, 
    interactionProperty='Conductance', master=
    modRa.surfaces['CP-27-Frame-2'], name=
    'CP-27-Frame-2-HEA_incl_connection-2', slave=
    modRa.surfaces['CP-27-HEA_incl_connection-2'], 
    sliding=FINITE, surfaceSmoothing=AUTOMATIC)
### POSITIONING STRUCTURE ###
modRa.translate(instanceList=(
    'HEA_incl_connection-1', ), vector=(0.0, -0.0072, -0.0065))
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(0.0, -0.0072, -0.0065))
modRa.translate(instanceList=(
    'Frame-1', ), vector=(0.0, -0.0017, 0.0))
modRa.translate(instanceList=(
    'Frame-2', ), vector=(0.0, -0.0017, 0.0))	
modRa.translate(instanceList=(
    'Insulation-1', ), vector=(0.0, 0.00045, 0.0))
modRa.translate(instanceList=(
    'Insulation-2', ), vector=(0.0, 0.00045, 0.0))
modRa.translate(instanceList=(
    'Insulation-3', ), vector=(0.0, 0.00045, 0.0))	
modRa.translate(instanceList=(
    'Outer_plate-1', ), vector=(0.0, 0.00045, 0.0))
modRa.regenerate()
### POSITIONING STRUCTURE ###
modRa.translate(instanceList=(
    'HEA_incl_connection-1', ), vector=(0.0, 0.0, -0.0005))
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(0.0, 0.0, -0.0005))
modRa.translate(instanceList=(
    'Frame-1', ), vector=(0.0, -0.0005, 0.0))
modRa.translate(instanceList=(
    'Frame-2', ), vector=(0.0, -0.0005, 0.0))	
modRa.regenerate()
### Conductance ###	
modRa.Surface(name='CP-1-Inner_plate-1', 
    side2Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.15, 0.0, 0.6), ), ((0.6, 0.0, 0.6), ), ((0.15, 0.0, 1.05), ), ((0.6, 
    0.0, 1.05), ), ((0.15, 0.0, 1.5), ), ((0.6, 0.0, 1.5), ), ((0.15, 0.0, 
    1.95), ), ((0.6, 0.0, 1.95), ), ((0.15, 0.0, 2.4), ), ((0.6, 0.0, 2.4), ), 
    ((0.15, 0.0, 2.85), ), ((0.6, 0.0, 2.85), ), ((0.15, 0.0, 3.3), ), ((0.6, 
    0.0, 3.3), ), ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ))
modRa.Surface(name='CP-2-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0022, 0.1), )))
modRa.Surface(name='CP-2-Inner_plate-1', 
    side1Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.75, 0.0, 0.3), ), ((0.3, 0.0, 0.3), ), ))
modRa.Surface(name='CP-3-Frame-2', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0022, 3.55), )))
modRa.Surface(name='CP-3-Inner_plate-1', 
    side1Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.15, 0.0, 3.3), ), ((0.6, 0.0, 3.3), ), ))
modRa.Surface(name='CP-10-Inner_plate-2', 
    side2Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.055, 0.0, 0.6), ), ((1.505, 0.0, 0.6), ), ((1.055, 0.0, 1.05), ), ((
    1.505, 0.0, 1.05), ), ((1.055, 0.0, 1.5), ), ((1.505, 0.0, 1.5), ), ((
    1.055, 0.0, 1.95), ), ((1.505, 0.0, 1.95), ), ((1.055, 0.0, 2.4), ), ((
    1.505, 0.0, 2.4), ), ((1.055, 0.0, 2.85), ), ((1.505, 0.0, 2.85), ), ((
    1.055, 0.0, 3.3), ), ((1.505, 0.0, 3.3), ), ((1.655, 0.0, 0.3), ), ((1.205, 
    0.0, 0.3), ), ))
modRa.Surface(name='CP-11-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0022, 0.1), )))
modRa.Surface(name='CP-11-Inner_plate-2', 
    side1Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.655, 0.0, 0.3), ), ((1.205, 0.0, 0.3), ), ))
modRa.Surface(name='CP-12-Frame-2', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0022, 3.55), )))
modRa.Surface(name='CP-12-Inner_plate-2', 
    side2Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.055, 0.0, 3.3), ), ((1.505, 0.0, 3.3), ), ))
modRa.Surface(name='CP-12-Inner_plate-2', 
    side1Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.055, 0.0, 3.3), ), ((1.505, 0.0, 3.3), ), ))
modRa.Surface(name='CP-13-Inner_plate-3', 
    side2Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((1.96, 0.0, 0.6), ), ((2.41, 0.0, 0.6), ), ((1.96, 0.0, 1.05), ), ((2.41, 
    0.0, 1.05), ), ((1.96, 0.0, 1.5), ), ((2.41, 0.0, 1.5), ), ((1.96, 0.0, 
    1.95), ), ((2.41, 0.0, 1.95), ), ((1.96, 0.0, 2.4), ), ((2.41, 0.0, 2.4), 
    ), ((1.96, 0.0, 2.85), ), ((2.41, 0.0, 2.85), ), ((1.96, 0.0, 3.3), ), ((
    2.41, 0.0, 3.3), ), ((2.56, 0.0, 0.3), ), ((2.11, 0.0, 0.3), ), ))
modRa.Surface(name='CP-14-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0022, 0.1), )))
modRa.Surface(name='CP-14-Inner_plate-3', 
    side1Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((2.56, 0.0, 0.3), ), ((2.11, 0.0, 0.3), ), ))
modRa.Surface(name='CP-15-Frame-2', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0022, 3.55), )))
modRa.Surface(name='CP-15-Inner_plate-3', 
    side1Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((1.96, 0.0, 3.3), ), ((2.41, 0.0, 3.3), ), ))
modRa.Surface(name='CP-26-Frame-1', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0522, 0.0), )))
modRa.Surface(name='CP-26-HEA_incl_connection-1', 
    side1Faces=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    ((0.266667, -0.0572, -0.007), )), side2Faces=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    ((2.476667, -0.1072, -0.007), ), ((2.643333, -0.220533, -0.007), ), ))
modRa.Surface(name='CP-27-Frame-2', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0522, 3.45), )))
modRa.Surface(name='CP-27-HEA_incl_connection-2', 
    side1Faces=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    ((0.266667, -0.0572, 3.443), )), side2Faces=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    ((2.476667, -0.1072, 3.443), ), ((2.643333, -0.220533, 3.443), ), ))
### REGENERATE ASSEMBLY ###
modRa.regenerate()
### All Nodes Set ###
modRa.Set(name='Nall', nodes=
    modRa.instances['Inner_plate-1'].nodes[0:4069]+\
    modRa.instances['Insulation-1'].nodes[0:6935]+\
    modRa.instances['Outer_plate-1'].nodes[0:1063]+\
    modRa.instances['Inner_plate-2'].nodes[0:4069]+\
    modRa.instances['Inner_plate-3'].nodes[0:4069]+\
    modRa.instances['Insulation-2'].nodes[0:6935]+\
    modRa.instances['Insulation-3'].nodes[0:6935]+\
    modRa.instances['Outer_plate-2'].nodes[0:1063]+\
    modRa.instances['Outer_plate-3'].nodes[0:1063]+\
    modRa.instances['Frame-1'].nodes[0:1093]+\
    modRa.instances['Frame-2'].nodes[0:1093]+\
    modRa.instances['HEA_incl_connection-1'].nodes[0:2125]+\
    modRa.instances['HEA_incl_connection-2'].nodes[0:2125])
### Sets per Panel ###
modRa.Set(cells=
    modRa.instances['Insulation-1'].cells.findAt((
    (0.9, 0.053783, 2.4), )), faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.15, 0.0, 0.6), (0.0, -1.0, 0.0)), ((0.6, 0.0, 0.6), (0.0, -1.0, 0.0)), 
    ((0.15, 0.0, 1.05), (0.0, -1.0, 0.0)), ((0.6, 0.0, 1.05), (0.0, -1.0, 
    0.0)), ((0.15, 0.0, 1.5), (0.0, -1.0, 0.0)), ((0.6, 0.0, 1.5), (0.0, -1.0, 
    0.0)), ((0.15, 0.0, 1.95), (0.0, -1.0, 0.0)), ((0.6, 0.0, 1.95), (0.0, 
    -1.0, 0.0)), ((0.15, 0.0, 2.4), (0.0, -1.0, 0.0)), ((0.6, 0.0, 2.4), (0.0, 
    -1.0, 0.0)), ((0.15, 0.0, 2.85), (0.0, -1.0, 0.0)), ((0.6, 0.0, 2.85), (
    0.0, -1.0, 0.0)), ((0.15, 0.0, 3.3), (0.0, -1.0, 0.0)), ((0.6, 0.0, 3.3), (
    0.0, -1.0, 0.0)), ((0.75, 0.0, 0.3), (0.0, -1.0, 0.0)), ((0.3, 0.0, 0.3), (
    0.0, -1.0, 0.0)), )+\
    modRa.instances['Outer_plate-1'].faces.findAt(
    ((0.6, 0.08045, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-1')
modRa.Set(cells=
    modRa.instances['Insulation-2'].cells.findAt((
    (1.805, 0.053783, 2.4), )), faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.055, 0.0, 0.6), (0.0, -1.0, 0.0)), ((1.505, 0.0, 0.6), (0.0, -1.0, 
    0.0)), ((1.055, 0.0, 1.05), (0.0, -1.0, 0.0)), ((1.505, 0.0, 1.05), (0.0, 
    -1.0, 0.0)), ((1.055, 0.0, 1.5), (0.0, -1.0, 0.0)), ((1.505, 0.0, 1.5), (
    0.0, -1.0, 0.0)), ((1.055, 0.0, 1.95), (0.0, -1.0, 0.0)), ((1.505, 0.0, 
    1.95), (0.0, -1.0, 0.0)), ((1.055, 0.0, 2.4), (0.0, -1.0, 0.0)), ((1.505, 
    0.0, 2.4), (0.0, -1.0, 0.0)), ((1.055, 0.0, 2.85), (0.0, -1.0, 0.0)), ((
    1.505, 0.0, 2.85), (0.0, -1.0, 0.0)), ((1.055, 0.0, 3.3), (0.0, -1.0, 
    0.0)), ((1.505, 0.0, 3.3), (0.0, -1.0, 0.0)), ((1.655, 0.0, 0.3), (0.0, 
    -1.0, 0.0)), ((1.205, 0.0, 0.3), (0.0, -1.0, 0.0)), )+\
    modRa.instances['Outer_plate-2'].faces.findAt(
    ((1.505, 0.08, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-2')
modRa.Set(cells=
    modRa.instances['Insulation-3'].cells.findAt((
    (2.71, 0.053783, 2.4), )), faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((1.96, 0.0, 0.6), (0.0, -1.0, 0.0)), ((2.41, 0.0, 0.6), (0.0, -1.0, 0.0)), 
    ((1.96, 0.0, 1.05), (0.0, -1.0, 0.0)), ((2.41, 0.0, 1.05), (0.0, -1.0, 
    0.0)), ((1.96, 0.0, 1.5), (0.0, -1.0, 0.0)), ((2.41, 0.0, 1.5), (0.0, -1.0, 
    0.0)), ((1.96, 0.0, 1.95), (0.0, -1.0, 0.0)), ((2.41, 0.0, 1.95), (0.0, 
    -1.0, 0.0)), ((1.96, 0.0, 2.4), (0.0, -1.0, 0.0)), ((2.41, 0.0, 2.4), (0.0, 
    -1.0, 0.0)), ((1.96, 0.0, 2.85), (0.0, -1.0, 0.0)), ((2.41, 0.0, 2.85), (
    0.0, -1.0, 0.0)), ((1.96, 0.0, 3.3), (0.0, -1.0, 0.0)), ((2.41, 0.0, 3.3), 
    (0.0, -1.0, 0.0)), ((2.56, 0.0, 0.3), (0.0, -1.0, 0.0)), ((2.11, 0.0, 0.3), 
    (0.0, -1.0, 0.0)), )+\
    modRa.instances['Outer_plate-3'].faces.findAt(
    ((2.41, 0.08, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-3')
# ### INITIAL TEMPERATURE ###
# mod.keywordBlock.synchVersions(storeNodesAndElements=False)
# mod.keywordBlock.replace(285,
#    '\n** ----------------------------------------------------------------\n** \n*INITIAL CONDITIONS, TYPE=TEMPERATURE\nNall,20\n** STEP: Initial\n\n*Imperfection, file=i0_buc-Job, step=1\n1, 0.003 \n**')
### Create Step ###
# Step is later modified for current iteration (by upGeomHT). 
# Defined here for Field Output Request and Model Change Interaction  
mod.HeatTransferStep(deltmx=50.0, initialInc=1.0, maxInc=
    5.0, maxNumInc=1000, minInc=1E-6, name='i0_HT-Step', 
	previous='Initial', timePeriod=3650.0)
### Import Adiabatic Temperature Data ###
imp = mod.TabularAmplitude
### Request Field Output ###
# Field Output is requested every 5 seconds.
modFOR = mod.fieldOutputRequests['F-Output-1']
modFOR.setValues(variables=('NT','FV',), timeInterval=5.0) # use this
# Field Output is requested for every (Abaqus) increment/iteration.
# modFOR.setValues(variables=('NT',), frequency=1.0)  # or this
### Request Restart File for Initial Request ###
mod.steps['i0_HT-Step'].Restart(frequency=0, numberIntervals=1, overlay=ON,
	timeMarks=OFF)
### Model change Interaction ###
mod.ModelChange(name='ModelChange', createStepName='i0_HT-Step', 
	isRestart=True)
########################## End of HT_basicModel ###########################
################### Additional Lines Added by upGeomHT ####################