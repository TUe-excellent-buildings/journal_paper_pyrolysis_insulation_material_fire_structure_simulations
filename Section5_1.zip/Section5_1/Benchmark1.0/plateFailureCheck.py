###########################################################################
## Name:        PlateFailureCheck.py 									 ##
##																		 ##
## Description: This Abaqus python script checks the ix_SR-Job.odb data  ##
##				from the Structural Response analysis for possible 		 ##
##				failure of the facade based on predefined failure modes  ##
##				which are calulated using failure variables.			 ##
##				The failure variables and *.odb path info are read from  ##
##				plateFailureInputVariables.py as controlled by           ##
##				FDS-2-Abaqus. Plate failure data is written to temporary ##
##				update file plateFailureUpdate.temp which is used to     ##
##				update geometries. Additional info is written to log     ##
##				file plateFailurePythonDebug.log.  						 ##
##												                         ##
## Input:		ix_SR-Job.odb 									    	 ##
##				plateFailureInputVariables.py   						 ##
##												                         ##
## Output:      plateFailureUpdate.temp                                  ##
##   			plateFailurePythonDebug.log   							 ##
##											                             ##
## Required     myOdbPath							 					 ##
## Parameters   Input variables all failure modes                        ##
###########################################################################
## Version 2.0                                       by J.G.G.M. de Boer ##
## May 2018                                j.g.g.m.d.boer@student.tue.nl ##
###########################################################################

############################## Begin Script ###############################

### Import and initiate logging ###
import logging
logFile='plateFailurePythonDebug.log'
logging.basicConfig(
	filename=logFile,
	filemode='w',
	level=logging.INFO,
	format='%(asctime)s %(message)s',
	datefmt='%a, %d %b %Y %H:%M:%S',
)
### Import Abaqus libraries ###
from odbAccess import openOdb
from abaqusConstants import *
from abaqus import *
### Import Python libraries ###
import math
### import input variables (controlled by FDS-2-Abaqus) ###
#- myOdbPath       #
#- failureCriteria #
execfile(r'plateFailureInputVariables.py', __main__.__dict__)
### initial logging ###
logging.info('Script Running')
### Read Odb ###
odb = openOdb(myOdbPath)
### Define Frame Selection ###
selectFrame = odb.steps[stepname].frames  
lastFrame = odb.steps[stepname].frames[-1]
### Count Number of Frames (iteration (output)steps in SR analysis) ###
numberOfFrames = len(selectFrame) 
### Create Lists required for checking FailureCriteria ###
failedElementList = []
panel_1_DeflectionDataList = []
panel_1_ScrewShear_1_DataList = []
panel_1_ScrewShear_2_DataList = []
panel_1_ScrewTensionDataList = []
panel_1_ScrewShearDisp_1_DataList = []
panel_1_ScrewShearDisp_2_DataList = []
panel_1_ScrewTensionDispDataList = []
panel_1_RelDispDataList = []
panel_2_DeflectionDataList = []
panel_2_ScrewShear_1_DataList = []
panel_2_ScrewShear_2_DataList = []
panel_2_ScrewTensionDataList = []
panel_2_ScrewShearDisp_1_DataList = []
panel_2_ScrewShearDisp_2_DataList = []
panel_2_ScrewTensionDispDataList = []
panel_2_RelDispDataList = []
panel_3_DeflectionDataList = []
panel_3_ScrewShear_1_DataList = []
panel_3_ScrewShear_2_DataList = []
panel_3_ScrewTensionDataList = []
panel_3_ScrewShearDisp_1_DataList = []
panel_3_ScrewShearDisp_2_DataList = []
panel_3_ScrewTensionDispDataList = []
panel_3_RelDispDataList = []
frame_1_LowerBoltShear_1_DataList = []
frame_1_LowerBoltShear_2_DataList = []
frame_1_LowerBoltTensionDataList = []
frame_1_LowerBoltShearDisp_1_DataList = []
frame_1_LowerBoltShearDisp_2_DataList = []
frame_1_LowerBoltTensionDispDataList = []
frame_1_UpperBoltShear_1_DataList = []
frame_1_UpperBoltShear_2_DataList = []
frame_1_UpperBoltTensionDataList = []
frame_1_UpperBoltShearDisp_1_DataList = []
frame_1_UpperBoltShearDisp_2_DataList = []
frame_1_UpperBoltTensionDispDataList = []
frame_2_LowerBoltShear_1_DataList = []
frame_2_LowerBoltShear_2_DataList = []
frame_2_LowerBoltTensionDataList = []
frame_2_LowerBoltShearDisp_1_DataList = []
frame_2_LowerBoltShearDisp_2_DataList = []
frame_2_LowerBoltTensionDispDataList = []
frame_2_UpperBoltShear_1_DataList = []
frame_2_UpperBoltShear_2_DataList = []
frame_2_UpperBoltTensionDataList = []
frame_2_UpperBoltShearDisp_1_DataList = []
frame_2_UpperBoltShearDisp_2_DataList = []
frame_2_UpperBoltTensionDispDataList = []
### create lists for checks ###
Panel_1_UnityCheckList = []
Panel_2_UnityCheckList = []
Panel_3_UnityCheckList = []
frame_1_Lower_UnityCheckList = []
frame_1_Upper_UnityCheckList = []
frame_2_Lower_UnityCheckList = []
frame_2_Upper_UnityCheckList = []
### Create Critical Failure Values ###
## Using the variables set by the user ##
## failure mode 1 ##
Ucr = (((lengthOfPanels)**2)/(400 * thicknessOfPanels))
## failure mode 2 ##
Urel = lengthOverlap
## failure mode 3 ##
Fsvrd = ((380 * screwArea) / 1.25)
Fsbrd = ((1.5 * ultimateStrengthScrewSupport * screwDiameter * thicknessOfScrewSupport) / 1.25)
Fstrd = ((560 * screwArea) / 1.25)
Fsprd = ((0.95 * 400 * math.sqrt(((thicknessOfScrewSupport)**3)* screwDiameter))/ 1.25)
# 12% axial fracture strain and 0.24rad transverse strain, as displacements #
dstcr = (0.19 / 1000)
dsscr = (0.38 / 1000)
## failure mode 4 ##
Fbvrd = ((0.6 * ultimateStrengthBolt * boltArea)/1.25)
Fbbrd = ((1.0 * 2.5 * ultimateStrengthBoltSupport * boltDiameter * thicknessOfBoltSupport)/1.25)
Fbtrd = ((0.9 * ultimateStrengthBolt * boltArea)/1.25)
Bbprd = ((0.6 * math.pi * washerDiameter * thicknessOfBoltSupport * ultimateStrengthBoltSupport)/1.25)
dbtcr = (2.4  /1000)
dbscr = (4.8 / 1000)
### Create Output File ###
failureUpdate = open('plateFailureUpdate.temp', 'w' )
### NODES OUT OF .odb FILE ###
Panel_1_All_Inner = odb.rootAssembly.instances[
    'INNER_PLATE-1'].nodeSets['ALL_NODES_INNER']
Panel_2_All_Inner = odb.rootAssembly.instances[
    'INNER_PLATE-2'].nodeSets['ALL_NODES_INNER']
Panel_3_All_Inner = odb.rootAssembly.instances[
    'INNER_PLATE-3'].nodeSets['ALL_NODES_INNER']
Panel_1_Bottom = odb.rootAssembly.instances[
    'OUTER_PLATE-1'].nodeSets['BOTTOM_NODE']
Panel_2_Bottom = odb.rootAssembly.instances[
    'OUTER_PLATE-2'].nodeSets['BOTTOM_NODE']
Panel_2_Top = odb.rootAssembly.instances[
    'OUTER_PLATE-2'].nodeSets['TOP_NODE']
Panel_3_Top = odb.rootAssembly.instances[
    'OUTER_PLATE-3'].nodeSets['TOP_NODE']
Panel_1_Screws = odb.rootAssembly.elementSets[
	'WIRE-4-SET-1']
Panel_2_Screws = odb.rootAssembly.elementSets[
	'WIRE-5-SET-1']
Panel_3_Screws = odb.rootAssembly.elementSets[
	'WIRE-6-SET-1']
Frame_1_Upper = odb.rootAssembly.elementSets[
	'_FASTENERS_HEA_FRAME-1_UPPER_PF_']
Frame_1_Lower = odb.rootAssembly.elementSets[
	'_FASTENERS_HEA_FRAME-1_LOWER_PF_']
Frame_2_Upper = odb.rootAssembly.elementSets[
	'_FASTENERS_HEA_FRAME-2_UPPER_PF_']
Frame_2_Lower = odb.rootAssembly.elementSets[
	'_FASTENERS_HEA_FRAME-2_LOWER_PF_']
## check if panel is already failed ##
## PANEL 1 ##
### Select instance by instanceName ###
Panel_1_select = odb.rootAssembly.instances['INNER_PLATE-1']
### check if plate already failed/is deactivated / needed for the if-check ###
#- if failed, plate deactivated -> no stress data in container)	#
Panel_1_checkPlateDeactivation = selectFrame[0].fieldOutputs['S'].getSubset(
	region = Panel_1_select, 
	position = INTEGRATION_POINT,
	elementType = 'S8R'
)
Panel_1_checkForZeroValues = len(Panel_1_checkPlateDeactivation.values)	
## PANEL 2 ##
Panel_2_select = odb.rootAssembly.instances['INNER_PLATE-2']
Panel_2_checkPlateDeactivation = selectFrame[0].fieldOutputs['S'].getSubset(
	region = Panel_2_select, 
	position = INTEGRATION_POINT,
	elementType = 'S8R'
)
Panel_2_checkForZeroValues = len(Panel_2_checkPlateDeactivation.values)	
## PANEL 3 ##
Panel_3_select = odb.rootAssembly.instances['INNER_PLATE-3']
Panel_3_checkPlateDeactivation = selectFrame[0].fieldOutputs['S'].getSubset(
	region = Panel_3_select, 
	position = INTEGRATION_POINT,
	elementType = 'S8R'
)
Panel_3_checkForZeroValues = len(Panel_3_checkPlateDeactivation.values)
## unity checks per panel ##	
Panel_1_Failed = 0
Panel_2_Failed = 0
Panel_3_Failed = 0
## unity checks per frame ##
frame_1_Lower_Failed = 0
frame_1_Upper_Failed = 0
frame_2_Lower_Failed = 0
frame_2_Upper_Failed = 0
### FAILURE MODES ###
## FAILURE MODE 1 ##
# PANEL 1 #
### if stress container is empty no check is needed ###
if Panel_1_checkForZeroValues == 0:
	logging.info (
	'Check failure mode 1: Panel-1 already failed in a previous iteration' 
		)
else :
	for frameCount in selectFrame:
		## Deflection field for current frame ##
		Panel_1_deflection = frameCount.fieldOutputs['U']
		Panel_1_max_deflection = Panel_1_deflection.getSubset(region=Panel_1_All_Inner)
		Panel_1_values_max_deflection = Panel_1_max_deflection.values
		### empty deflection Data list for failurecheck ###
		panel_1_DeflectionDataList [:]=[]
		for v in Panel_1_values_max_deflection:
			### add (append) deflection data to Data list ###
			panel_1_DeflectionDataList.append(v.data[1])
		### creating minimum and maximum values ###
		## because deflection is not always largest in the middle ##
		Umin = min(panel_1_DeflectionDataList)
		Umax = max(panel_1_DeflectionDataList)
		### checking failure criteria, generating boolean list ###
		Panel_1_deflectionCheckList = [
			(Umax - Umin) >= Ucr 
		]	
		### counting number of 'True' (=failed points) ###
		#- in boolean list deflectionCheck #
		panel_1_Deflection_NumberOfFailedPoints = Panel_1_deflectionCheckList.\
			count(True)
		### check failure criteria (elements) ###
		if panel_1_Deflection_NumberOfFailedPoints == 1: 
			### write plateFailure data to update-file incl. Failure mode### 
			failureUpdate.write('PANEL-1 %d 1\n' % ( 
					frameCount.frameValue
				)
			)
			### write plateFailure to logfile (debugging) ###
			logging.info (
				'PANEL-1 failed at t=%d seconds since the deflection is too large' % ( 
					frameCount.frameValue
				)
			)
			### setting panel as failed, no other failure checks needed ###
			Panel_1_Failed = 1
			### Break 'frameCount for loop' when plate failed ###
			break
# PANEL 2 #
### if stress container is empty no check is needed ###
if Panel_2_checkForZeroValues == 0:
	logging.info (
	'Check failure mode 1: Panel-2 already failed in a previous iteration' 
		)
else :
	for frameCount in selectFrame:
		## Deflection field for current frame ##
		Panel_2_deflection = frameCount.fieldOutputs['U']
		Panel_2_max_deflection = Panel_2_deflection.getSubset(region=Panel_2_All_Inner)
		Panel_2_values_max_deflection = Panel_2_max_deflection.values
		### empty deflection Data list for failurecheck ###
		panel_2_DeflectionDataList [:]=[]
		for v in Panel_2_values_max_deflection:
			### add (append) deflection data to Data list ###
			panel_2_DeflectionDataList.append(v.data[1])
		### creating minimum and maximum values ###
			## because deflection is not always largest in the middle ##
		Umin = min(panel_2_DeflectionDataList)
		Umax = max(panel_2_DeflectionDataList)
		### checking failure criteria, generating boolean list ###
		Panel_2_deflectionCheckList = [
			(Umax - Umin) >= Ucr 
		]	
		### counting number of 'True' (=failed points) ###
		#- in boolean list deflectionCheck #
		panel_2_Deflection_NumberOfFailedPoints = Panel_2_deflectionCheckList.\
			count(True)
		### check failure criteria (elements) ###
		if panel_2_Deflection_NumberOfFailedPoints == 1: 
			### write plateFailure data to update-file incl. Failure mode### 
			failureUpdate.write('PANEL-2 %d 1\n' % ( 
					frameCount.frameValue
				)
			)
			### write plateFailure to logfile (debugging) ###
			logging.info (
				'PANEL-2 failed at t=%d seconds since the deflection is too large' % ( 
					frameCount.frameValue
				)
			)
			### setting panel as failed, no other failure checks needed ###
			Panel_2_Failed = 1
			### Break 'frameCount for loop' when plate failed ###
			break
# PANEL 3 #
### if stress container is empty no check is needed ###
if Panel_3_checkForZeroValues == 0:
	logging.info (
	'Check failure mode 1: Panel-3 already failed in a previous iteration' 
		)
else :
	for frameCount in selectFrame:
		## Deflection field for current frame ##
		Panel_3_deflection = frameCount.fieldOutputs['U']
		Panel_3_max_deflection = Panel_3_deflection.getSubset(region=Panel_3_All_Inner)
		Panel_3_values_max_deflection = Panel_3_max_deflection.values
		### empty deflection Data list for failurecheck ###
		panel_3_DeflectionDataList [:]=[]
		for v in Panel_3_values_max_deflection:
			### add (append) deflection data to Data list ###
			panel_3_DeflectionDataList.append(v.data[1])
		### creating minimum and maximum values ###
			## because deflection is not always largest in the middle ##
		Umin = min(panel_3_DeflectionDataList)
		Umax = max(panel_3_DeflectionDataList)
		### checking failure criteria, generating boolean list ###
		Panel_3_deflectionCheckList = [
			(Umax - Umin) >= Ucr 
		]	
		### counting number of 'True' (=failed points) ###
		#- in boolean list deflectionCheck #
		panel_3_Deflection_NumberOfFailedPoints = Panel_3_deflectionCheckList.\
			count(True)
		### check failure criteria (elements) ###
		if panel_3_Deflection_NumberOfFailedPoints == 1: 
			### write plateFailure data to update-file incl. Failure mode### 
			failureUpdate.write('PANEL-3 %d 1\n' % ( 
					frameCount.frameValue
				)
			)
			### write plateFailure to logfile (debugging) ###
			logging.info (
				'PANEL-3 failed at t=%d seconds since the deflection is too large' % ( 
					frameCount.frameValue
				)
			)
			### setting panel as failed, no other failure checks needed ###
			Panel_3_Failed = 1
			### Break 'frameCount for loop' when plate failed ###
			break
## FAILURE MODE 2 ##
# Between panel 1 and 2 #
if (Panel_1_Failed or Panel_2_Failed) == 1:
	logging.info(
	'Check failure mode 2: failure mode 2 cannot occur since Panel-1 or Panel-2 is already failed'
		)
else:
	if (Panel_1_checkForZeroValues or Panel_2_checkForZeroValues) == 0:
		logging.info (
		'Check failure mode 2: Panel-1 or Panel-2 already failed in a previous iteration' 
			)
	else:
		for frameCount in selectFrame:
			## Displacement field for current frame ##
			Panel_1_displacement = frameCount.fieldOutputs['U']
			Panel_1_bottom_displacement = Panel_1_displacement.getSubset(region=Panel_1_Bottom)
			Panel_1_values_bottom_displacement = Panel_1_bottom_displacement.values
			Panel_2_displacement = frameCount.fieldOutputs['U']
			Panel_2_top_displacement = Panel_2_displacement.getSubset(region=Panel_2_Top)
			Panel_2_values_top_displacement = Panel_2_top_displacement.values
			### empty displacement Data list for failurecheck ###
			panel_1_RelDispDataList [:]=[]
			panel_2_RelDispDataList [:]=[]
			for v in Panel_1_values_bottom_displacement:
				### add (append) displacement bottom node panel-1 data to Data list ###
				panel_1_RelDispDataList.append(v.data[0])
			for u in Panel_2_values_top_displacement:
				### add (append) displacement top node panel-2 data to Data list ###
				panel_2_RelDispDataList.append(u.data[0])
			### checking failure criteria, generating boolean list ###
			Panel_1_2_RelDispCheckList = [
				(U1 - U2) >= Urel for U1 in panel_1_RelDispDataList for U2 in panel_2_RelDispDataList
			] 
			### counting number of 'True' (=failed points) ###
			#- in boolean list RelDispCheck #
			Panel_1_2_RelDisp_NumberOfFailedPoints = Panel_1_2_RelDispCheckList.\
				count(True)
			### check failure criteria (elements) ###
			if Panel_1_2_RelDisp_NumberOfFailedPoints == 1: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 PANEL-2 %d 2\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'An opening occurs between PANEL-1 and PANEL-2 at t=%d seconds since the relative displacement is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting opening ###
				Panel_1_2_Opening = 1
				### Break 'frameCount for loop' when plate failed ###
				break
# Between panel 2 and 3 #
if (Panel_2_Failed or Panel_3_Failed) == 1:
	logging.info(
	'Check failure mode 2: failure mode 2 cannot occur since Panel-2 or Panel-3 is already failed'
		)
else:
	if (Panel_2_checkForZeroValues or Panel_3_checkForZeroValues) == 0:
		logging.info (
		'Check failure mode 2: Panel-2 or Panel-3 already failed in a previous iteration' 
			)
	else:
		for frameCount in selectFrame:
			## Displacement field for current frame ##
			Panel_2_displacement = frameCount.fieldOutputs['U']
			Panel_2_bottom_displacement = Panel_2_displacement.getSubset(region=Panel_2_Bottom)
			Panel_2_values_bottom_displacement = Panel_2_bottom_displacement.values
			Panel_3_displacement = frameCount.fieldOutputs['U']
			Panel_3_top_displacement = Panel_3_displacement.getSubset(region=Panel_3_Top)
			Panel_3_values_top_displacement = Panel_3_top_displacement.values
			### empty displacement Data list for failurecheck ###
			panel_2_RelDispDataList [:]=[]
			panel_3_RelDispDataList [:]=[]
			for v in Panel_2_values_bottom_displacement:
				### add (append) displacement bottom node panel-2 data to Data list ###
				panel_2_RelDispDataList.append(v.data[0])
			for u in Panel_3_values_top_displacement:
				### add (append) displacement top node panel-3 data to Data list ###
				panel_3_RelDispDataList.append(u.data[0])
			### checking failure criteria, generating boolean list ###
			Panel_2_3_RelDispCheckList = [
				(U2 - U3) >= Urel for U2 in panel_2_RelDispDataList for U3 in panel_3_RelDispDataList
			] 
			### counting number of 'True' (=failed points) ###
			#- in boolean list RelDispCheck #
			Panel_2_3_RelDisp_NumberOfFailedPoints = Panel_2_3_RelDispCheckList.\
				count(True)
			### check failure criteria (elements) ###
			if Panel_2_3_RelDisp_NumberOfFailedPoints == 1: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 PANEL-3 %d 2\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'An opening occurs between PANEL-2 and PANEL-3 at t=%d seconds since the relative displacement is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting opening ###
				Panel_2_3_Opening = 1
				### Break 'frameCount for loop' when plate failed ###
				break
## FAILURE MODE 3 ##
# PANEL 1 #
if Panel_1_Failed == 1:
	logging.info(
	'Check failure mode 3: Panel-1 already failed due to too large bending of the panels'
		)
else:
	if Panel_1_checkForZeroValues == 0:
		logging.info (
		'Check failure mode 3: Panel-1 already failed in a previous iteration' 
			)
	else:
		for frameCount in selectFrame:
			## Connection force field for current frame ##
			Panel_1_Forces = frameCount.fieldOutputs['CTF']
			Panel_1_Screw_Forces = Panel_1_Forces.getSubset(region=Panel_1_Screws)
			Panel_1_values_Screw_Forces = Panel_1_Screw_Forces.values
			Panel_1_Disp = frameCount.fieldOutputs['CU']
			Panel_1_Screw_Disp = Panel_1_Disp.getSubset(region=Panel_1_Screws)
			Panel_1_values_Screw_Disp = Panel_1_Screw_Disp.values
			### empty forces Data list for failurecheck ###
			panel_1_ScrewShear_1_DataList [:] = []
			panel_1_ScrewShear_2_DataList [:] = []
			panel_1_ScrewTensionDataList [:] = []
			panel_1_ScrewShearDisp_1_DataList [:] = []
			panel_1_ScrewShearDisp_2_DataList [:] = []
			panel_1_ScrewTensionDispDataList [:] = []
			for s1 in Panel_1_values_Screw_Forces:
				### add (append) shear force 1 of the screws of panel-1 to Data list ###
				panel_1_ScrewShear_1_DataList.append(s1.data[0])
			for s2 in Panel_1_values_Screw_Forces:
				### add (append) shear force 2 of the screws of panel-1 to Data list ###
				panel_1_ScrewShear_2_DataList.append(s2.data[2])
			for t in Panel_1_values_Screw_Forces:
				### add (append) tension force of the screws of panel-1 to Data list ###
				panel_1_ScrewTensionDataList.append(t.data[1])
			for ds1 in Panel_1_values_Screw_Disp:
				### add (append) shear displacement 1 of the screws of panel-1 to Data list ###
				panel_1_ScrewShearDisp_1_DataList.append(ds1.data[0])
			for ds2 in Panel_1_values_Screw_Disp:
				### add (append) shear displacement 2 of the screws of panel-1 to Data list ###
				panel_1_ScrewShearDisp_2_DataList.append(ds2.data[2])
			for dt in Panel_1_values_Screw_Disp:
				### add (append) tension displacement of the screws of panel-1 to Data list ###
				panel_1_ScrewTensionDispDataList.append(dt.data[1])
			### Splitting Force per screw ###
			SF11 = panel_1_ScrewShear_1_DataList[0]
			SF21 = panel_1_ScrewShear_2_DataList[0]
			TF1 = panel_1_ScrewTensionDataList[0]
			SF12 = panel_1_ScrewShear_1_DataList[1]
			SF22 = panel_1_ScrewShear_2_DataList[1]
			TF2 = panel_1_ScrewTensionDataList[1]
			Sd11 = panel_1_ScrewShearDisp_1_DataList[0]
			Sd21 = panel_1_ScrewShearDisp_2_DataList[0]
			Td1 = panel_1_ScrewTensionDispDataList[0]
			Sd12 = panel_1_ScrewShearDisp_1_DataList[1]
			Sd22 = panel_1_ScrewShearDisp_2_DataList[1]
			Td2 = panel_1_ScrewTensionDispDataList[1]
			### FAILURE MODE 1 ###
			## empty unity check list ##
			Panel_1_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_1_Screw_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dsscr
			Panel_1_Screw_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dsscr
			Panel_1_UnityCheckList = [Panel_1_Screw_1_UnityCheck, Panel_1_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_1_NumberOfFailedScrews = Panel_1_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_1_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 %d 3 1\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-1 failed at t=%d seconds since the shear strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_1_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 2 ###
			## empty unity check list ##
			Panel_1_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_1_Screw_1_UnityCheck = Td1 >= dstcr
			Panel_1_Screw_2_UnityCheck = Td2 >= dstcr 
			Panel_1_UnityCheckList = [Panel_1_Screw_1_UnityCheck, Panel_1_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_1_NumberOfFailedScrews = Panel_1_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_1_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 %d 3 2\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-1 failed at t=%d seconds since the tension strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_1_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 3 ###
			## empty unity check list ##
			Panel_1_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_1_Screw_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dsscr)+(Td1/(1.4*dstcr))) >= 1.0
			Panel_1_Screw_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dsscr)+(Td2/(1.4*dstcr))) >= 1.0
			Panel_1_UnityCheckList = [Panel_1_Screw_1_UnityCheck, Panel_1_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_1_NumberOfFailedScrews = Panel_1_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_1_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 %d 3 3\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-1 failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_1_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 4 ###
			## empty unity check list ##
			Panel_1_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_1_Screw_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fsbrd) >= 1.0
			Panel_1_Screw_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fsbrd) >= 1.0
			Panel_1_UnityCheckList = [Panel_1_Screw_1_UnityCheck, Panel_1_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_1_NumberOfFailedScrews = Panel_1_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_1_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 %d 3 4\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-1 failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_1_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 5 ###
			## empty unity check list ##
			Panel_1_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_1_Screw_1_UnityCheck = (TF1/Fsprd) >= 1.0
			Panel_1_Screw_2_UnityCheck = (TF2/Fsprd) >= 1.0
			Panel_1_UnityCheckList = [Panel_1_Screw_1_UnityCheck, Panel_1_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_1_NumberOfFailedScrews = Panel_1_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_1_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-1 %d 3 5\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-1 failed at t=%d seconds since the tension force larger than the pull-out capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_1_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
# PANEL 2 #
if Panel_2_Failed == 1:
	logging.info(
	'Check failure mode 3: Panel-2 already failed due to too large bending of the panels'
		)
else:
	if Panel_2_checkForZeroValues == 0:
		logging.info (
		'Check failure mode 3: Panel-2 already failed in a previous iteration' 
			)
	else:
		for frameCount in selectFrame:
			## Connection force field for current frame ##
			Panel_2_Forces = frameCount.fieldOutputs['CTF']
			Panel_2_Screw_Forces = Panel_2_Forces.getSubset(region=Panel_2_Screws)
			Panel_2_values_Screw_Forces = Panel_2_Screw_Forces.values
			Panel_2_Disp = frameCount.fieldOutputs['CU']
			Panel_2_Screw_Disp = Panel_2_Disp.getSubset(region=Panel_2_Screws)
			Panel_2_values_Screw_Disp = Panel_2_Screw_Disp.values
			### empty forces Data list for failurecheck ###
			panel_2_ScrewShear_1_DataList [:] = []
			panel_2_ScrewShear_2_DataList [:] = []
			panel_2_ScrewTensionDataList [:] = []
			panel_2_ScrewShearDisp_1_DataList [:] = []
			panel_2_ScrewShearDisp_2_DataList [:] = []
			panel_2_ScrewTensionDispDataList [:] = []
			for s1 in Panel_2_values_Screw_Forces:
				### add (append) shear force 1 of the screws of panel-2 to Data list ###
				panel_2_ScrewShear_1_DataList.append(s1.data[0])
			for s2 in Panel_2_values_Screw_Forces:
				### add (append) shear force 2 of the screws of panel-2 to Data list ###
				panel_2_ScrewShear_2_DataList.append(s2.data[2])
			for t in Panel_2_values_Screw_Forces:
				### add (append) tension force of the screws of panel-2 to Data list ###
				panel_2_ScrewTensionDataList.append(t.data[1])
			for ds1 in Panel_2_values_Screw_Disp:
				### add (append) shear displacement 1 of the screws of panel-2 to Data list ###
				panel_2_ScrewShearDisp_1_DataList.append(ds1.data[0])
			for ds2 in Panel_2_values_Screw_Disp:
				### add (append) shear displacement 2 of the screws of panel-2 to Data list ###
				panel_2_ScrewShearDisp_2_DataList.append(ds2.data[2])
			for dt in Panel_2_values_Screw_Disp:
				### add (append) tension displacement of the screws of panel-2 to Data list ###
				panel_2_ScrewTensionDispDataList.append(dt.data[1])
			### Splitting Force per screw ###
			SF11 = panel_2_ScrewShear_1_DataList[0]
			SF21 = panel_2_ScrewShear_2_DataList[0]
			TF1 = panel_2_ScrewTensionDataList[0]
			SF12 = panel_2_ScrewShear_1_DataList[1]
			SF22 = panel_2_ScrewShear_2_DataList[1]
			TF2 = panel_2_ScrewTensionDataList[1]
			Sd11 = panel_2_ScrewShearDisp_1_DataList[0]
			Sd21 = panel_2_ScrewShearDisp_2_DataList[0]
			Td1 = panel_2_ScrewTensionDispDataList[0]
			Sd12 = panel_2_ScrewShearDisp_1_DataList[1]
			Sd22 = panel_2_ScrewShearDisp_2_DataList[1]
			Td2 = panel_2_ScrewTensionDispDataList[1]
			### FAILURE MODE 1 ###
			## empty unity check list ##
			Panel_2_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_2_Screw_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dsscr
			Panel_2_Screw_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dsscr
			Panel_2_UnityCheckList = [Panel_2_Screw_1_UnityCheck, Panel_2_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_2_NumberOfFailedScrews = Panel_2_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_2_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 %d 3 1\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-2 failed at t=%d seconds since the shear strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_2_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 2 ###
			## empty unity check list ##
			Panel_2_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_2_Screw_1_UnityCheck = Td1 >= dstcr
			Panel_2_Screw_2_UnityCheck = Td2 >= dstcr 
			Panel_2_UnityCheckList = [Panel_2_Screw_1_UnityCheck, Panel_2_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_2_NumberOfFailedScrews = Panel_2_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_2_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 %d 3 2\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-2 failed at t=%d seconds since the tension strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_2_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 3 ###
			## empty unity check list ##
			Panel_2_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_2_Screw_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dsscr)+(Td1/(1.4*dstcr))) >= 1.0
			Panel_2_Screw_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dsscr)+(Td2/(1.4*dstcr))) >= 1.0
			Panel_2_UnityCheckList = [Panel_2_Screw_1_UnityCheck, Panel_2_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_2_NumberOfFailedScrews = Panel_2_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_2_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 %d 3 3\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-2 failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_2_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 4 ###
			## empty unity check list ##
			Panel_2_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_2_Screw_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fsbrd) >= 1.0
			Panel_2_Screw_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fsbrd) >= 1.0
			Panel_2_UnityCheckList = [Panel_2_Screw_1_UnityCheck, Panel_2_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_2_NumberOfFailedScrews = Panel_2_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_2_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 %d 3 4\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-2 failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_2_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 5 ###
			## empty unity check list ##
			Panel_2_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_2_Screw_1_UnityCheck = (TF1/Fsprd) >= 1.0
			Panel_2_Screw_2_UnityCheck = (TF2/Fsprd) >= 1.0
			Panel_2_UnityCheckList = [Panel_2_Screw_1_UnityCheck, Panel_2_Screw_2_UnityCheck] 
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_2_NumberOfFailedScrews = Panel_2_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_2_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-2 %d 3 5\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-2 failed at t=%d seconds since the tension force larger than the pull-out capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_2_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
# PANEL 3 #
if Panel_3_Failed == 1:
	logging.info(
	'Check failure mode 3: Panel-3 already failed due to too large bending of the panels'
		)
else:
	if Panel_3_checkForZeroValues == 0:
		logging.info (
		'Check failure mode 3: Panel-3 already failed in a previous iteration' 
			)
	else:
		for frameCount in selectFrame:
			## Connection force field for current frame ##
			Panel_3_Forces = frameCount.fieldOutputs['CTF']
			Panel_3_Screw_Forces = Panel_3_Forces.getSubset(region=Panel_3_Screws)
			Panel_3_values_Screw_Forces = Panel_3_Screw_Forces.values
			Panel_3_Disp = frameCount.fieldOutputs['CU']
			Panel_3_Screw_Disp = Panel_3_Disp.getSubset(region=Panel_3_Screws)
			Panel_3_values_Screw_Disp = Panel_3_Screw_Disp.values
			### empty forces Data list for failurecheck ###
			panel_3_ScrewShear_1_DataList [:] = []
			panel_3_ScrewShear_2_DataList [:] = []
			panel_3_ScrewTensionDataList [:] = []
			panel_3_ScrewShearDisp_1_DataList [:] = []
			panel_3_ScrewShearDisp_2_DataList [:] = []
			panel_3_ScrewTensionDispDataList [:] = []
			for s1 in Panel_3_values_Screw_Forces:
				### add (append) shear force 1 of the screws of panel-3 to Data list ###
				panel_3_ScrewShear_1_DataList.append(s1.data[0])
			for s2 in Panel_3_values_Screw_Forces:
				### add (append) shear force 2 of the screws of panel-3 to Data list ###
				panel_3_ScrewShear_2_DataList.append(s2.data[2])
			for t in Panel_3_values_Screw_Forces:
				### add (append) tension force of the screws of panel-3 to Data list ###
				panel_3_ScrewTensionDataList.append(t.data[1])
			for ds1 in Panel_3_values_Screw_Disp:
				### add (append) shear displacement 1 of the screws of panel-3 to Data list ###
				panel_3_ScrewShearDisp_1_DataList.append(ds1.data[0])
			for ds2 in Panel_3_values_Screw_Disp:
				### add (append) shear displacement 2 of the screws of panel-3 to Data list ###
				panel_3_ScrewShearDisp_2_DataList.append(ds2.data[2])
			for dt in Panel_3_values_Screw_Disp:
				### add (append) tension displacement of the screws of panel-3 to Data list ###
				panel_3_ScrewTensionDispDataList.append(dt.data[1])
			### Splitting Force per screw ###
			SF11 = panel_3_ScrewShear_1_DataList[0]
			SF21 = panel_3_ScrewShear_2_DataList[0]
			TF1 = panel_3_ScrewTensionDataList[0]
			SF12 = panel_3_ScrewShear_1_DataList[1]
			SF22 = panel_3_ScrewShear_2_DataList[1]
			TF2 = panel_3_ScrewTensionDataList[1]
			Sd11 = panel_3_ScrewShearDisp_1_DataList[0]
			Sd21 = panel_3_ScrewShearDisp_2_DataList[0]
			Td1 = panel_3_ScrewTensionDispDataList[0]
			Sd12 = panel_3_ScrewShearDisp_1_DataList[1]
			Sd22 = panel_3_ScrewShearDisp_2_DataList[1]
			Td2 = panel_3_ScrewTensionDispDataList[1]
			### FAILURE MODE 1 ###
			## empty unity check list ##
			Panel_3_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_3_Screw_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dsscr
			Panel_3_Screw_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dsscr
			Panel_3_UnityCheckList = [Panel_3_Screw_1_UnityCheck, Panel_3_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_3_NumberOfFailedScrews = Panel_3_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_3_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-3 %d 3 1\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-3 failed at t=%d seconds since the shear strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_3_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 2 ###
			## empty unity check list ##
			Panel_3_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_3_Screw_1_UnityCheck = Td1 >= dstcr
			Panel_3_Screw_2_UnityCheck = Td2 >= dstcr 
			Panel_3_UnityCheckList = [Panel_3_Screw_1_UnityCheck, Panel_3_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_3_NumberOfFailedScrews = Panel_3_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_3_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-3 %d 3 2\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-3 failed at t=%d seconds since the tension strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_3_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 3 ###
			## empty unity check list ##
			Panel_3_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_3_Screw_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dsscr)+(Td1/(1.4*dstcr))) >= 1.0
			Panel_3_Screw_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dsscr)+(Td2/(1.4*dstcr))) >= 1.0
			Panel_3_UnityCheckList = [Panel_3_Screw_1_UnityCheck, Panel_3_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_3_NumberOfFailedScrews = Panel_3_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_3_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-3 %d 3 3\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-3 failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_3_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 4 ###
			## empty unity check list ##
			Panel_3_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_3_Screw_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fsbrd) >= 1.0
			Panel_3_Screw_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fsbrd) >= 1.0
			Panel_3_UnityCheckList = [Panel_3_Screw_1_UnityCheck, Panel_3_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_3_NumberOfFailedScrews = Panel_3_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_3_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-3 %d 3 4\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-3 failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_3_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
			### FAILURE MODE 5 ###
			## empty unity check list ##
			Panel_3_UnityCheckList [:] = []
			### checking failure criteria, generating boolean list ###
			Panel_3_Screw_1_UnityCheck = (TF1/Fsprd) >= 1.0
			Panel_3_Screw_2_UnityCheck = (TF2/Fsprd) >= 1.0
			Panel_3_UnityCheckList = [Panel_3_Screw_1_UnityCheck, Panel_3_Screw_2_UnityCheck]
			### counting number of 'True' (=failed points) ###
			#- in boolean list unityCheck #
			Panel_3_NumberOfFailedScrews = Panel_3_UnityCheckList.\
				count(True)
			### check failure criteria (2 screws failed) ###
			if Panel_3_NumberOfFailedScrews == 2: 
				### write plateFailure data to update-file incl. Failure mode### 
				failureUpdate.write('PANEL-3 %d 3 5\n' % ( 
						frameCount.frameValue
					)
				)
				### write plateFailure to logfile (debugging) ###
				logging.info (
					'Both screws of PANEL-3 failed at t=%d seconds since the tension force larger than the pull-out capacity of the steel frame' % ( 
						frameCount.frameValue
					)
				)
				### setting panel failure ###
				Panel_3_Failed = 1
				### Break 'frameCount for loop' when plate failed ###
				break
## FAILURE MODE 4 ##
# FRAME-1-UPPER #
for frameCount in selectFrame:
	## Connection force field for current frame ##
	frame_1_Upper_Forces = frameCount.fieldOutputs['CTF']
	frame_1_Upper_Bolt_Forces = frame_1_Upper_Forces.getSubset(region=Frame_1_Upper)
	frame_1_values_Upper_Bolt_Forces = frame_1_Upper_Bolt_Forces.values
	frame_1_Upper_Disp = frameCount.fieldOutputs['CU']
	frame_1_Upper_Bolt_Disp = frame_1_Upper_Disp.getSubset(region=Frame_1_Upper)
	frame_1_values_Upper_Bolt_Disp = frame_1_Upper_Bolt_Disp.values
	### empty forces Data list for failurecheck ###
	frame_1_UpperBoltShear_1_DataList [:] = []
	frame_1_UpperBoltShear_2_DataList [:] = []
	frame_1_UpperBoltTensionDataList [:] = []
	frame_1_UpperBoltShearDisp_1_DataList [:] = []
	frame_1_UpperBoltShearDisp_2_DataList [:] = []
	frame_1_UpperBoltTensionDispDataList [:] = []
	for s1 in frame_1_values_Upper_Bolt_Forces:
		### add (append) shear force 1 of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltShear_1_DataList.append(s1.data[0])
	for s2 in frame_1_values_Upper_Bolt_Forces:
		### add (append) shear force 2 of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltShear_2_DataList.append(s2.data[1])
	for t in frame_1_values_Upper_Bolt_Forces:
		### add (append) tension force of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltTensionDataList.append(t.data[2])
	for ds1 in frame_1_values_Upper_Bolt_Disp:
		### add (append) shear displacement 1 of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltShearDisp_1_DataList.append(ds1.data[0])
	for ds2 in frame_1_values_Upper_Bolt_Disp:
		### add (append) shear displacement 2 of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltShearDisp_2_DataList.append(ds2.data[1])
	for dt in frame_1_values_Upper_Bolt_Disp:
		### add (append) tension displacement of the bolts of frame-1-upper to Data list ###
		frame_1_UpperBoltTensionDispDataList.append(dt.data[2])	
	### Splitting Force per screw ###
	SF11 = frame_1_UpperBoltShear_1_DataList[0]
	SF21 = frame_1_UpperBoltShear_2_DataList[0]
	TF1 = frame_1_UpperBoltTensionDataList[0]
	SF12 = frame_1_UpperBoltShear_1_DataList[1]
	SF22 = frame_1_UpperBoltShear_2_DataList[1]
	TF2 = frame_1_UpperBoltTensionDispDataList[1]
	Sd11 = frame_1_UpperBoltShearDisp_1_DataList[0]
	Sd21 = frame_1_UpperBoltShearDisp_2_DataList[0]
	Td1 = frame_1_UpperBoltTensionDispDataList[0]
	Sd12 = frame_1_UpperBoltShearDisp_1_DataList[1]
	Sd22 = frame_1_UpperBoltShearDisp_2_DataList[1]
	Td2 = frame_1_UpperBoltTensionDispDataList[1]
	### FAILURE MODE 1 ###
	## empty unity check list ##
	frame_1_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Upper_Bolt_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dbscr
	frame_1_Upper_Bolt_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dbscr
	frame_1_Upper_UnityCheckList = [frame_1_Upper_Bolt_1_UnityCheck, frame_1_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Upper_NumberOfFailedBolts = frame_1_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_1_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-UPPER failed at t=%d seconds since the shear strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 2 ###
	## empty unity check list ##
	frame_1_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Upper_Bolt_1_UnityCheck = Td1 >= dbtcr 
	frame_1_Upper_Bolt_2_UnityCheck = Td2 >= dbtcr
	frame_1_Upper_UnityCheckList = [frame_1_Upper_Bolt_1_UnityCheck, frame_1_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Upper_NumberOfFailedBolts = frame_1_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-UPPER failed at t=%d seconds since the tension strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 3 ###
	## empty unity check list ##
	frame_1_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Upper_Bolt_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dbscr)+(Td1/(1.4*dbtcr))) >= 1.0
	frame_1_Upper_Bolt_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dbscr)+(Td2/(1.4*dbtcr))) >= 1.0
	frame_1_Upper_UnityCheckList = [frame_1_Upper_Bolt_1_UnityCheck, frame_1_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Upper_NumberOfFailedBolts = frame_1_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_1_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-UPPER failed at t=%d seconds since the combination of transverse and longitudinal is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break#
	### FAILURE MODE 4 ###
	## empty unity check list ##
	frame_1_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Upper_Bolt_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fbbrd) >= 1.0
	frame_1_Upper_Bolt_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fbbrd) >= 1.0
	frame_1_Upper_UnityCheckList = [frame_1_Upper_Bolt_1_UnityCheck, frame_1_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Upper_NumberOfFailedBolts = frame_1_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-UPPER failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 5 ###
	## empty unity check list ##
	frame_1_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Upper_Bolt_1_UnityCheck = (TF1/Bbprd) >= 1.0
	frame_1_Upper_Bolt_2_UnityCheck = (TF2/Bbprd) >= 1.0
	frame_1_Upper_UnityCheckList = [frame_1_Upper_Bolt_1_UnityCheck, frame_1_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Upper_NumberOfFailedBolts = frame_1_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-UPPER failed at t=%d seconds since the tension force larger than the pull-trough capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
# FRAME-1-LOWER #
for frameCount in selectFrame:
	## Connection force field for current frame ##
	frame_1_Lower_Forces = frameCount.fieldOutputs['CTF']
	frame_1_Lower_Bolt_Forces = frame_1_Lower_Forces.getSubset(region=Frame_1_Lower)
	frame_1_values_Lower_Bolt_Forces = frame_1_Lower_Bolt_Forces.values
	frame_1_Lower_Disp = frameCount.fieldOutputs['CU']
	frame_1_Lower_Bolt_Disp = frame_1_Lower_Disp.getSubset(region=Frame_1_Lower)
	frame_1_values_Lower_Bolt_Disp = frame_1_Lower_Bolt_Disp.values
	### empty forces Data list for failurecheck ###
	frame_1_LowerBoltShear_1_DataList [:] = []
	frame_1_LowerBoltShear_2_DataList [:] = []
	frame_1_LowerBoltTensionDataList [:] = []
	frame_1_LowerBoltShearDisp_1_DataList [:] = []
	frame_1_LowerBoltShearDisp_2_DataList [:] = []
	frame_1_LowerBoltTensionDispDataList [:] = []
	for s1 in frame_1_values_Lower_Bolt_Forces:
		### add (append) shear force 1 of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltShear_1_DataList.append(s1.data[0])
	for s2 in frame_1_values_Lower_Bolt_Forces:
		### add (append) shear force 2 of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltShear_2_DataList.append(s2.data[1])
	for t in frame_1_values_Lower_Bolt_Forces:
		### add (append) tension force of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltTensionDataList.append(t.data[2])
	for ds1 in frame_1_values_Lower_Bolt_Disp:
		### add (append) shear strain 1 of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltShearDisp_1_DataList.append(ds1.data[0])
	for ds2 in frame_1_values_Lower_Bolt_Disp:
		### add (append) shear strain 2 of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltShearDisp_2_DataList.append(ds2.data[1])
	for dt in frame_1_values_Lower_Bolt_Disp:
		### add (append) tension strain of the bolts of frame-1-lower to Data list ###
		frame_1_LowerBoltTensionDispDataList.append(dt.data[2])
	### Splitting Force per screw ###
	SF11 = frame_1_LowerBoltShear_1_DataList[0]
	SF21 = frame_1_LowerBoltShear_2_DataList[0]
	TF1 = frame_1_LowerBoltTensionDataList[0]
	SF12 = frame_1_LowerBoltShear_1_DataList[1]
	SF22 = frame_1_LowerBoltShear_2_DataList[1]
	TF2 = frame_1_LowerBoltTensionDataList[1]
	Sd11 = frame_1_LowerBoltShearDisp_1_DataList[0]
	Sd21 = frame_1_LowerBoltShearDisp_2_DataList[0]
	Td1 = frame_1_LowerBoltTensionDispDataList[0]
	Sd12 = frame_1_LowerBoltShearDisp_1_DataList[1]
	Sd22 = frame_1_LowerBoltShearDisp_2_DataList[1]
	Td2 = frame_1_LowerBoltTensionDispDataList[1]
	### FAILURE MODE 1 ###
	## empty unity check list ##
	frame_1_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Lower_Bolt_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dbscr 
	frame_1_Lower_Bolt_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dbscr  
	frame_1_Lower_UnityCheckList = [frame_1_Lower_Bolt_1_UnityCheck, frame_1_Lower_Bolt_2_UnityCheck]   
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Lower_NumberOfFailedBolts = frame_1_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_1_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-LOWER failed at t=%d seconds since the shear strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 2 ###
	## empty unity check list ##
	frame_1_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Lower_Bolt_1_UnityCheck = Td1 >= dbtcr 
	frame_1_Lower_Bolt_2_UnityCheck = Td2 >= dbtcr
	frame_1_Lower_UnityCheckList = [frame_1_Lower_Bolt_1_UnityCheck, frame_1_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Lower_NumberOfFailedBolts = frame_1_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-LOWER failed at t=%d seconds since the tension strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 3 ###
	## empty unity check list ##
	frame_1_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Lower_Bolt_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dbscr)+(Td1/(1.4*dbtcr))) >= 1.0
	frame_1_Lower_Bolt_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dbscr)+(Td2/(1.4*dbtcr))) >= 1.0
	frame_1_Lower_UnityCheckList = [frame_1_Lower_Bolt_1_UnityCheck, frame_1_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Lower_NumberOfFailedBolts = frame_1_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_1_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-LOWER failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 4 ###
	## empty unity check list ##
	frame_1_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Lower_Bolt_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fbbrd) >= 1.0 
	frame_1_Lower_Bolt_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fbbrd) >= 1.0 
	frame_1_Lower_UnityCheckList = [frame_1_Lower_Bolt_1_UnityCheck, frame_1_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Lower_NumberOfFailedBolts = frame_1_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-LOWER failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 5 ###
	## empty unity check list ##
	frame_1_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_1_Lower_Bolt_1_UnityCheck = (TF1/Bbprd) >= 1.0
	frame_1_Lower_Bolt_2_UnityCheck = (TF2/Bbprd) >= 1.0
	frame_1_Lower_UnityCheckList = [frame_1_Lower_Bolt_1_UnityCheck, frame_1_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_1_Lower_NumberOfFailedBolts = frame_1_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_1_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-1-LOWER failed at t=%d seconds since the tension force larger than the pull-trough capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_1_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
# FRAME-2-UPPER #
for frameCount in selectFrame:
	## Connection force field for current frame ##
	frame_2_Upper_Forces = frameCount.fieldOutputs['CTF']
	frame_2_Upper_Bolt_Forces = frame_2_Upper_Forces.getSubset(region=Frame_2_Upper)
	frame_2_values_Upper_Bolt_Forces = frame_2_Upper_Bolt_Forces.values
	frame_2_Upper_Disp = frameCount.fieldOutputs['CU']
	frame_2_Upper_Bolt_Disp = frame_2_Upper_Disp.getSubset(region=Frame_2_Upper)
	frame_2_values_Upper_Bolt_Disp = frame_2_Upper_Bolt_Disp.values
	### empty forces Data list for failurecheck ###
	frame_2_UpperBoltShear_1_DataList [:] = []
	frame_2_UpperBoltShear_2_DataList [:] = []
	frame_2_UpperBoltTensionDataList [:] = []
	frame_2_UpperBoltShearDisp_1_DataList [:] = []
	frame_2_UpperBoltShearDisp_2_DataList [:] = []
	frame_2_UpperBoltTensionDispDataList [:] = []
	for s1 in frame_1_values_Upper_Bolt_Forces:
		### add (append) shear force 1 of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltShear_1_DataList.append(s1.data[0])
	for s2 in frame_2_values_Upper_Bolt_Forces:
		### add (append) shear force 2 of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltShear_2_DataList.append(s2.data[1])
	for t in frame_2_values_Upper_Bolt_Forces:
		### add (append) tension force of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltTensionDataList.append(t.data[2])
	for ds1 in frame_1_values_Upper_Bolt_Disp:
		### add (append) shear displacement 1 of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltShearDisp_1_DataList.append(ds1.data[0])
	for ds2 in frame_2_values_Upper_Bolt_Disp:
		### add (append) shear displacement 2 of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltShearDisp_2_DataList.append(ds2.data[1])
	for dt in frame_2_values_Upper_Bolt_Disp:
		### add (append) tension displacement of the bolts of frame-2-upper to Data list ###
		frame_2_UpperBoltTensionDispDataList.append(dt.data[2])	
	### Splitting Force per screw ###
	SF11 = frame_2_UpperBoltShear_1_DataList[0]
	SF21 = frame_2_UpperBoltShear_2_DataList[0]
	TF1 = frame_2_UpperBoltTensionDataList[0]
	SF12 = frame_2_UpperBoltShear_1_DataList[1]
	SF22 = frame_2_UpperBoltShear_2_DataList[1]
	TF2 = frame_2_UpperBoltTensionDataList[1]
	Sd11 = frame_2_UpperBoltShearDisp_1_DataList[0]
	Sd21 = frame_2_UpperBoltShearDisp_2_DataList[0]
	Td1 = frame_2_UpperBoltTensionDispDataList[0]
	Sd12 = frame_2_UpperBoltShearDisp_1_DataList[1]
	Sd22 = frame_2_UpperBoltShearDisp_2_DataList[1]
	Td2 = frame_2_UpperBoltTensionDispDataList[1]
	### FAILURE MODE 1 ###
	## empty unity check list ##
	frame_2_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Upper_Bolt_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dbscr
	frame_2_Upper_Bolt_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dbscr
	frame_2_Upper_UnityCheckList = [frame_2_Upper_Bolt_1_UnityCheck, frame_2_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Upper_NumberOfFailedBolts = frame_2_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_2_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-UPPER failed at t=%d seconds since the shear strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 2 ###
	## empty unity check list ##
	frame_2_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Upper_Bolt_1_UnityCheck = Td1 >= dbtcr 
	frame_2_Upper_Bolt_2_UnityCheck = Td2 >= dbtcr 
	frame_2_Upper_UnityCheckList = [frame_2_Upper_Bolt_1_UnityCheck, frame_2_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Upper_NumberOfFailedBolts = frame_2_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-UPPER failed at t=%d seconds since the tension strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 3 ###
	## empty unity check list ##
	frame_2_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Upper_Bolt_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dbscr)+(Td1/(1.4*dbtcr))) >= 1.0
	frame_2_Upper_Bolt_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dbscr)+(Td2/(1.4*dbtcr))) >= 1.0
	frame_2_Upper_UnityCheckList = [frame_2_Upper_Bolt_1_UnityCheck, frame_2_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Upper_NumberOfFailedBolts = frame_2_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_2_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-UPPER failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 4 ###
	## empty unity check list ##
	frame_2_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Upper_Bolt_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fbbrd) >= 1.0
	frame_2_Upper_Bolt_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fbbrd) >= 1.0
	frame_2_Upper_UnityCheckList = [frame_2_Upper_Bolt_1_UnityCheck, frame_2_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Upper_NumberOfFailedBolts = frame_2_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-UPPER failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 5 ###
	## empty unity check list ##
	frame_2_Upper_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Upper_Bolt_1_UnityCheck = (TF1/Bbprd) >= 1.0 
	frame_2_Upper_Bolt_2_UnityCheck = (TF2/Bbprd) >= 1.0  
	frame_2_Upper_UnityCheckList = [frame_2_Upper_Bolt_1_UnityCheck, frame_2_Upper_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Upper_NumberOfFailedBolts = frame_2_Upper_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Upper_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-UPPER failed at t=%d seconds since the tension force larger than the pull-trough capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Upper_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
# FRAME-2-LOWER #
for frameCount in selectFrame:
	## Connection force field for current frame ##
	frame_2_Lower_Forces = frameCount.fieldOutputs['CTF']
	frame_2_Lower_Bolt_Forces = frame_2_Lower_Forces.getSubset(region=Frame_1_Lower)
	frame_2_values_Lower_Bolt_Forces = frame_2_Lower_Bolt_Forces.values
	frame_2_Lower_Disp = frameCount.fieldOutputs['CU']
	frame_2_Lower_Bolt_Disp = frame_2_Lower_Disp.getSubset(region=Frame_1_Lower)
	frame_2_values_Lower_Bolt_Disp = frame_2_Lower_Bolt_Disp.values
	### empty forces Data list for failurecheck ###
	frame_2_LowerBoltShear_1_DataList [:] = []
	frame_2_LowerBoltShear_2_DataList [:] = []
	frame_2_LowerBoltTensionDataList [:] = []
	frame_2_LowerBoltShearDisp_1_DataList [:] = []
	frame_2_LowerBoltShearDisp_2_DataList [:] = []
	frame_2_LowerBoltTensionDispDataList [:] = []
	for s1 in frame_2_values_Lower_Bolt_Forces:
		### add (append) shear force 1 of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltShear_1_DataList.append(s1.data[0])
	for s2 in frame_2_values_Lower_Bolt_Forces:
		### add (append) shear force 2 of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltShear_2_DataList.append(s2.data[1])
	for t in frame_2_values_Lower_Bolt_Forces:
		### add (append) tension force of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltTensionDataList.append(t.data[2])
	for ds1 in frame_2_values_Lower_Bolt_Disp:
		### add (append) shear displacement 1 of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltShearDisp_1_DataList.append(ds1.data[0])
	for ds2 in frame_2_values_Lower_Bolt_Disp:
		### add (append) shear displacement 2 of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltShearDisp_2_DataList.append(ds2.data[1])
	for dt in frame_2_values_Lower_Bolt_Disp:
		### add (append) tension displacement of the bolts of frame-1-lower to Data list ###
		frame_2_LowerBoltTensionDispDataList.append(dt.data[2])
	### Splitting Force per screw ###
	SF11 = frame_2_LowerBoltShear_1_DataList[0]
	SF21 = frame_2_LowerBoltShear_2_DataList[0]
	TF1 = frame_2_LowerBoltTensionDataList[0]
	SF12 = frame_2_LowerBoltShear_1_DataList[1]
	SF22 = frame_2_LowerBoltShear_2_DataList[1]
	TF2 = frame_2_LowerBoltTensionDataList[1]
	Sd11 = frame_2_LowerBoltShearDisp_1_DataList[0]
	Sd21 = frame_2_LowerBoltShearDisp_2_DataList[0]
	Td1 = frame_2_LowerBoltTensionDispDataList[0]
	Sd12 = frame_2_LowerBoltShearDisp_1_DataList[1]
	Sd22 = frame_2_LowerBoltShearDisp_2_DataList[1]
	Td2 = frame_2_LowerBoltTensionDispDataList[1]
	### FAILURE MODE 1 ###
	## empty unity check list ##
	frame_2_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Lower_Bolt_1_UnityCheck = math.sqrt(Sd11**2+Sd21**2) >= dbscr
	frame_2_Lower_Bolt_2_UnityCheck = math.sqrt(Sd12**2+Sd22**2) >= dbscr
	frame_2_Lower_UnityCheckList = [frame_2_Lower_Bolt_1_UnityCheck, frame_2_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Lower_NumberOfFailedBolts = frame_2_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_2_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-LOWER failed at t=%d seconds since the shear strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 2 ###
	## empty unity check list ##
	frame_2_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Lower_Bolt_1_UnityCheck = TF1 >= dbtcr 
	frame_2_Lower_Bolt_2_UnityCheck = TF2 >= dbtcr 
	frame_2_Lower_UnityCheckList = [frame_2_Lower_Bolt_1_UnityCheck, frame_2_Lower_Bolt_2_UnityCheck]  
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Lower_NumberOfFailedBolts = frame_2_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-LOWER failed at t=%d seconds since the tension strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 3 ###
	## empty unity check list ##
	frame_2_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Lower_Bolt_1_UnityCheck = ((math.sqrt(Sd11**2+Sd21**2)/dbscr)+(Td1/(1.4*dbtcr))) >= 1.0 
	frame_2_Lower_Bolt_2_UnityCheck = ((math.sqrt(Sd12**2+Sd22**2)/dbscr)+(Td2/(1.4*dbtcr))) >= 1.0 
	frame_2_Lower_UnityCheckList = [frame_2_Lower_Bolt_1_UnityCheck, frame_2_Lower_Bolt_2_UnityCheck]
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Lower_NumberOfFailedBolts = frame_2_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 bolts failed) ###
	if frame_2_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-LOWER failed at t=%d seconds since the combination of transverse and longitudinal strain is too large' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 4 ###
		## empty unity check list ##
	frame_2_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Lower_Bolt_1_UnityCheck = (math.sqrt(SF11**2+SF21**2)/Fbbrd) >= 1.0 
	frame_2_Lower_Bolt_2_UnityCheck = (math.sqrt(SF12**2+SF22**2)/Fbbrd) >= 1.0 
	frame_2_Lower_UnityCheckList = [frame_2_Lower_Bolt_1_UnityCheck, frame_2_Lower_Bolt_2_UnityCheck] 
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Lower_NumberOfFailedBolts = frame_2_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-LOWER failed at t=%d seconds since the shear force larger than the bearing capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
	### FAILURE MODE 5 ###
	## empty unity check list ##
	frame_2_Lower_UnityCheckList [:] = []
	### checking failure criteria, generating boolean list ###
	frame_2_Lower_Bolt_1_UnityCheck = (TF1/Bbprd) >= 1.0
	frame_2_Lower_Bolt_2_UnityCheck = (TF2/Bbprd) >= 1.0
	frame_2_Lower_UnityCheckList = [frame_2_Lower_Bolt_1_UnityCheck, frame_2_Lower_Bolt_2_UnityCheck]  
	### counting number of 'True' (=failed points) ###
	#- in boolean list unityCheck #
	frame_2_Lower_NumberOfFailedBolts = frame_2_Lower_UnityCheckList.\
		count(True)
	### check failure criteria (2 screws failed) ###
	if frame_2_Lower_NumberOfFailedBolts == 2: 
		### write plateFailure to logfile (debugging) ###
		logging.info (
			'Both bolts of FRAME-2-LOWER failed at t=%d seconds since the tension force larger than the pull-trough capacity of the steel frame' % ( 
				frameCount.frameValue
			)
		)
		### setting panel failure ###
		frame_2_Lower_Failed = 1
		### Break 'frameCount for loop' when plate failed ###
		break
if (frame_1_Upper_Failed and frame_1_Lower_Failed or frame_2_Upper_Failed and frame_2_Lower_Failed or frame_1_Upper_Failed and frame_2_Upper_Failed or frame_1_Lower_Failed and frame_2_Lower_Failed) == 1:
	### write plateFailure data to update-file incl. Failure mode### 
	failureUpdate.write('FACADE %d 4\n' % ( 
			lastFrame.frameValue
		)
	)
	### write plateFailure to logfile (debugging) ###
	logging.info (
		'The whole facade failed at t=%d seconds since the bolts have failed' % ( 
			lastFrame.frameValue
		)
	)
### Finalize and close plateFailureUpdate.temp ###
failureUpdate.write('Done')
failureUpdate.close()	
### Finalize log file ###
logging.info ('Completed')
### output completed message to console ###
print 'Completed, see plateFailurePythonDebug.log for details'	

############################## end-of-script ##############################