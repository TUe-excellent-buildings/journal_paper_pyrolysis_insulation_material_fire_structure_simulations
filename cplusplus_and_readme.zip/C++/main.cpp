///////////////////////////////////////////////////////////////////////////
// Name:        FDS-2-Abaqus                                             //
//                                                                       //
// Description: This program  manages the two-way coupling of a          //
//              CFD Fire Dynamic Simulator (FDS) fire simulation and     //
//              a sequential coupled FE Abaqus Heat Transfer (HT) and    //
//              Structural Response (SR) analysis. In its current state  //
//              FDS-2-Abaqus is limited to analyzing structures          //
//              consisting of multiple plate-instances using a stress-   //
//              based failure criteria.  The number of plates,           //
//              temperature partitions, simulation duration, iteration   //
//              size, and failure criteria can be varied freely (as      //
//              long as required FDS and Abaqus basic model setups       //
//              are supplied). Basically the programs iterates through   //
//              various one way coupled CFD-FEM analyses. After every    //
//              iteration the program checks plate failure based on      //
//              user-defined stress failure criteria. If failure occurs  //
//              the plates are removed from the models (FDS and Abaqus)  //
//              for the next iteration. The overview of plate failure    //
//              and failure time points is written to _plateFailure.log. //
//                                                                       //
// Input:       plateFailureUpdate.temp							         //
//                                                                       //
// Output:      _plateFailure.log                                        //
//              _iterationCounter.temp                                   //
//              _platePartitionCounter.temp                              //
//              _runIterationTemp.bat                                    //
//              plateFailureInputVariables.py                            //
//                                                                       //
// Required     numberOfPlates          (user console input)             //
// Parameters:  numberOfPartitions      (user console input)             //
//              totalSimulationDuration (user console input)             //
//              iterationSize           (user console input)             //
//              failureStrain           (user console input)             //
//              failureNumberOfPoints   (user console input)             //
//              failureNumberOfElements (user console input)             //
//              failedPlateNumber                                        //
//              failureTimePoint                                         //
///////////////////////////////////////////////////////////////////////////
// Version 3.0                                           by Qingfeng Xu  //
// August 2021                                       xqf0620@outlook.com //
///////////////////////////////////////////////////////////////////////////

/////////////////////////////// Begin Code ////////////////////////////////

// Import Libraries //
#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <stdlib.h>
#include <windows.h>
#include <iomanip>
#include <regex>
#include <limits>

// Import boost Libraries //
#include <boost/lexical_cast.hpp>

// Define String Parameters //
// output filename to (temporary) store iteration data //
// used in: upGeomFDS, upGeomHT, upGeomSR,
std::string counterFileName = "_iterationCounter.temp";
// output filename to (temporary) store plate/partition info //
// used in: reWriteAST2py, upGeomHT, upGeomSR
std::string platePartitionFileName = "_platePartitionInfo.temp";
// filename for (temporary) batch file containing program //
// sequence for single iteration loop                     //
std::string batchScriptFileName = "_runIterationTemp.bat";
// output filename for log managing plate failure //
// used in: upGeomFDS, upGeomHT, upGeomSR         //
std::string plateFailureFileName = "_plateFailure.log";
// input filename containing possible plate failure        //
// for current iteration (managed by PlateFailureCheck.py) //
std::string updatePlateFailureFileName = "plateFailureUpdate.temp";
// output filename for storing input variables for checking failure //
// used in: PlateFailureCheck.py                                    //
std::string plateFailureInputVariablesFileName =
    "plateFailureInputVariables.py";
// inputString to store line from updatePlateFailureFilename //
std::string inputString;
// input file name for storing FailureInputVariables //
// used in : upGeomSR //
std::string FailureInputVariablesFileName = "_FailureInputVariables.temp";

// filename strings for verification if required files exist //
std::string upGeomFDS = "upGeomFDS.exe";
std::string fdsBasicSetup = "FDS_BasicSetup.fds";
std::string reWriteAST2py = "reWriteAST2py.exe";
std::string UMATHT_HT = "_UMATHT_HT.for";
std::string USDFLD_SR = "_USDFLD_SR.for";
std::string upGeomHT = "upGeomHT.exe";
std::string htBasicModel= "HT_basicModel.py";
std::string upGeomSR = "upGeomSR.exe";
std::string srBasicModel = "SR_basicModel.py";
std::string plateFailureCheck = "PlateFailureCheck.py";
std::string bucImperfectionFil = "_outputSR\\i0_buc-Job.fil";
std::string bucImperfectionPrt = "_outputSR\\i0_buc-Job.prt";
std::string exists = "Exists!";
std::string missing = "Missing!";

// Define Integer Parameters //
// numberOfPlates, user input see function request_basic_variables //
int numberOfPlates(3);
// numberOfPartitions, user input see function request_basic_variables //
int numberOfPartitions(16);
// totalSimulationDuration, user input see func. request_basic_variables //
int totalSimulationDuration(50);
// iterationSize, user input see function request_basic_variables //
int iterationSize(10);
// iterationCounter starts at 0 (zeroth iteration) //
int iterationCounter(0); // do not edit //
// arrayCounter to be used in for loops iterating through //
// array managing _plateFailure.log info                  //
int arrayCounter(0);
// Plate/Instance number of failed plate //
// read from plateFailureFileName        //
int failedPlateNumber(0);
// failure time point for plate 'failedPlateNumber' //
// read from plateFailureFileName        //
int failureTimePoint(0);
// Panel/instance number of plates which opened (failure mode 2) //
// read from plateFailureFileName       //
int openedPlateNumber1 (0);
int openedPlateNumber2 (0);
// Failure mode in screw or bolt failure modes //
// read from plateFailureFileName       //
int failureMode (0);
// Counter managing number of failed plates //
int numberOfFailedPlates(0);
// Failure modes do need some variables. The critical //
// failure value will be calculated by FDS-2-Abaqus //
// Failure mode 1 needs the length of the Panels //
double lengthOfPanels(3.6);
// and the thickness of the panels //
double thicknessOfPanels(0.08);
// For the second failure mode, the geometry should be known //
double lenghtOverlap(0.0046);
// third failure mode exist out of a few screw failure modes//
// several variables should be known //
double screwDiameter(5.5);
double screwArea(13.9);
double ultimateStrengthScrew(800);
// variables of the weakest structural element //
int ultimateStrengthScrewSupport(510);
double thicknessOfScrewSupport(3);
// Last failure mode exists out of a few bolt failure modes//
double boltDiameter(14);
double boltArea(114.9);
int ultimateStrengthBolt(800);
double washerDiameter (24);
// support structure //
int ultimateStrengthBoltSupport(510);
double thicknessOfBoltSupport(3);



// Define char variables //
// choice char for selecting/storing yes/no questions //
char choice;

// function requesting input to continue //
// 'pause' function                      //
void press_enter_to_continue()
{
    std::cin.clear();
    std::cout << "Press ENTER to continue...";
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

// function to print banner logo to console //
void print_banner_to_console()
{
    // ASCII Title-Art //
    std::cout << '\n';
    std::cout << "    )     "
        << " __ __  __     __                        "
        << "    )   " << '\n';
    std::cout << "   ) \\    "
        << "|_ |  \\(_  __   _) __  /\\ |_  _  _     _ "
        << "   ) \\  " << '\n';
    std::cout << "  / ) (   "
        << "|  |__/__)     /__    /--\\|_)(_|(_||_|_) "
        << "  / ) ( " << '\n';
    std::cout << "  \\(_)/   "
        << "                                  |      "
        << "  \\(_)/ " << '\n';
    std::cout << '\n';
    // Version and Author Info //
    std::cout << "Version 3.0                                   "
        << "by Qingfeng Xu" << '\n';
    std::cout << "October 2021                             "
        << "xqf0620@outlook.com" << '\n';
    std::cout << '\n';
}

// function to print banner and introductory info to console //
// NOTE: maximum characters on line = 60 //
void welcome_world()
{
    print_banner_to_console();
    std::cout << "[ [ [Description] ] ]" << '\n'
    << "FDS-2-Abaqus manages the two-way coupling of a CFD Fire " << '\n'
    << "Dynamic Simulator (FDS) fire simulation and a sequential "<< '\n'
    << "coupled FEM Abaqus Heat Transfer (HT) and Structural " << '\n'
    << "Response (SR) analysis." << '\n' << '\n';
    std::cout << "[ [ [Checking Required Files] ] ]" << '\n'
    << "FDS-2-Abaqus will now check if all required files are " << '\n'
    << "supplied. If any are MISSING verify file(name)s and paths!" <<'\n';
    press_enter_to_continue();
    std::cout << '\n';
}

// function to check if file exists or are missing //
std::string check_file_existence(const std::string& name)
{
    if (FILE *file = fopen(name.c_str(), "r")){
        fclose(file);
        return exists;
    }
    else{
        return missing;
    }
}

void verify_existence_required_files()
{
    std::cout << "[ [ [Required Programs] ] ]" << '\n'
        << "reWriteAST2py.exe       "
        << check_file_existence(reWriteAST2py) << '\n'
        << "upGeomFDS.exe           "
        << check_file_existence(upGeomFDS) << '\n'
        << "upGeomHT.exe            "
        << check_file_existence(upGeomHT) << '\n'
        << "upGeomSR.exe            "
        << check_file_existence(upGeomSR) << '\n';
    std::cout << "[ [ [Required Scripts] ] ]" << '\n'
        << "FDS_BasicSetup.fds      "
        << check_file_existence(fdsBasicSetup) << '\n'
        << "HT_basicModel.py        "
        << check_file_existence(htBasicModel) << '\n'
        << "SR_basicModel.py        "
        << check_file_existence(srBasicModel) << '\n'
        << "PlateFailureCheck.py    "
        << check_file_existence(plateFailureCheck) << '\n';
    std::cout << "[ [ [Required Buckling File] ] ]" << '\n'
        << "i0_buc-Job.fil          "
        << check_file_existence(bucImperfectionFil) << '\n'
        << "i0_buc-Job.prt          "
        << check_file_existence(bucImperfectionPrt) << '\n'
        << "(in \\_outputSR\\ folder)" << '\n';
    std::cout << '\n';
}

// function to ask user to select yes (Y or y) or no (N or n) //
// and return the selected answer                             //
char select_yes_no()
{
    std::cin >> choice;
    if (choice != 'y' && choice != 'Y' && choice != 'n' && choice != 'N'){
        std::cout << "Please select [y/n]: ";
        select_yes_no();
    }
    // return choice to caller //
    return choice;
}

// function to request input and verify if it is an integer //
int request_and_verify_value(int someInteger)
{
    // request integer input //
    std::cin >> someInteger;
    // verify/check if input is integer //
    while(std::cin.fail()){
        std::cin.clear();
        std::cin.ignore(9999, '\n');
        std::cout << "Error: not an integer, try again!" << '\n';
        std::cin >> someInteger;
    }
    // return the integer to caller //
    return someInteger;
}
// function to request input and verify if it is an integer //
double request_and_verify_value_double(double someDouble)
{
    // request integer input //
    std::cin >> someDouble;
    // verify/check if input is integer //
    while(std::cin.fail()){
        std::cin.clear();
        std::cin.ignore(9999, '\n');
        std::cout << "Error: not an integer, try again!" << '\n';
        std::cin >> someDouble;
    }
    // return the integer to caller //
    return someDouble;
}
void create_FailureInputVariables_temp_file()
{
    // create output stream to temporary FailureInputVariables info file //
    // used to calculate connector stiffnesses, plasticity //
    // and making thickness of the panels, screw and bolt sizes parametric //
    std::ofstream FailureInputVariables(FailureInputVariablesFileName);
    // write all input variables to info file //
    FailureInputVariables << lengthOfPanels << " " << thicknessOfPanels << " " << lenghtOverlap << " "
        << screwDiameter << " " << screwArea << " " << ultimateStrengthScrew << " "
        << ultimateStrengthScrewSupport << " " << thicknessOfScrewSupport << " "
        << boltDiameter << " " << boltArea << " " << ultimateStrengthBolt << " "
        << washerDiameter << " " << ultimateStrengthBoltSupport << " " << thicknessOfBoltSupport
        << '\n' << "lengthOfPanels[m] thicknessOfPanels[m] lengthOverlap[m] screwDiameter[mm]"
        << "screwArea[mm^2] ultimateStrengthScrew[N/mm^2] ultimateStrengthScrewSupport[N/mm^2]"
        << " thicknessOfScrewSupport[mm] boltDiameter[mm] boltArea[mm^2] ultimateStrengthBolt[N/mm^2]"
        << " washerDiameter[mm] ultimateStrengthBoltSupport[N/mm^2] thicknessOfBoltSupport[mm]";
    // close output stream //
    FailureInputVariables.close();
}
// function to create temporary platePartition info file //
void create_plate_partition_temp_file()
{
    // create output stream to temporary platePartition-file //
    std::ofstream platePartitionTemp(platePartitionFileName);
    // write plate and partition info to platePartition-file //
    platePartitionTemp << numberOfPlates << " " << numberOfPartitions
        << '\n' << "numberOfPlates[#] numberOfPartitions (per plate) [#]";
    // close output stream //
    platePartitionTemp.close();
    // NOTE: file is removed in function remove_temp_files() //
}

// function to create temporary iteration info file //
void update_iteration_temp_file()
{
    // create output stream to temporary iteration-file //
    std::ofstream iterationTemp(counterFileName);
    // write iteration-info to iteration-file //
    iterationTemp << iterationCounter << " " << iterationSize << " "
        << totalSimulationDuration << '\n'
        << "iterationNumber[#] iterationSize[s] totalSimulationTime[s]";
    // close output stream //
    iterationTemp.close();
    // NOTE: file is removed in function remove_temp_files() //
}

// function to print plate failure array to file                   //
// this array manages plate failure data throughout whole coupling //
void print_plate_failure_log_file(int myArray[][4])
{
    // open output stream to plateFailureFileName //
    // NOTE: overwrites already existing file     //
    std::ofstream plateFailureLog(plateFailureFileName);
    // print array to file (row by row) //
    for (arrayCounter = 0; arrayCounter < numberOfPlates; arrayCounter++){
        plateFailureLog
            // write plate number    //
            << myArray[arrayCounter][0] << " "
            // write failure boolean //
            << myArray[arrayCounter][1] << " "
            // write failure time    //
            << myArray[arrayCounter][2] << " "
            // write failure mode
            << myArray[arrayCounter][3]<<'\n';
    }
    // close output stream //
    plateFailureLog.close();
}

// function to create plate failure array of size [numberOfPlates][3] //
// this array manages plate failure data throughout whole coupling    //
void create_plate_failure_log_file(int myArray[][4])
{
    // number each cells of first column from 1 to numberOfPlates //
    for (arrayCounter = 0; arrayCounter < numberOfPlates; arrayCounter++){
        myArray[arrayCounter][0] = {arrayCounter + 1};
    }
    // print/output the plateFailureArray to file (see function above) //
    print_plate_failure_log_file(myArray);
}

// function to update plate failure log file by reading  plate number //
// and failure time from plateFailureUpdate.temp                      //
void update_plate_failure_log_file(int myArray[][4])
{
    // create input stream from failure-update-file //
    std::ifstream sourceFile(updatePlateFailureFileName);
    // print error if update-file can't be read/located //
    if (!sourceFile){
        std::cerr << "Uh oh, panel failure update file "
            << updatePlateFailureFileName
            << " could not be opened or does not exist!" << '\n';
        press_enter_to_continue();
        exit(1);
    }
    // definition of regular expression required to capture //
    // plate (instance) number and failure time point from  //
    // plateFailureUpdate.temp                              //
    const std::regex instanceStrAndIntFM1
        ("\\D*\\s*(\\d+)\\s+(\\d+)\\s+(\\d+)\\.*\\d*");
    const std::regex instanceStrAndIntFM2
        ("\\D*\\s*(\\d+)\\s+\\D+\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\.*\\d*");
    const std::regex instanceStrAndIntFM3
        ("\\D*\\s*(\\d+)\\s+(\\d+)\\s+(\\d+)\\s+(\\d+)\\.*\\d*");
    const std::regex instanceStrAndIntFM4
        ("\\D*\\s*(\\d+)\\s+(\\d+)\\.*\\d*");
    // while end of file isn't reached do this //
    while(!sourceFile.eof()){
        // get line and put the line in the string inputString //
        getline(sourceFile, inputString);
        // break (end) while loop if getline reads Done //
        if (inputString == "Done"){
            std::cout << "Failure Check Completed!" << '\n' << '\n';
            break;
        }
        // if input string matches regular expression //
        // FAILURE MODE 1 //
        else if(std::regex_match(inputString, instanceStrAndIntFM1)){
            // match (string) results into stringMatch //
            std::smatch stringMatch;
            if (std::regex_search(inputString, stringMatch,
            instanceStrAndIntFM1)){
                // cast obtained 'strings' as integers //
                failedPlateNumber =
                    boost::lexical_cast<int>(stringMatch[1]);
                failureTimePoint =
                    boost::lexical_cast<int>(stringMatch[2]) +
                    (iterationCounter * iterationSize);
                // output plateFailure to console //
                std::cout << "! ! ! F A I L U R E ! ! !" << '\n'
                    << "Panel " << failedPlateNumber
                    << " Failed @ " << failureTimePoint << " seconds" << '\n'
                    << "since the deflection is too large"
                    << '\n';
                // print error if an already failed plate fails again //
                if (myArray[failedPlateNumber - 1][1] == 1){
                    std::cerr << "Error! An already Failed Panel, "
                        <<"Failed Again. This should not happen!" << '\n'
                        <<"Please check scripts/models!";
                    exit(1);
                }
                // update plateFailureArray for this itteration //
                // write failure boolean and failureTimePoint   //
                myArray[failedPlateNumber - 1][1] = 1;
                myArray[failedPlateNumber - 1][2] = failureTimePoint;
                myArray[failedPlateNumber - 1][3] = 1;
                numberOfFailedPlates++;
                // continue with while loop //
                continue;
            }
        }
        // if input string matches regular expression  //
        // FAILURE MODE 2 //
        else if(std::regex_match(inputString, instanceStrAndIntFM2)){
            // match (string) results into stringMatch //
            std::smatch stringMatch;
            if (std::regex_search(inputString, stringMatch,
            instanceStrAndIntFM2)){
                // cast obtained 'strings' as integers //
                openedPlateNumber1 =
                    boost::lexical_cast<int>(stringMatch[1]);
                openedPlateNumber2 =
                    boost::lexical_cast<int>(stringMatch[2]);
                failureTimePoint =
                    boost::lexical_cast<int>(stringMatch[3]) +
                    (iterationCounter * iterationSize);
                // output plateFailure to console //
                std::cout << "! SMALL OPENING OCCURS !" << '\n'
                    << "Between Panel " << openedPlateNumber1 << "and Panel " << openedPlateNumber2 << '\n'
                    << " Occurs @ " << failureTimePoint << " seconds"
                    << '\n';
                // update plateFailureArray for this iteration //
                // Will not be updated, nothing happens in fire simulation   //
                myArray[openedPlateNumber1 - 1][3] = 2;
                myArray[openedPlateNumber2 -1][3] = 2;
                continue;
            }
        }
        // if input string matches regular expression  //
        // FAILURE MODE 3 //
        else if(std::regex_match(inputString, instanceStrAndIntFM3)){
            // match (string) results into stringMatch //
            std::smatch stringMatch;
            if (std::regex_search(inputString, stringMatch,
            instanceStrAndIntFM3)){
                // cast obtained 'strings' as integers //
                failedPlateNumber =
                    boost::lexical_cast<int>(stringMatch[1]);
                failureTimePoint =
                    boost::lexical_cast<int>(stringMatch[2]) +
                    (iterationCounter * iterationSize);
                failureMode =
                    boost::lexical_cast<int>(stringMatch[4]);
                // output plateFailure to console //
                std::cout << "! ! ! S C R E W   F A I L U R E ! ! !" << '\n'
                    << "of Panel " << failedPlateNumber
                    << " Failed @ " << failureTimePoint << " seconds" << '\n';
                // print error if an already failed plate fails again //
                if (myArray[failedPlateNumber - 1][1] == 1){
                    std::cerr << "Error! An already Failed Panel, "
                        <<"Failed Again. This should not happen!" << '\n'
                        <<"Please check scripts/models!";
                    exit(1);
                }
                else if (failureMode == 1){
                    std::cout << "since the shear force is larger than" << '\n'
                        << "the shear design resistance of the screws"
                        << '\n';
                }
                else if (failureMode == 2){
                    std::cout << "since the tension force is larger than" << '\n'
                        << "the tension design resistance of the screws"
                        << '\n';
                }
                else if (failureMode == 3){
                    std::cout << "since the combination of the shear and tension force is" << '\n'
                        << "larger than the combination design resistance of the screws"
                        << '\n';
                }
                else if (failureMode == 4){
                    std::cout << "since the shear force is larger than" << '\n'
                        << "the design bearing capacity of the steel frame"
                        << '\n';
                }
                else if (failureMode == 5){
                    std::cout << "since the tension force is larger than" << '\n'
                        << "the design pull-out resistance of the steel frame"
                        << '\n';
                }
                // update plateFailureArray for this itteration //
                // write failure boolean and failureTimePoint   //
                myArray[failedPlateNumber - 1][1] = 1;
                myArray[failedPlateNumber - 1][2] = failureTimePoint;
                myArray[failedPlateNumber -1] [3] = 3;
                numberOfFailedPlates++;
                // continue with while loop //
                continue;
            }
        }
        // if input string matches regular expression  //
        // FAILURE MODE 4 //
        else if(std::regex_match(inputString, instanceStrAndIntFM4)){
            // match (string) results into stringMatch //
            std::smatch stringMatch;
            if (std::regex_search(inputString, stringMatch,
            instanceStrAndIntFM4)){
                // cast obtained 'strings' as integers //
                failureTimePoint =
                    boost::lexical_cast<int>(stringMatch[1]) +
                    (iterationCounter * iterationSize);
                failureMode =
                    boost::lexical_cast<int>(stringMatch[2]);
                // output plateFailure to console //
                std::cout << "! ! ! B O L T   F A I L U R E ! ! !" << '\n'
                    << "The whole facade will fail within " << failureTimePoint << " seconds" << '\n'
                    << "because the facade system will not be fixed " << '\n' << "to the main structure anymore." << '\n';
                // update plateFailureArray for this itteration //
                // write failure boolean and failureTimePoint to all plates  //
                for (int rowCounter = 0; rowCounter < numberOfPlates; rowCounter++){
                    myArray[rowCounter][1] = 1;
                    myArray[rowCounter][2] = failureTimePoint;
                    myArray[rowCounter][3] = 4;

                }
                numberOfFailedPlates = numberOfPlates;
                // continue with while loop //
                continue;

            }


        }
    }

    // close input stream //
    sourceFile.close();
    // print/output the plateFailureArray to file //
    print_plate_failure_log_file(myArray);
}

// function to request basic values from user and some verification //
void request_basic_variables()
{
    std::cout << "[ [ [ Request Input Variables] ] ]" << '\n'
    << "FDS-2-Abaqus will now request some basic input variables." << '\n'
    << "Make sure the numberOfPlates and numberOfPartitions agree " << '\n'
    << "with the variables defined in the basicModel input files " << '\n'
    << "and scripts (3 facade panels and 16 partitions per panel)." << '\n' << '\n';
    std::cout << "[ [ [Basic Model Info] ] ]"  << '\n';
    // request numberOfPlates //
    std::cout << "Please enter the number of panels [#]: ";
    numberOfPlates = request_and_verify_value(numberOfPlates);
    // request numberOfTemperaturePartitions //
    std::cout << "Please enter the number of temperature " << '\n'
        << "partitions for each panel [#]: ";
    numberOfPartitions = request_and_verify_value(numberOfPartitions);
    // request totalSimulationDuration and iterationSize and verify //
    // if totalsimulationDuration > iterationSize                   //
    do{
        if (iterationSize > totalSimulationDuration){
            std::cout << "Error! iteration size larger than total "
                << "simulation duration, try again!" << '\n';
        }
        // request totalSimulationDuration //
        std::cout << "Please enter the total simulation duration [s]: ";
        totalSimulationDuration =
            request_and_verify_value(totalSimulationDuration);
        // request iterationSize //
        std::cout << "Please enter the iteration size [s]: ";
        iterationSize = request_and_verify_value(iterationSize);
    }
    while (iterationSize > totalSimulationDuration);
    // list selected values //
    std::cout << '\n' << "You selected the values listed below:" << '\n'
        << "Number of Panels = " << numberOfPlates << " panel(s)" << '\n'
        << "Number of Temperature Partitions (per panel) = "
        << numberOfPartitions << " partition(s)" << '\n'
        << "Total Simulation Duration = " << totalSimulationDuration
        << " seconds" << '\n'
        << "Iteration Size = " << iterationSize << " seconds" << '\n'
        << '\n';
    // ask user if selected input is correct //
    std::cout << "are these values correct [y/n]? ";
    select_yes_no();
    // if no -> request new input ('restart function') //
    if (choice == 'n' || choice == 'N'){
        std::cout << '\n';
        request_basic_variables();
    }
    // if yes -> continue //
    else if (choice == 'y' || choice == 'Y'){
        std::cout << '\n';
        // nothing really happens here //
    }
    // this should never happen, only y,Y,n, or N can be returned //
    else{
        std::cerr << "This should never happen only [y/n] is returned";
        press_enter_to_continue();
        exit(1);
    }
}

// function to list 'standard' failure parameters and the possibility //
// to change these parameters                                         //
void update_failure_criteria()
{
    // list standard values //
    std::cout << "[ [ [Failure Criteria] ] ]"  << '\n'
        << "Panels:" << '\n'
        << "Length of the facade panels = " << lengthOfPanels << " m" << '\n'
        << "Thickness of the facade panels = " << thicknessOfPanels << " m" << '\n'
        << "Overlap of the facade panels (locking system) = " << lenghtOverlap << " m" << '\n'
        << '\n' << "Screws:" << '\n'
        << "Diameter of the screw = " << screwDiameter << " mm" << '\n'
        << "Tensile area of the screw = " << screwArea << " mm^2" << '\n'
        << "Ultimate tensile strength of the screw = " << ultimateStrengthScrew << " N/mm^2" << '\n'
        << "Ultimate tensile strength of the support element = " << ultimateStrengthScrewSupport << " N/mm^2" << '\n'
        << "Thickness of the support element = " << thicknessOfScrewSupport << " mm" << '\n'
        << '\n' << "Bolts:" << '\n'
        << "Diameter of the bolt = " << boltDiameter << " mm" << '\n'
        << "Tensile area of the screw = " << boltArea << " mm^2" << '\n'
        << "Ultimate tensile strength of the bolt = " << ultimateStrengthBolt << " N/mm^2" << '\n'
        << "Diameter of the washer = " << washerDiameter << " mm" << '\n'
        << "Ultimate tensile strength of the support element = " << ultimateStrengthBoltSupport << " N/mm^2" << '\n'
        << "Thickness of the support element = " << thicknessOfBoltSupport << " mm" << '\n';
    // ask user if standard input is correct //
    std::cout << '\n' << "are these values correct [y/n]? ";
    select_yes_no();
    // if no ask user for new failure input //
    if (choice == 'n' || choice == 'N'){
        std::cout << '\n';
        std::cout << "[ [ [Failure Criteria] ] ]" << '\n';
        // request panel variables to calculate critical failure value //
        std::cout << "Please enter the thickness of the facade panels in [m]: ";
        thicknessOfPanels = request_and_verify_value_double(thicknessOfPanels);
        std::cout << "Please enter the overlap of the facade panels (locking system) in [m]: ";
        lenghtOverlap = request_and_verify_value_double(lenghtOverlap);
        // request variables of screw failure modes //
        std::cout << "Screws:" << '\n'<< "Please enter the diameter of the screw in [mm]: ";
        screwDiameter = request_and_verify_value_double(screwDiameter);
        std::cout << "Please enter the area of the screw in [mm^2]: ";
        screwArea = request_and_verify_value_double(screwArea);
        std::cout << "Please enter the ultimate tensile strength of the screw in [N/mm^2]: ";
        ultimateStrengthScrew = request_and_verify_value_double(ultimateStrengthScrew);
        std::cout << "Please enter the ultimate tensile strength of the support element in [N/mm^2]: ";
        ultimateStrengthScrewSupport = request_and_verify_value(ultimateStrengthScrewSupport);
        std::cout << "Please enter the thickness of the support element in [mm]: ";
        thicknessOfScrewSupport = request_and_verify_value_double(thicknessOfScrewSupport);
        // request variables of bolt failure modes //
        std::cout << "Bolts:" << '\n'<< "Please enter the diameter of the bolt in [mm]: ";
        boltDiameter = request_and_verify_value_double(boltDiameter);
        std::cout << "Please enter the area of the bolt in [mm^2]: ";
        boltArea = request_and_verify_value_double(boltArea);
        std::cout << "Please enter the ultimate tensile strength of the bolt in [N/mm^2]: ";
        ultimateStrengthBolt = request_and_verify_value(ultimateStrengthBolt);
        std::cout << "Please enter the diameter of the washer in [mm^2]: ";
        washerDiameter = request_and_verify_value_double(washerDiameter);
        std::cout << "Please enter the ultimate tensile strength of the support element in [N/mm^2]: ";
        ultimateStrengthBoltSupport = request_and_verify_value(ultimateStrengthBoltSupport);
        std::cout << "Please enter the thickness of the support element in [mm]: ";
        thicknessOfBoltSupport = request_and_verify_value_double(thicknessOfBoltSupport);
        std::cout << '\n' << "You selected the values listed below: "
            << '\n';
        // write values to plateFailureInputVariables.py //
        update_failure_criteria();
    }
    // if yes -> continue //
    else if (choice == 'y' || choice == 'Y'){
        std::cout << std::endl;
            // final check before running simulation //
        std::cout << "[ [ [ Final Check ] ] ]" << '\n'
        << "FDS-2-Abaqus is now ready to begin the coupling procedure!"
        << '\n'
        << "Select YES [y] to start the coupling simulation, select "
        << '\n'
        << "NO [n] to re-enter input variables." << '\n' << '\n'
        << "Start Simulation?: ";
        // selecting NO allows user to re-enter input variables //
        select_yes_no();
        if (choice == 'n' || choice == 'N'){
            std::cout << '\n';
            request_basic_variables();
            update_failure_criteria();
        }
    }
    // this should never happen, only y,Y,n, or N can be returned //
    else{
        std::cerr << "This should never happen only [y/n] is returned";
        press_enter_to_continue();
        exit(1);
    }
}

// function to write plateFailureInputVariables.py script //
// containing failure info for current iteration.         //
// input for plateFailureCheck.py                         //
void update_plate_failure_input_variables_py()
{
    std::ofstream plateFailureVar(plateFailureInputVariablesFileName);
    plateFailureVar << "## input variables for PlateFailureCheck.py"
        << '\n' << "## Generated by FDS-2-Abaqus" << '\n';
    plateFailureVar << "# Failure Criteria" << '\n'
        << "lengthOfPanels = " << lengthOfPanels << '\n'
        << "thicknessOfPanels = " << thicknessOfPanels << '\n'
        << "lengthOverlap = " << lenghtOverlap << '\n'
        << "screwDiameter = " << screwDiameter << '\n'
        << "screwArea = " << screwArea << '\n'
        << "ultimateStrengthScrew = " << ultimateStrengthScrew << '\n'
        << "ultimateStrengthScrewSupport = " << ultimateStrengthScrewSupport << '\n'
        << "thicknessOfScrewSupport = " << thicknessOfScrewSupport << '\n'
        << "boltDiameter = " << boltDiameter << '\n'
        << "boltArea = " << boltArea << '\n'
        << "ultimateStrengthBolt = " << ultimateStrengthBolt << '\n'
        << "washerDiameter = " << washerDiameter << '\n'
        << "ultimateStrengthBoltSupport = " << ultimateStrengthBoltSupport << '\n'
        << "thicknessOfBoltSupport = " << thicknessOfBoltSupport << '\n';
    plateFailureVar << "# Input Files and Path" << '\n'
        << "jobname = 'i" << iterationCounter << "_SR-Job'" << '\n'
        << "stepname = 'i" << iterationCounter << "_SR-Step'" << '\n'
        << "path = '_outputSR/'" << '\n'
        << "myOdbPath = path + jobname + '.odb'" << '\n';
}

// batch file executing the various programs and scripts //
// required for a single iteration loop                  //
void create_temp_batch_file()
{
    // create output stream to temp batch file //
    std::ofstream tempBatch(batchScriptFileName);
    // if all plates failed only FDS simulation should continue //
    if (numberOfFailedPlates >= numberOfPlates){
        tempBatch << "call upGeomFDS.exe" << '\n';
        tempBatch << "call fds fds_script.fds" << '\n';
    }
    // write batch (*bat) file for normal iteration loop //
    else{
        tempBatch << "call upGeomFDS.exe" << '\n';
        tempBatch << "call fds fds_script.fds" << '\n';
        tempBatch << "call reWriteAST2Py.exe" << '\n';
        tempBatch << "call upGeomHT.exe" << '\n';
        tempBatch << "call abaqus cae noGUI=HT_Script.py" << '\n';
        tempBatch << "call upGeomSR.exe" << '\n';
        tempBatch << "call abaqus cae noGUI=SR_Script.py" << '\n';
        tempBatch << "call abaqus cae noGUI=PlateFailureCheck.py" << '\n';
    }
    // close output stream //
    tempBatch.close();
}

// function to call batch command //
// NOTE: works only for windows! //
void run_next_iteration()
{
    //execute bat file
    SHELLEXECUTEINFO shellExWaitCompletion = {0};
    shellExWaitCompletion.cbSize = sizeof(SHELLEXECUTEINFO);
    shellExWaitCompletion.fMask = SEE_MASK_NOCLOSEPROCESS;
    shellExWaitCompletion.hwnd = NULL;
    shellExWaitCompletion.lpVerb = NULL;
    shellExWaitCompletion.lpFile = batchScriptFileName.c_str();
    shellExWaitCompletion.lpParameters = "";
    shellExWaitCompletion.lpDirectory = NULL;
    shellExWaitCompletion.nShow = SW_SHOW;
    shellExWaitCompletion.hInstApp = NULL;
    ShellExecuteEx(&shellExWaitCompletion);
    WaitForSingleObject(shellExWaitCompletion.hProcess,INFINITE);
}

// function to output current iteration info to console //
void print_current_iteration_info()
{
        std::cout << "[ [ [Starting Iteration #" << iterationCounter
            << "] ] ]" << '\n' << "# IterationTimeSlot: "
            << (iterationCounter * iterationSize) << "-"
            << ((iterationCounter + 1) * iterationSize) << "s" << '\n'
            << "TotalSimulationDuration: " << totalSimulationDuration
            << "s." << '\n';
}

// function to only iterate FDS simulation //
// this is called when ALL plates FAILED   //
void iterate_fds_only()
{
    // output all-plates-failed failure message //
    std::cout << "The whole facade has failed, only finalizing "
        << "FDS Fire Simulation" << '\n';
    // update iteration batch file to only iterate FDS //
    create_temp_batch_file();
    // while loop finalizing simulation (fds only) //
    while (iterationCounter * iterationSize < totalSimulationDuration){
        print_current_iteration_info();
        update_iteration_temp_file();
        run_next_iteration();
        iterationCounter++;
    }
}

// function to clean up some temporary files //
void remove_temp_files()
{
    std::remove(counterFileName.c_str());
    std::remove(platePartitionFileName.c_str());
    std::remove(batchScriptFileName.c_str());
    std::remove(plateFailureInputVariablesFileName.c_str());
    std::remove(updatePlateFailureFileName.c_str());
}

// function to output starting info to console //
void print_start_coupling_analysis()
{
    std::cout << "[ [ [ S T A R T I N G   C O U P L I N G   "
        << "A N A L Y S I S ] ] ]" << '\n' << '\n';
}

// function to output completion info to console //
void print_completion_info_and_failureArray(int myArray[][4])
{
    std::cout << "[ [ [ C O U P L I N G   A N A L Y S I S   "
        << "C O M P L E T E D ] ] ]" << '\n';
    print_banner_to_console();
     // Simulation Overview/Summary //
    std::cout << "[ [ [Overview of Failed Plates] ] ] " << '\n'
        << "Number of Panels: " << numberOfPlates << '\n'
        << "Number of Failed Panels: " << numberOfFailedPlates << '\n';
    for (arrayCounter = 0; arrayCounter < numberOfPlates; arrayCounter++){
        if (myArray[arrayCounter][1] == 1){
            if (myArray[arrayCounter][3] == 1){
                std::cout << "Panel " << myArray[arrayCounter][0]
                    << " Failed @ " << myArray[arrayCounter][2]
                    << " seconds since the deflection is too large" << '\n';
            }
            else if (myArray[arrayCounter][3] == 3){
                std::cout << "Panel " << myArray[arrayCounter][0]
                    << " Failed @ " << myArray[arrayCounter][2]
                    << " seconds since both screws of the panel failed" << '\n';
            }
            else if (myArray[arrayCounter][3] == 4){
                std::cout << "The whole facade failed within "
                    << myArray[arrayCounter][2]
                    << " seconds" << '\n'
                    << " since the bolts failed and the facade will not be connected" << '\n'
                    << " to the main structure anymore" << '\n';
            }
        }
        else if (myArray[arrayCounter][3] == 2){
            std::cout << "There will be a small opening at the top/bottom of Panel " << myArray[arrayCounter][0];
        }
    }
    std::cout << '\n'
        << "NOTE: Always check FDS (*.out) and Abaqus (*.msg)" << '\n'
        << "      files for possible errors!" << '\n';
    std::cout << '\n' << "[ [ [ Thank You For Using FDS-2-Abaqus ] ] ]"
        << '\n';
    press_enter_to_continue();
    press_enter_to_continue();
}

int main()
{
    // welcome and introductory info //
    welcome_world();
    // check if required files exist (in path) //
    verify_existence_required_files();
    // request #panels, #partition, sim. duration, and iteration size //
    request_basic_variables();
    // check and/or request failure criteria //
    update_failure_criteria();
    // create temporary FailureInputVariables file for upGeomSR //
    create_FailureInputVariables_temp_file();
    // create temporary platePartition file //
    create_plate_partition_temp_file();
    // define plateFailureArray                              //
    // this is defined here since numberOfPlates is required //
    int plateFailureArray[numberOfPlates][4] = {0};
    // create plate failure log file //
    create_plate_failure_log_file(plateFailureArray);
    // create batch file executing the various programs and scripts //
    // for a single iteration loop                                  //
    create_temp_batch_file();
    // Just a banner (time stamps should be included)
    print_start_coupling_analysis();
    // while loop iterating through all steps in //
    // the fully coupled simulation              //
    while(iterationCounter * iterationSize < totalSimulationDuration){
        if (numberOfFailedPlates >= numberOfPlates){
            iterate_fds_only();
            break;
        }
        // output current iteration info to console //
        print_current_iteration_info();
        // update current iteration to temporary file //
        update_iteration_temp_file();
        // update input variables for plateFailureCheck.py //
        // plateFailureCheck.py checks plate failure       //
        update_plate_failure_input_variables_py();
        // run batch file executing the various programs and scripts //
        run_next_iteration();
        // update and print _plateFailure.log //
        update_plate_failure_log_file(plateFailureArray);
        // next iteration
        iterationCounter++;
    }
    // output completion info to console //
    print_completion_info_and_failureArray(plateFailureArray);
    // clean up some temporary files //
    //remove_temp_files();
    return 0;
}

//////////////////////////////  End of Code  //////////////////////////////
////////////////////////////// FDS-2-Abaqus  //////////////////////////////
