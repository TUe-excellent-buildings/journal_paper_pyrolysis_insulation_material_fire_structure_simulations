###########################################################################
## Name:        SR_basicModel.py 									 	 ##
##																		 ##
## Description: Basic Structural Response(SR) Model for a self supporting##
## 				sandwich panel facade system, including main structure,  ##
##				framework and connections. This model can be used in 	 ##
##				a two-way coupled thermo-mechanical CFD-FEM Analysis.	 ##
##						 												 ##
## Additional	This script is INCOMPLETE, additional python code is     ##
## Info:		appended by geometric update program upGeomSR based on   ##
##				the current iteration in the coupling analysis.          ##
##				The complete coupling procedure is managed by 			 ##
## 				Master Program FDS-2-Abaqus.							 ##
## 																		 ##
## Input :		HT_Script.odb (Temperatures)							 ##
##				i0_buc-Job.fil (imperfection node file)			         ##
##				io_buc-Job.prt (imperfection part file)					 ##
##																		 ##
## Output:      SR_script.odb											 ## 
##				Requires a \\_outputSR\\ folder to store *.odb output    ##
##																		 ##
###########################################################################
## Version 2.0                                       by J.G.G.M. de Boer ##
## May 2018                                j.g.g.m.d.boer@student.tue.nl ##
###########################################################################

############################## Begin Script ###############################
# -*- coding: mbcs -*-
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
cliCommand("""session.journalOptions.setValues(replayGeometry=COORDINATE,
	recoverGeometry=COORDINATE)""")
### use this lines for use in FDS-2-Abaqus (relative path)
currentPath = os.getcwd()
### use this line when launching script from Abaqus CEA (direct path)
# specify output directory (exclude '_outputSR' folder)
#currentPath = 'C:\\...' 
## Change Working Directory ##
# don't forget to create a '_outputSR' folder in output directory
os.chdir(currentPath + '\\_outputSR\\') 
## Name Model ##
mod = mdb.models['Model-1']
modRa = mod.rootAssembly
## Specify-Attributes ##
mod.setValues(absoluteZero=-273.15, stefanBoltzmann=5.67e-08)	
### CREATE PARTS ###
## Insulation ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
    point2=(0.9, 0.08))
mod.Part(dimensionality=THREE_D, name='Insulation', type=
    DEFORMABLE_BODY)
mod.parts['Insulation'].BaseSolidExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Inner plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.9, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.45, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.45, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Inner_plate', type=
    DEFORMABLE_BODY)
mod.parts['Inner_plate'].BaseShellExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Outer plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.9, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.45, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.45, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Outer_plate', type=
    DEFORMABLE_BODY)
mod.parts['Outer_plate'].BaseShellExtrude(depth=3.6, sketch=
    mod.sketches['__profile__'])
## Steel column ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(-0.1, 0.0), point2=(
    0.1, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.0), 
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.0, 0.19))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.095))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.095), 
    ))
mod.sketches['__profile__'].Line(point1=(-0.1, 0.19), point2=
    (0.1, 0.19))
mod.sketches['__profile__'].geometry.findAt((-0.09, 0.19))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((-0.09, 
    0.19), ))
mod.Part(dimensionality=THREE_D, name='HEA_200', type=
    DEFORMABLE_BODY)
mod.parts['HEA_200'].BaseShellExtrude(depth=2.71, sketch=
    mod.sketches['__profile__'])
## Frame ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.15), point2=(
    0.0, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075), 
    ))
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.15, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.075, 0.0), 
    ))
mod.sketches['__profile__'].geometry.findAt((0.0, 0.075))
mod.sketches['__profile__'].geometry.findAt((0.075, 0.0))
mod.sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mod.sketches['__profile__'].geometry.findAt((0.0, 0.075), 
    ), entity2=mod.sketches['__profile__'].geometry.findAt((
    0.075, 0.0), ))
mod.Part(dimensionality=THREE_D, name='Frame', type=
    DEFORMABLE_BODY)
mod.parts['Frame'].BaseShellExtrude(depth=2.71, sketch=
    mod.sketches['__profile__'])
## Connection plate ##
mod.ConstrainedSketch(name='__profile__', sheetSize=2.0)
mod.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.1, 0.0))
mod.sketches['__profile__'].geometry.findAt((0.05, 0.0))
mod.sketches['__profile__'].HorizontalConstraint(
    addUndoState=False, entity=
    mod.sketches['__profile__'].geometry.findAt((0.05, 0.0), 
    ))
mod.Part(dimensionality=THREE_D, name='Welded_plate', type=
    DEFORMABLE_BODY)
mod.parts['Welded_plate'].BaseShellExtrude(depth=0.15, 
    sketch=mod.sketches['__profile__'])
### CREATE EDGE PARTITIONS ###
## Inner plate ## Spring connection ##
# Plane axis #
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.1, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.2, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.3, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.4, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.5, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.6, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.7, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.8, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    0.9, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.0, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.1, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.2, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.3, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.4, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.5, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.6, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.7, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.8, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    1.9, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.0, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.1, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.2, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.3, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.4, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.5, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.6, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.7, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.8, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    2.9, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.0, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.1, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.2, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.3, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.4, principalPlane=XYPLANE)
mod.parts['Inner_plate'].DatumPlaneByPrincipalPlane(offset=
    3.5, principalPlane=XYPLANE)
# Partition by plane #
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[2], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 0.9), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[3], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 0.975), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[4], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.05), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[5], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.125), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[6], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.2), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[7], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.275), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[8], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.35), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[9], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.425), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[10], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.5), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[11], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.575), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[12], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.65), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[13], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.725), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[14], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.8), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[15], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.875), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[16], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 1.95), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[17], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.025), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[18], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.1), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[19], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.175), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[20], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.25), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[21], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.325), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[22], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.4), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[23], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.475), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[24], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.55), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[25], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.625), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[26], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.7), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[27], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.775), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[28], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.85), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[29], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 2.925), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[30], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.0), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[31], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.075), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[32], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.15), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[33], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.225), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[34], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.3), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[35], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.375), 
    )))
mod.parts['Inner_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Inner_plate'].datums[36], edges=
    mod.parts['Inner_plate'].edges.findAt(((0.0, 0.0, 3.45), 
    )))
## Outer plate ## Spring connection ##
# Plane axis #
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.1, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.2, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.3, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.4, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.5, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.6, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.7, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.8, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    0.9, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.0, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.1, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.2, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.3, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.4, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.5, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.6, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.7, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.8, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    1.9, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.0, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.1, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.2, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.3, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.4, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.5, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.6, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.7, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.8, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    2.9, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.0, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.1, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.2, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.3, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.4, principalPlane=XYPLANE)
mod.parts['Outer_plate'].DatumPlaneByPrincipalPlane(offset=
    3.5, principalPlane=XYPLANE)
# Partitions by plane #
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[2], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 0.9), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[3], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 0.975), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[4], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.05), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[5], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.125), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[6], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.2), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[7], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.275), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[8], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.35), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[9], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.425), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[10], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.5), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[11], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.575), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[12], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.65), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[13], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.725), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[14], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.8), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[15], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.875), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[16], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 1.95), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[17], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.025), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[18], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.1), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[19], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.175), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[20], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.25), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[21], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.325), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[22], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.4), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[23], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.475), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[24], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.55), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[25], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.625), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[26], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.7), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[27], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.775), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[28], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.85), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[29], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 2.925), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[30], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.0), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[31], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.075), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[32], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.15), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[33], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.225), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[34], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.3), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[35], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.375), 
    )))
mod.parts['Outer_plate'].PartitionEdgeByDatumPlane(
    datumPlane=mod.parts['Outer_plate'].datums[36], edges=
    mod.parts['Outer_plate'].edges.findAt(((0.9, 0.0, 3.45), 
    )))
## Partition for screw connection ##
# frame #
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByPoint(edge=
    mdb.models['Model-1'].parts['Frame'].edges[0], point=
    mdb.models['Model-1'].parts['Frame'].InterestingPoint(
    mdb.models['Model-1'].parts['Frame'].edges[0], MIDDLE))
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByPoint(edge=
    mdb.models['Model-1'].parts['Frame'].edges[5], point=
    mdb.models['Model-1'].parts['Frame'].InterestingPoint(
    mdb.models['Model-1'].parts['Frame'].edges[5], MIDDLE))
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByPoint(edge=
    mdb.models['Model-1'].parts['Frame'].edges[3], point=
    mdb.models['Model-1'].parts['Frame'].InterestingPoint(
    mdb.models['Model-1'].parts['Frame'].edges[3], MIDDLE))
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByPoint(edge=
    mdb.models['Model-1'].parts['Frame'].edges[9], point=
    mdb.models['Model-1'].parts['Frame'].InterestingPoint(
    mdb.models['Model-1'].parts['Frame'].edges[9], MIDDLE))
mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.13, name='__profile__', 
    sheetSize=5.42, transform=
    mdb.models['Model-1'].parts['Frame'].MakeSketchTransform(
    sketchPlane=mdb.models['Model-1'].parts['Frame'].faces[0], 
    sketchPlaneSide=SIDE1, 
    sketchUpEdge=mdb.models['Model-1'].parts['Frame'].edges[5], 
    sketchOrientation=RIGHT, origin=(0.075, 0.0, 1.355)))
mdb.models['Model-1'].parts['Frame'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0.0, 1.355), point2=
    (0.0, -1.355))
mdb.models['Model-1'].sketches['__profile__'].VerticalConstraint(addUndoState=
    False, entity=mdb.models['Model-1'].sketches['__profile__'].geometry[9])
mdb.models['Model-1'].sketches['__profile__'].PerpendicularConstraint(
    addUndoState=False, entity1=
    mdb.models['Model-1'].sketches['__profile__'].geometry[2], entity2=
    mdb.models['Model-1'].sketches['__profile__'].geometry[9])
mdb.models['Model-1'].parts['Frame'].PartitionFaceBySketch(faces=
    mdb.models['Model-1'].parts['Frame'].faces.getSequenceFromMask(('[#1 ]', ), 
    ), sketch=mdb.models['Model-1'].sketches['__profile__'], sketchUpEdge=
    mdb.models['Model-1'].parts['Frame'].edges[5])
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByParam(edges=
    mdb.models['Model-1'].parts['Frame'].edges.getSequenceFromMask(('[#1 ]', ), 
    ), parameter=0.98)
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByParam(edges=
    mdb.models['Model-1'].parts['Frame'].edges.getSequenceFromMask(('[#1 ]', ), 
    ), parameter=0.66)
mdb.models['Model-1'].parts['Frame'].PartitionEdgeByParam(edges=
    mdb.models['Model-1'].parts['Frame'].edges.getSequenceFromMask(('[#1 ]', ), 
    ), parameter=0.49)
### CREATE MATERIAL PROPERTIES ###
## Steel properties ## including temperature dependant properties ##
mod.Material(name='Steel_S355')
mod.materials['Steel_S355'].Elastic(table=((
    210000000000.0, 0.3, 20.0), (210000000000.0, 0.3, 100.0), (189000000000.0,
    0.3, 200.0), (168000000000.0, 0.3, 300.0), (147000000000.0, 0.3, 400.0), (
    126000000000.0, 0.3, 500.0), (65100000000.0, 0.3, 600.0), (27300000000.0,
    0.3, 700.0), (18900000000.0, 0.3, 800.0), (14175000000.0, 0.3, 900.0), (
    9450000000.0, 0.3, 1000.0), (4725000000.0, 0.3, 1100.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Density(table=((7850.0, ), ))
mod.materials['Steel_S355'].Expansion(table=((1.51e-05, 20.0), (
    1.51e-05, 750.0), (1.31e-05, 760.0), (1.31e-05, 860.0), (1.51e-05, 870.0), 
    (1.51e-05, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].SpecificHeat(table=((440.0, 20.0), (
    760.0, 600.0), (5000.0, 735.0), (650.4, 900.0), (650.0, 1200.0)), 
    temperatureDependency=ON)
mod.materials['Steel_S355'].Conductivity(table=((53.3, 20.0), (
    27.4, 800.0), (27.3, 1200.0)), temperatureDependency=ON)
mod.materials['Steel_S355'].Plastic(table=((355599612.4,
    0.0, 20.0), (357218145.0, 0.004566937, 20.0), (358829331.8, 0.009113111,
    20.0), (360433239.2, 0.013638711, 20.0), (362029932.7, 0.018143923, 20.0),
    (404615489.5, 0.138290882, 20.0), (355599612.4, 0.0, 100.0), (357218145.0,
    0.004566937, 100.0), (358829331.8, 0.009113111, 100.0), (360433239.2,
    0.013638711, 100.0), (362029932.7, 0.018143923, 100.0), (404615489.5,
    0.138290882, 100.0), (286875560.6, 0.0, 200.0), (333319059.6, 0.004610407,
    200.0), (349284030.0, 0.009199656, 200.0), (358112290.5, 0.01376794,
    200.0), (361977173.2, 0.01831545, 200.0), (404568694.6, 0.138442992,
    200.0), (217840389.4, 0.0, 300.0), (308131318.1, 0.004665269, 300.0), (
    339225541.8, 0.009308874, 300.0), (355678058.7, 0.013931016, 300.0), (
    361939756.3, 0.018531891, 300.0), (404535508.1, 0.138634936, 300.0), (
    149205823.4, 0.0, 400.0), (281382163.9, 0.0047352, 400.0), (328533487.9,
    0.009448083, 400.0), (353104758.7, 0.014138859, 400.0), (361924013.5,
    0.018807735, 400.0), (404521545.4, 0.138879566, 400.0), (99731307.34, 0.0,
    500.0), (213381375.5, 0.00479072, 500.0), (253814286.9, 0.009558599,
    500.0), (274829284.2, 0.014303853, 500.0), (282297425.4, 0.019026696,
    500.0), (315523874.0, 0.139073755, 500.0), (30037294.84, 0.0, 600.0), (
    115714763.5, 0.004872775, 600.0), (147777119.4, 0.00972192, 600.0), (
    164362320.5, 0.014547665, 600.0), (170101989.6, 0.019350234, 600.0), (
    190123089.3, 0.1393607, 600.0), (6123928.57, 0.0, 700.0), (52377488.91,
    0.004931741, 700.0), (70599467.17, 0.009839279, 700.0), (80026210.08,
    0.01472285, 700.0), (83251261.26, 0.019582688, 700.0), (93047705.59,
    0.139566868, 700.0), (1952518.154, 0.0, 800.0), (25283029.45, 0.004961843,
    800.0), (33873342.85, 0.009899188, 800.0), (38302736.71, 0.014812274,
    800.0), (39819693.35, 0.019701341, 800.0), (44504511.49, 0.139672106,
    800.0), (798753.0381, 0.0, 900.0), (13896838.39, 0.004973524, 900.0), (
    18522040.26, 0.009922435, 900.0), (20904066.71, 0.014846974, 900.0), (
    21720698.66, 0.019747381, 900.0), (24275956.11, 0.139712942, 900.0), (
    355000.6001, 0.0, 1000.0), (9194998.354, 0.004978197, 1000.0), (
    12320356.23, 0.009931734, 1000.0), (13929587.95, 0.014860854, 1000.0), (
    14480697.85, 0.019765797, 1000.0), (16184176.59, 0.139729276, 1000.0), (
    88750.03751, 0.0, 1100.0), (4562665.473, 0.004982869, 1100.0), (
    6146323.829, 0.009941032, 1100.0), (6961565.569, 0.014874733, 1100.0), (
    7240470.85, 0.019784212, 1100.0), (8092196.434, 0.139745609, 1100.0)),
    temperatureDependency=ON)
## Insulation properties ##	
mod.Material(name='Insulation')
modMatIns = mod.materials['Insulation']
modMatIns.Depvar(n=1)
modMatIns.UserDefinedField()
modMatIns.Density(dependencies=1,
    table=((80.0, 1.0), (20.4, 0.0)))
modMatIns.Elastic(dependencies=1,
    table=((20000000.0, 0.20, 1.0), (10000000, 0.20, 0.0)))
modMatIns.Expansion(table=((5e-5, ), ))

### CREATE & ASSIGN SECTION ###
## Inner plate ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Inner_Steel_plate', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.0004, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['Inner_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 
    2.4), (0.0, -1.0, 0.0)), )), sectionName='Inner_Steel_plate', 
    thicknessAssignment=FROM_SECTION)
## Outer plate ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Outer_Steel_plate', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.0005, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['Outer_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Outer_plate'].faces.findAt(((0.6, 0.0, 
    2.4), (0.0, -1.0, 0.0)), )), sectionName='Outer_Steel_plate', 
    thicknessAssignment=FROM_SECTION)
## Insulation ##
mod.HomogeneousSolidSection(material='Insulation', name=
    'Insulation', thickness=None)
mod.parts['Insulation'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    cells=mod.parts['Insulation'].cells.findAt(((0.9, 
    0.053333, 2.4), ), )), sectionName='Insulation', thicknessAssignment=
    FROM_SECTION)
## Column ##
# Web # 
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='HEA_200_web', numIntPts=5, 
    poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=GRADIENT, 
    thickness=0.0065, thicknessField='', thicknessModulus=None, thicknessType=
    UNIFORM, useDensity=OFF)
mod.parts['HEA_200'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['HEA_200'].faces.findAt(((0.0, 0.126667, 
    1.806667), (1.0, 0.0, 0.0)), )), sectionName='HEA_200_web', 
    thicknessAssignment=FROM_SECTION)
# Flench #
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='HEA_200_flench', 
    numIntPts=5, poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=
    GRADIENT, thickness=0.01, thicknessField='', thicknessModulus=None, 
    thicknessType=UNIFORM, useDensity=OFF)
mod.parts['HEA_200'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['HEA_200'].faces.findAt(((0.033333, 0.0, 
    0.903333), (0.0, -1.0, 0.0)), ((-0.033333, 0.0, 1.806667), (0.0, -1.0, 
    0.0)), ((-0.033333, 0.19, 1.806667), (0.0, -1.0, 0.0)), ((0.033333, 0.19, 
    0.903333), (0.0, -1.0, 0.0)), )), sectionName='HEA_200_flench', 
    thicknessAssignment=FROM_SECTION)
mod.parts['Welded_plate'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mod.parts['Welded_plate'].faces.findAt(((0.066667, 
    0.0, 0.1), (0.0, -1.0, 0.0)), )), sectionName='HEA_200_flench', 
    thicknessAssignment=FROM_SECTION)
## Frame ##
mod.HomogeneousShellSection(idealization=NO_IDEALIZATION, 
    integrationRule=SIMPSON, material='Steel_S355', name='Steel_frame', numIntPts=5, 
    poissonDefinition=DEFAULT, preIntegrate=OFF, temperature=GRADIENT, 
    thickness=0.004, thicknessField='', thicknessModulus=None, thicknessType=
    UNIFORM, useDensity=OFF)
mdb.models['Model-1'].parts['Frame'].SectionAssignment(offset=0.0, offsetField=
    '', offsetType=MIDDLE_SURFACE, region=Region(
    faces=mdb.models['Model-1'].parts['Frame'].faces.findAt(((0.05, 0.0, 
    1.806667), (0.0, -1.0, 0.0)), ((0.1, 0.0, 0.903333), (0.0, -1.0, 0.0)), ((
    0.0, 0.05, 1.806667), (-1.0, 0.0, 0.0)), )), sectionName='Steel_frame', 
    thicknessAssignment=FROM_SECTION)
### CREATE SURFACES ###
## Insulation and plates ## Tie constraint ##
mod.parts['Outer_plate'].Surface(name='Outer_insulation', 
    side1Faces=mod.parts['Outer_plate'].faces.findAt(((0.6, 
    0.0, 2.4), )))
mod.parts['Insulation'].Surface(name='Insulation_outer', 
    side1Faces=mod.parts['Insulation'].faces.findAt(((0.3, 
    0.08, 2.4), )))
mod.parts['Insulation'].Surface(name='Insulation_inner', 
    side1Faces=mod.parts['Insulation'].faces.findAt(((0.6, 
    0.0, 2.4), )))
mod.parts['Inner_plate'].Surface(name='Inner_insulation', 
    side2Faces=mod.parts['Inner_plate'].faces.findAt(((0.6, 
    0.0, 2.4), )))
### ASSEMBLY FACADE ###
## Create Kingspan panel ##
# Create instances # inner plate, outer plate, insulation #
modRa.DatumCsysByDefault(CARTESIAN)
modRa.Instance(dependent=ON, name='Inner_plate-1', 
    part=mod.parts['Inner_plate'])
modRa.Instance(dependent=ON, name='Insulation-1', 
    part=mod.parts['Insulation'])
modRa.Instance(dependent=ON, name='Outer_plate-1', 
    part=mod.parts['Outer_plate'])
modRa.instances['Insulation-1'].translate(vector=(
    0.99, 0.0, 0.0))
modRa.instances['Outer_plate-1'].translate(vector=
    (1.98002, 0.0, 0.0))
# Built panel #
modRa.translate(instanceList=('Insulation-1', ), 
    vector=(-0.99, 0.0, 0.0))
modRa.translate(instanceList=('Outer_plate-1', ), 
    vector=(-1.98002, 0.08, 0.0))
## Duplicate panel ##
modRa.LinearInstancePattern(direction1=(1.0, 0.0, 
    0.0), direction2=(0.0, 1.0, 0.0), instanceList=('Inner_plate-1', 
    'Insulation-1', 'Outer_plate-1'), number1=3, number2=1, spacing1=0.905, 
    spacing2=0.0802)
## Rename instances ##
modRa.features.changeKey(fromName=
    'Inner_plate-1-lin-2-1', toName='Inner_plate-2')
modRa.features.changeKey(fromName=
    'Inner_plate-1-lin-3-1', toName='Inner_plate-3')
modRa.features.changeKey(fromName=
    'Insulation-1-lin-2-1', toName='Insulation-2')
modRa.features.changeKey(fromName=
    'Insulation-1-lin-3-1', toName='Insulation-3')
modRa.features.changeKey(fromName=
    'Outer_plate-1-lin-2-1', toName='Outer_plate-2')
modRa.features.changeKey(fromName=
    'Outer_plate-1-lin-3-1', toName='Outer_plate-3')
## Create Steel frame ##
# Create instance # frame #
modRa.Instance(dependent=ON, name='Frame-1', part=
    mod.parts['Frame'])
modRa.instances['Frame-1'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15, 
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-1', ))
modRa.rotate(angle=180.0, axisDirection=(2.71, 
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-1', ))
modRa.translate(instanceList=('Frame-1', ), 
    vector=(-2.7252, -0.3, 0.0))
# Create instance # frame #
modRa.Instance(dependent=ON, name='Frame-2', part=
    mod.parts['Frame'])
modRa.instances['Frame-2'].translate(vector=(
    2.7252, 0.0, 0.0))
# Positioning frame #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.15, 
    0.0), axisPoint=(2.7252, 0.0, 0.0), instanceList=('Frame-2', ))
modRa.rotate(angle=180.0, axisDirection=(2.71, 
    0.0, 0.0), axisPoint=(2.7252, 0.15, 0.0), instanceList=('Frame-2', ))
modRa.translate(instanceList=('Frame-2', ), 
    vector=(-2.7252, -0.30, 3.45))
# Create instance # column #
modRa.Instance(dependent=ON, name='HEA_200-1', 
    part=mod.parts['HEA_200'])
modRa.instances['HEA_200-1'].translate(vector=(
    2.8302, 0.0, 0.0))
# Positioning column #
modRa.rotate(angle=90.0, axisDirection=(0.0, 0.19, 
    0.0), axisPoint=(2.8302, 0.0, 2.71), instanceList=('HEA_200-1', ))
modRa.translate(instanceList=('HEA_200-1', ), 
    vector=(-0.1202, -0.34, -2.71))
# Create instance # connection plate #
modRa.Instance(dependent=ON, name='Welded_plate-1'
    , part=mod.parts['Welded_plate'])
modRa.instances['Welded_plate-1'].translate(
    vector=(2.7202, 0.0, 0.0))
# Positioning connection plate #
modRa.rotate(angle=90.0, axisDirection=(0.1, 0.0, 
    0.0), axisPoint=(2.7202, 0.0, 0.0), instanceList=('Welded_plate-1', ))
modRa.translate(instanceList=('Welded_plate-1', ), 
    vector=(-0.1102, 0.0, 0.0))
modRa.translate(instanceList=('Welded_plate-1', ), 
    vector=(-0.2, 0.0, 0.0))
# Create instance # connection plate #
modRa.Instance(dependent=ON, name='Welded_plate-2'
    , part=mod.parts['Welded_plate'])
modRa.instances['Welded_plate-2'].translate(
    vector=(2.7202, 0.0, 0.0))
# Positioning connection plate #
modRa.rotate(angle=90.0, axisDirection=(-0.05, 
    0.0, 0.0), axisPoint=(2.8202, 0.0, 0.0), instanceList=('Welded_plate-2', ))
modRa.translate(instanceList=('Welded_plate-2', ), 
    vector=(-2.7202, -0.15, 0.0))
modRa.translate(instanceList=('Welded_plate-2', ), 
    vector=(0.2, 0.0, 0.0))
# Merge column & conection plates # create part #
modRa.InstanceFromBooleanMerge(domain=GEOMETRY, 
    instances=(modRa.instances['Welded_plate-2'], 
    modRa.instances['HEA_200-1'], 
    modRa.instances['Welded_plate-1']), name=
    'HEA_incl_connection', originalInstances=SUPPRESS)
# Create instance # Column including connection plates #
modRa.Instance(dependent=ON, name=
    'HEA_incl_connection-2', part=
    mod.parts['HEA_incl_connection'])
modRa.instances['HEA_incl_connection-2'].translate(
    vector=(2.9812, 0.0, 0.0))
# Positioning column including connection plates #
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(-2.9812, 0.0, 3.45))
### TIE PANELS ###
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-1'].surfaces['Insulation_inner']
    , name='Constraint-1', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Inner_plate-1'].surfaces['Inner_insulation']
    , thickness=ON, tieRotations=ON)
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-1'].surfaces['Insulation_outer']
    , name='Constraint-2', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Outer_plate-1'].surfaces['Outer_insulation']
    , thickness=ON, tieRotations=ON)
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-2'].surfaces['Insulation_inner']
    , name='Constraint-3', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Inner_plate-2'].surfaces['Inner_insulation']
    , thickness=ON, tieRotations=ON)
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-2'].surfaces['Insulation_outer']
    , name='Constraint-4', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Outer_plate-2'].surfaces['Outer_insulation']
    , thickness=ON, tieRotations=ON)
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-3'].surfaces['Insulation_inner']
    , name='Constraint-5', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Inner_plate-3'].surfaces['Inner_insulation']
    , thickness=ON, tieRotations=ON)
mod.Tie(adjust=ON, master=
    modRa.instances['Insulation-3'].surfaces['Insulation_outer']
    , name='Constraint-6', positionToleranceMethod=COMPUTED, slave=
    modRa.instances['Outer_plate-3'].surfaces['Outer_insulation']
    , thickness=ON, tieRotations=ON)
### CREATE ATTACHMENT POINTS ###
## Connection column & frame ##
modRa.AttachmentPointsOffsetFromEdges(edges=
    modRa.instances['HEA_incl_connection-1'].edges.findAt(
    ((2.51, -0.0375, 0.0), )), name='Connection_HEA_frame-1', numberOfPoints=2, 
    numberOfRows=1, offsetFromEdges=0.05, offsetFromStartPoint=0.05, 
    patterningMethod=PATTERN_ORTHOGONALLY, pointCreationMethod=BY_SPACING, 
    referenceFace=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    (2.476667, -0.1, 0.0), ), setName='Connection_HEA_frame-1', 
    spacingBetweenPoints=0.05, spacingMethod=SPECIFY_NUM_PTS, startPoint=
    modRa.instances['HEA_incl_connection-1'].vertices.findAt(
    (2.51, -0.15, 0.0), ))
modRa.AttachmentPointsOffsetFromEdges(edges=
    modRa.instances['HEA_incl_connection-1'].edges.findAt(
    ((0.3, -0.1125, 0.0), )), name='Connection_HEA_frame-2', numberOfPoints=2, 
    numberOfRows=1, offsetFromEdges=0.05, offsetFromStartPoint=0.05, 
    patterningMethod=PATTERN_ORTHOGONALLY, pointCreationMethod=BY_SPACING, 
    referenceFace=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    (0.266667, -0.05, 0.0), ), setName='Connection_HEA_frame-2', 
    spacingBetweenPoints=0.05, spacingMethod=SPECIFY_NUM_PTS, startPoint=
    modRa.instances['HEA_incl_connection-1'].vertices.findAt(
    (0.3, -0.15, 0.0), ))
modRa.AttachmentPointsOffsetFromEdges(edges=
    modRa.instances['HEA_incl_connection-2'].edges.findAt(
    ((2.51, -0.0375, 3.45), )), name='Connection_HEA_frame-3', numberOfPoints=2
    , numberOfRows=1, offsetFromEdges=0.05, offsetFromStartPoint=0.05, 
    patterningMethod=PATTERN_ORTHOGONALLY, pointCreationMethod=BY_SPACING, 
    referenceFace=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    (2.476667, -0.1, 3.45), ), setName='Connection_HEA_frame-3', 
    spacingBetweenPoints=0.05, spacingMethod=SPECIFY_NUM_PTS, startPoint=
    modRa.instances['HEA_incl_connection-2'].vertices.findAt(
    (2.51, -0.15, 3.45), ))
modRa.AttachmentPointsOffsetFromEdges(edges=
    modRa.instances['HEA_incl_connection-2'].edges.findAt(
    ((0.3, -0.1125, 3.45), )), name='Connection_HEA_frame-4', numberOfPoints=2, 
    numberOfRows=1, offsetFromEdges=0.05, offsetFromStartPoint=0.05, 
    patterningMethod=PATTERN_ORTHOGONALLY, pointCreationMethod=BY_SPACING, 
    referenceFace=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    (0.266667, -0.05, 3.45), ), setName='Connection_HEA_frame-4', 
    spacingBetweenPoints=0.05, spacingMethod=SPECIFY_NUM_PTS, startPoint=
    modRa.instances['HEA_incl_connection-2'].vertices.findAt(
    (0.3, -0.15, 3.45), ))
### CREATING CONNECTOR PROPERTIES ###
## Will be updated by upGeomSR ##
## Screws ##
mod.ConnectorSection(name='Screws_plates', translationalType=
    CARTESIAN)
mod.sections['Screws_plates'].setValues(behaviorOptions=(
    ConnectorElasticity(table=((9964000.0, 55600000.0, 9964000.0), ), 
    independentComponents=(), components=(1, 2, 3)), ConnectorPlasticity(
    isotropicTable=((6200.0, 0.0, 0.0), (7750.0, 0.0055, 0.0)), kinematicTable=(
    ), components=(2, )), ConnectorPlasticity(isotropicTable=((4200.0, 0.0, 
    0.0), (5250.0, 0.0055, 0.0)), kinematicTable=(), components=(1, 3))))
## Bolts ##
mod.ConnectorSection(name='Bolts_HEA', translationalType=
    CARTESIAN)
mod.sections['Bolts_HEA'].setValues(behaviorOptions=(
    ConnectorElasticity(table=((63777000.0, 63777000.0, 600000000.0), ), 
    independentComponents=(), components=(1, 2, 3)), ConnectorPlasticity(
    isotropicTable=((66200.0, 0.0, 0.0), (82750, 0.014, 0.0)), kinematicTable=(
    ), components=(3, )), ConnectorPlasticity(isotropicTable=((44100.0, 0.0, 
    0.0), (55125.0, 0.014, 0.0)), kinematicTable=(), components=(1, 2))))
### ASSIGNING FASTENERS ###
## Column & frame ##
modRa.Set(name='Fasteners_HEA_frame-1_lower', vertices=
    modRa.vertices.findAt(((2.46, -0.05, 0.0), ), ((2.46, -0.1, 0.0), ), ))
modRa.engineeringFeatures.PointFastener(
    connectionType=CONNECTOR, name='Fasteners_HEA_frame-1_lower', physicalRadius=0.012, 
    region=modRa.sets['Fasteners_HEA_frame-1_lower'], 
    sectionName='Bolts_HEA')
modRa.Set(name='Fasteners_HEA_frame-1_upper', vertices=
    modRa.vertices.findAt(((0.25, -0.05, 0.0), ), ((0.25, -0.1, 0.0), ),))
modRa.engineeringFeatures.PointFastener(
    connectionType=CONNECTOR, name='Fasteners_HEA_frame-1_upper', physicalRadius=0.012, 
    region=modRa.sets['Fasteners_HEA_frame-1_upper'], 
    sectionName='Bolts_HEA')
modRa.Set(name='Fasteners_HEA_frame-2_lower', vertices=
    modRa.vertices.findAt(((2.46, -0.05, 3.45), ), ((2.46, -0.1, 3.45), ),))
modRa.engineeringFeatures.PointFastener(
    connectionType=CONNECTOR, name='Fasteners_HEA_frame-2_lower', physicalRadius=0.012, 
    region=modRa.sets['Fasteners_HEA_frame-2_lower'], 
    sectionName='Bolts_HEA')
modRa.Set(name='Fasteners_HEA_frame-2_upper', vertices=
    modRa.vertices.findAt(((0.25, -0.05, 3.45), ), ((0.25, -0.1, 3.45), ),))
modRa.engineeringFeatures.PointFastener(
    connectionType=CONNECTOR, name='Fasteners_HEA_frame-2_upper', physicalRadius=0.012, 
    region=modRa.sets['Fasteners_HEA_frame-2_upper'], 
    sectionName='Bolts_HEA')
### CREATE MESH ###
## Column including connection plate ##
mod.parts['HEA_incl_connection'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['HEA_incl_connection'].setElementType(elemTypes=(
    ElemType(elemCode=S8R, elemLibrary=STANDARD), ElemType(elemCode=STRI65, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['HEA_incl_connection'].faces.findAt(((2.476667, 
    -0.1, 0.0), ), ((0.903333, -0.34, -0.033333), ), ((1.806667, -0.34, 
    0.033333), ), ((2.643333, -0.213333, 0.0), ), ((2.643333, -0.15, 0.033333), 
    ), ((2.643333, -0.15, -0.033333), ), ((0.266667, -0.05, 0.0), ), ), ))
mod.parts['HEA_incl_connection'].generateMesh()
## Frame ##
mod.parts['Frame'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['Frame'].setElementType(elemTypes=(ElemType(
    elemCode=S8R, elemLibrary=STANDARD), ElemType(elemCode=STRI65, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Frame'].faces.findAt(((0.1, 0.0, 1.806667), ), 
    ((0.0, 0.05, 1.806667), ), ), ))
mod.parts['Frame'].generateMesh()
## Inner plate ##
mod.parts['Inner_plate'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.05)
mod.parts['Inner_plate'].setElementType(elemTypes=(ElemType(
    elemCode=S8R, elemLibrary=STANDARD), ElemType(elemCode=STRI65, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), ))
mod.parts['Inner_plate'].generateMesh()
## Insulation ##
mod.parts['Insulation'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.1)
mod.parts['Insulation'].seedEdgeByNumber(constraint=FINER, 
    edges=mod.parts['Insulation'].edges.findAt(((0.0, 0.02, 
    3.6), ), ((0.0, 0.02, 0.0), ), ((0.9, 0.06, 3.6), ), ((0.9, 0.06, 0.0), ), 
    ), number=2)
mod.parts['Insulation'].setElementType(elemTypes=(ElemType(
    elemCode=C3D20R, elemLibrary=STANDARD), ElemType(elemCode=C3D15, 
    elemLibrary=STANDARD), ElemType(elemCode=C3D10, elemLibrary=STANDARD)), 
    regions=(mod.parts['Insulation'].cells.findAt(((0.9, 
    0.053333, 2.4), )), ))
mod.parts['Insulation'].generateMesh()
## Outer plate ##
mod.parts['Outer_plate'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=0.1)
mod.parts['Outer_plate'].setElementType(elemTypes=(ElemType(
    elemCode=S8R, elemLibrary=STANDARD), ElemType(elemCode=STRI65, 
    elemLibrary=STANDARD)), regions=(
    mod.parts['Outer_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), ))
mod.parts['Outer_plate'].generateMesh()
### REGENERATE ASSEMBLY ###
modRa.regenerate()
### REPOSITIONING STRUCTURE ###
modRa.translate(instanceList=(
    'HEA_incl_connection-1', ), vector=(0.0, -0.0072, -0.007))
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(0.0, -0.0072, -0.007))
modRa.translate(instanceList=(
    'Frame-1', ), vector=(0.0, -0.0022, 0.0))
modRa.translate(instanceList=(
    'Frame-2', ), vector=(0.0, -0.0022, 0.0))	
modRa.translate(instanceList=(
    'Insulation-1', ), vector=(0.0, 0.00045, 0.0))
modRa.translate(instanceList=(
    'Insulation-2', ), vector=(0.0, 0.00045, 0.0))
modRa.translate(instanceList=(
    'Insulation-3', ), vector=(0.0, 0.00045, 0.0))	
modRa.translate(instanceList=(
    'Outer_plate-1', ), vector=(0.0, 0.00045, 0.0))
modRa.regenerate()
### BOUNDARY CONDITIONS ###
## Columns to floors ##
# Top #
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name='Top_column_1'
    , region=Region(
    edges=modRa.instances['HEA_incl_connection-1'].edges.findAt(
    ((0.0, -0.3472, -0.032), ), ((0.0, -0.3472, 0.068), ), ((0.0, -0.2997, 
    -0.007), ), ((0.0, -0.1572, 0.068), ), ((0.0, -0.1572, -0.032), ), )), u1=
    UNSET, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name='Top_column_2'
    , region=Region(
    edges=modRa.instances['HEA_incl_connection-2'].edges.findAt(
    ((0.0, -0.3472, 3.418), ), ((0.0, -0.3472, 3.518), ), ((0.0, -0.2997, 
    3.443), ), ((0.0, -0.1572, 3.518), ), ((0.0, -0.1572, 3.418), ), )), u1=
    UNSET, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
# Bottom #
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name=
    'Bottom_column_1', region=Region(
    edges=modRa.instances['HEA_incl_connection-1'].edges.findAt(
    ((2.71, -0.3472, -0.082), ), ((2.71, -0.3472, 0.018), ), ((2.71, -0.2047, 
    -0.007), ), ((2.71, -0.1572, 0.018), ), ((2.71, -0.1572, -0.082), ), )), 
    u1=SET, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)
mod.DisplacementBC(amplitude=UNSET, createStepName='Initial', 
    distributionType=UNIFORM, fieldName='', localCsys=None, name=
    'Bottom_column_2', region=Region(
    edges=modRa.instances['HEA_incl_connection-2'].edges.findAt(
    ((2.71, -0.3472, 3.368), ), ((2.71, -0.3472, 3.468), ), ((2.71, -0.2047, 
    3.443), ), ((2.71, -0.1572, 3.468), ), ((2.71, -0.1572, 3.368), ), )), u1=
    SET, u2=SET, u3=SET, ur1=UNSET, ur2=UNSET, ur3=UNSET)	
modRa.regenerate()
### INTERACTION PROPERTIES###
## Surfaces ##
modRa.Surface(name='Welded_plate_1-1', side1Faces=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    ((0.266667, -0.0572, -0.007), )))
modRa.Surface(name='Welded_plate_1-2', side2Faces=
    modRa.instances['HEA_incl_connection-1'].faces.findAt(
    ((2.476667, -0.1072, -0.007), )))
modRa.Surface(name='Welded_plate_2-1', side1Faces=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    ((0.266667, -0.0572, 3.443), )))
modRa.Surface(name='Welded_plate_2-2', side2Faces=
    modRa.instances['HEA_incl_connection-2'].faces.findAt(
    ((2.476667, -0.1072, 3.443), )))
modRa.Surface(name='Frame_1_HEA', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0522, 0.0), )))
modRa.Surface(name='Frame_2_HEA', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0522, 3.45), )))
modRa.Surface(name='Frame_1_plate', side1Faces=
    modRa.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0022, 0.1), )))
modRa.Surface(name='Frame_2_plate', side1Faces=
    modRa.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0022, 3.55), )))
modRa.Surface(name='Inner_plate_1_frame', 
    side1Faces=
    modRa.instances['Inner_plate-1'].faces.findAt(
    ((0.6, 0.0, 2.4), )))
modRa.Surface(name='Inner_plate_2_frame', 
    side1Faces=
    modRa.instances['Inner_plate-2'].faces.findAt(
    ((1.505, 0.0, 2.4), )))
modRa.Surface(name='Inner_plate_3_frame', 
    side1Faces=
    modRa.instances['Inner_plate-3'].faces.findAt(
    ((2.41, 0.0, 2.4), )))	
## Interaction Hard Contact ##
mod.ContactProperty('Compression_only')
mod.interactionProperties['Compression_only'].TangentialBehavior(
    formulation=FRICTIONLESS)
mod.interactionProperties['Compression_only'].NormalBehavior(
    allowSeparation=ON, constraintEnforcementMethod=DEFAULT, 
    pressureOverclosure=HARD)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Welded_plate_1-1'], name=
    'HEA_frame_1-1', slave=
    modRa.surfaces['Frame_1_HEA'], sliding=FINITE, 
    thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Welded_plate_1-2'], name=
    'HEA_frame_1-2', slave=
    modRa.surfaces['Frame_1_HEA'], sliding=FINITE, 
    thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Welded_plate_2-1'], name=
    'HEA_frame_2-1', slave=
    modRa.surfaces['Frame_2_HEA'], sliding=FINITE, 
    thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Welded_plate_2-2'], name=
    'HEA_frame_2-2', slave=
    modRa.surfaces['Frame_2_HEA'], sliding=FINITE, 
    thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_1_plate'], name=
    'Frame_1_plate_1', slave=
    modRa.surfaces['Inner_plate_1_frame'], 
    sliding=FINITE, thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_1_plate'], name=
    'Frame_1_plate_2', slave=
    modRa.surfaces['Inner_plate_2_frame'], 
    sliding=FINITE, thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_1_plate'], name=
    'Frame_1_plate_3', slave=
    modRa.surfaces['Inner_plate_3_frame'], 
    sliding=FINITE, thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_2_plate'], name=
    'Frame_2_plate_1', slave=
    modRa.surfaces['Inner_plate_1_frame'], 
    sliding=FINITE, thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_2_plate'], name=
    'Frame_2_plate_2', slave=
    modRa.surfaces['Inner_plate_2_frame'], 
    sliding=FINITE, thickness=ON)
mod.SurfaceToSurfaceContactStd(adjustMethod=NONE, 
    clearanceRegion=None, createStepName='Initial', datumAxis=None, 
    initialClearance=OMIT, interactionProperty='Compression_only', master=
    modRa.surfaces['Frame_2_plate'], name=
    'Frame_2_plate_3', slave=
    modRa.surfaces['Inner_plate_3_frame'], 
    sliding=FINITE, thickness=ON)
### REPOSITIONING STRUCTURE ###
modRa.translate(instanceList=(
    'HEA_incl_connection-1', ), vector=(0.0, 0.0, -0.0005))
modRa.translate(instanceList=(
    'HEA_incl_connection-2', ), vector=(0.0, 0.0, -0.0005))
modRa.translate(instanceList=(
    'Frame-1', ), vector=(0.0, -0.0005, 0.0))
modRa.translate(instanceList=(
    'Frame-2', ), vector=(0.0, -0.0005, 0.0))	
 ### CREATE STEP ###
mod.StaticStep(amplitude=RAMP, initialInc=0.3, maxInc=10.0, 
    maxNumInc=10000, minInc=1e-09, name='i0_SR-Step', nlgeom=ON, 
    previous='Initial', timePeriod=300.0)
### OUTPUT SR ###
## Request Field Output ## 
mod.fieldOutputRequests['F-Output-1'].setValues(timeInterval=5.0, 
	variables=('S','SSAVG', 'E', 'PE', 'PEEQ', 'U', 'NT', 'TEMP', 'FV'))
## Request Restart File for Initial Request## 
mod.steps['i0_SR-Step'].Restart(frequency=0, numberIntervals=1, overlay=ON, 
	timeMarks=OFF)
## model change Interaction ## 
mod.ModelChange(name='ModelChange', createStepName='i0_SR-Step', 
	isRestart=True)
### connection between panels (locking system) ###
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 3.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 3.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 2.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 2.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 1.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 1.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].vertices.findAt(
    (0.9, 0.08045, 0.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.905, 0.0, 0.0), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((0.90125, 0.060338, 0.0), 
    ), ((0.90125, 0.060338, 0.1), ), ((0.90125, 0.060338, 0.2), ), ((0.90125, 
    0.060338, 0.3), ), ((0.90125, 0.060338, 0.4), ), ((0.90125, 0.060338, 0.5), 
    ), ((0.90125, 0.060338, 0.6), ), ((0.90125, 0.060338, 0.7), ), ((0.90125, 
    0.060338, 0.8), ), ((0.90125, 0.060338, 0.9), ), ((0.90125, 0.060338, 1.0), 
    ), ((0.90125, 0.060338, 1.1), ), ((0.90125, 0.060338, 1.2), ), ((0.90125, 
    0.060338, 1.3), ), ((0.90125, 0.060338, 1.4), ), ((0.90125, 0.060338, 1.5), 
    ), ((0.90125, 0.060338, 1.6), ), ((0.90125, 0.060338, 1.7), ), ((0.90125, 
    0.060338, 1.8), ), ((0.90125, 0.060338, 1.9), ), ((0.90125, 0.060338, 2.0), 
    ), ((0.90125, 0.060338, 2.1), ), ((0.90125, 0.060338, 2.2), ), ((0.90125, 
    0.060338, 2.3), ), ((0.90125, 0.060338, 2.4), ), ((0.90125, 0.060338, 2.5), 
    ), ((0.90125, 0.060338, 2.6), ), ((0.90125, 0.060338, 2.7), ), ((0.90125, 
    0.060338, 2.8), ), ((0.90125, 0.060338, 2.9), ), ((0.90125, 0.060338, 3.0), 
    ), ((0.90125, 0.060338, 3.1), ), ((0.90125, 0.060338, 3.2), ), ((0.90125, 
    0.060338, 3.3), ), ((0.90125, 0.060338, 3.4), ), ((0.90125, 0.060338, 3.5), 
    ), ((0.90125, 0.060338, 3.6), ), ), name='Wire-1-Set-1')
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 3.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 3.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 2.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 2.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 1.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 1.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].vertices.findAt(
    (1.805, 0.08, 0.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.81, 0.0, 0.0), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((1.80625, 0.06, 0.0), ), (
    (1.80625, 0.06, 0.1), ), ((1.80625, 0.06, 0.2), ), ((1.80625, 0.06, 0.3), 
    ), ((1.80625, 0.06, 0.4), ), ((1.80625, 0.06, 0.5), ), ((1.80625, 0.06, 
    0.6), ), ((1.80625, 0.06, 0.7), ), ((1.80625, 0.06, 0.8), ), ((1.80625, 
    0.06, 0.9), ), ((1.80625, 0.06, 1.0), ), ((1.80625, 0.06, 1.1), ), ((
    1.80625, 0.06, 1.2), ), ((1.80625, 0.06, 1.3), ), ((1.80625, 0.06, 1.4), ), 
    ((1.80625, 0.06, 1.5), ), ((1.80625, 0.06, 1.6), ), ((1.80625, 0.06, 1.7), 
    ), ((1.80625, 0.06, 1.8), ), ((1.80625, 0.06, 1.9), ), ((1.80625, 0.06, 
    2.0), ), ((1.80625, 0.06, 2.1), ), ((1.80625, 0.06, 2.2), ), ((1.80625, 
    0.06, 2.3), ), ((1.80625, 0.06, 2.4), ), ((1.80625, 0.06, 2.5), ), ((
    1.80625, 0.06, 2.6), ), ((1.80625, 0.06, 2.7), ), ((1.80625, 0.06, 2.8), ), 
    ((1.80625, 0.06, 2.9), ), ((1.80625, 0.06, 3.0), ), ((1.80625, 0.06, 3.1), 
    ), ((1.80625, 0.06, 3.2), ), ((1.80625, 0.06, 3.3), ), ((1.80625, 0.06, 
    3.4), ), ((1.80625, 0.06, 3.5), ), ((1.80625, 0.06, 3.6), ), ), name=
    'Wire-2-Set-1')
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 3.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 3.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 2.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 2.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 1.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 1.0), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.9), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.9), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.8), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.8), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.7), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.7), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.6), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.6), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.5), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.5), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.4), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.4), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.3), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.3), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.2), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.2), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.1), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.1), )), (
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].vertices.findAt(
    (2.71, 0.08, 0.0), ), 
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.0, 0.0, 0.0), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((2.0325, 0.06, 0.0), ), ((
    2.0325, 0.06, 0.1), ), ((2.0325, 0.06, 0.2), ), ((2.0325, 0.06, 0.3), ), ((
    2.0325, 0.06, 0.4), ), ((2.0325, 0.06, 0.5), ), ((2.0325, 0.06, 0.6), ), ((
    2.0325, 0.06, 0.7), ), ((2.0325, 0.06, 0.8), ), ((2.0325, 0.06, 0.9), ), ((
    2.0325, 0.06, 1.0), ), ((2.0325, 0.06, 1.1), ), ((2.0325, 0.06, 1.2), ), ((
    2.0325, 0.06, 1.3), ), ((2.0325, 0.06, 1.4), ), ((2.0325, 0.06, 1.5), ), ((
    2.0325, 0.06, 1.6), ), ((2.0325, 0.06, 1.7), ), ((2.0325, 0.06, 1.8), ), ((
    2.0325, 0.06, 1.9), ), ((2.0325, 0.06, 2.0), ), ((2.0325, 0.06, 2.1), ), ((
    2.0325, 0.06, 2.2), ), ((2.0325, 0.06, 2.3), ), ((2.0325, 0.06, 2.4), ), ((
    2.0325, 0.06, 2.5), ), ((2.0325, 0.06, 2.6), ), ((2.0325, 0.06, 2.7), ), ((
    2.0325, 0.06, 2.8), ), ((2.0325, 0.06, 2.9), ), ((2.0325, 0.06, 3.0), ), ((
    2.0325, 0.06, 3.1), ), ((2.0325, 0.06, 3.2), ), ((2.0325, 0.06, 3.3), ), ((
    2.0325, 0.06, 3.4), ), ((2.0325, 0.06, 3.5), ), ((2.0325, 0.06, 3.6), ), ), 
    name='Wire-3-Set-1')
## create connector section for locking system ##
mdb.models['Model-1'].ConnectorSection(name='Lock', translationalType=
    CARTESIAN)
mdb.models['Model-1'].sections['Lock'].setValues(behaviorOptions=(
    ConnectorElasticity(table=((1000000.0, ), ), independentComponents=(), 
    components=(2, )), ))
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-1-Set-1'], sectionName=
    'Lock')
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-2-Set-1'], sectionName=
    'Lock')
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-3-Set-1'], sectionName=
    'Lock')
## frame surface ##
mdb.models['Model-1'].rootAssembly.Surface(name='Frame_1_plate', side1Faces=
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'].faces.findAt(((
    1.806667, -0.0027, 0.05), ), ((0.903333, -0.0027, 0.1), ), ))
mdb.models['Model-1'].rootAssembly.Surface(name='Frame_2_plate', side1Faces=
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'].faces.findAt(((
    1.806667, -0.0027, 3.5), ), ((0.903333, -0.0027, 3.55), ), ))
### create partition inner-plate ###
mdb.models['Model-1'].ConstrainedSketch(gridSpacing=0.18, name='__profile__', 
    sheetSize=7.42, transform=
    mdb.models['Model-1'].parts['Inner_plate'].MakeSketchTransform(
    sketchPlane=mdb.models['Model-1'].parts['Inner_plate'].faces.findAt((0.6, 
    0.0, 2.4), (0.0, -1.0, 0.0)), sketchPlaneSide=SIDE1, 
    sketchUpEdge=mdb.models['Model-1'].parts['Inner_plate'].edges.findAt((
    0.675, 0.0, 3.6), ), sketchOrientation=RIGHT, origin=(0.45, 0.0, 1.8)))
mdb.models['Model-1'].parts['Inner_plate'].projectReferencesOntoSketch(filter=
    COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__profile__'])
mdb.models['Model-1'].sketches['__profile__'].Spot(point=(-1.75, 0.4))
mdb.models['Model-1'].sketches['__profile__'].Spot(point=(-1.75, -0.4))
mdb.models['Model-1'].sketches['__profile__'].Spot(point=(1.75, 0.4))
mdb.models['Model-1'].sketches['__profile__'].Spot(point=(1.75, -0.4))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-1.75, 0.4), 
    point2=(-1.8, 0.45))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(-1.75, -0.4), 
    point2=(-1.8, -0.45))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(1.75, -0.4), 
    point2=(1.8, -0.45))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(1.75, 0.4), 
    point2=(1.8, 0.45))
mdb.models['Model-1'].parts['Inner_plate'].PartitionFaceBySketch(faces=
    mdb.models['Model-1'].parts['Inner_plate'].faces.findAt(((0.6, 0.0, 2.4), 
    )), sketch=mdb.models['Model-1'].sketches['__profile__'], sketchUpEdge=
    mdb.models['Model-1'].parts['Inner_plate'].edges.findAt((0.675, 0.0, 3.6), 
    ))
del mdb.models['Model-1'].sketches['__profile__']
mdb.models['Model-1'].parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mdb.models['Model-1'].parts['Inner_plate'].faces.findAt(((0.583333, 0.0, 
    3.583333), )), point1=
    mdb.models['Model-1'].parts['Inner_plate'].vertices.findAt((0.05, 0.0, 
    3.55), ), point2=
    mdb.models['Model-1'].parts['Inner_plate'].vertices.findAt((0.85, 0.0, 
    3.55), ))
mdb.models['Model-1'].parts['Inner_plate'].PartitionFaceByShortestPath(faces=
    mdb.models['Model-1'].parts['Inner_plate'].faces.findAt(((0.016667, 0.0, 
    3.483333), )), point1=
    mdb.models['Model-1'].parts['Inner_plate'].vertices.findAt((0.05, 0.0, 
    0.05), ), point2=
    mdb.models['Model-1'].parts['Inner_plate'].vertices.findAt((0.85, 0.0, 
    0.05), ))
mdb.models['Model-1'].rootAssembly.regenerate()
mdb.models['Model-1'].parts['Inner_plate'].generateMesh()
### create Screws ###
mdb.models['Model-1'].rootAssembly.regenerate()
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.05, 0.0, 0.05), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'].vertices.findAt((
    0.0542, -0.0027, 0.075), )), (
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].vertices.findAt(
    (0.05, 0.0, 3.55), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'].vertices.findAt((
    0.0542, -0.0027, 3.525), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((0.05105, -0.000675, 
    3.54375), ), ((0.05105, -0.000675, 0.05625), ), ), name='Wire-4-Set-1')
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.955, 0.0, 0.05), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'].vertices.findAt((
    0.957172, -0.0027, 0.075), )), (
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].vertices.findAt(
    (0.955, 0.0, 3.55), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'].vertices.findAt((
    0.957172, -0.0027, 3.525), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((0.955543, -0.000675, 
    3.54375), ), ((0.955543, -0.000675, 0.05625), ), ), name='Wire-5-Set-1')
mdb.models['Model-1'].rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=OFF
    , points=((
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.86, 0.0, 0.05), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'].vertices.findAt((
    1.851114, -0.0027, 0.075), )), (
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].vertices.findAt(
    (1.86, 0.0, 3.55), ), 
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'].vertices.findAt((
    1.851114, -0.0027, 3.525), ))))
mdb.models['Model-1'].rootAssembly.Set(edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((1.857779, -0.000675, 
    3.54375), ), ((1.857779, -0.000675, 0.05625), ), ), name='Wire-6-Set-1')
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-4-Set-1'], sectionName=
    'Screws_plates')
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-5-Set-1'], sectionName=
    'Screws_plates')
mdb.models['Model-1'].rootAssembly.SectionAssignment(region=
    mdb.models['Model-1'].rootAssembly.sets['Wire-6-Set-1'], sectionName=
    'Screws_plates')
### Create all node set Nall ###
mdb.models['Model-1'].rootAssembly.regenerate()
mdb.models['Model-1'].rootAssembly.Set(name='Nall', nodes=
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].nodes[0:4069]+\
    mdb.models['Model-1'].rootAssembly.instances['Insulation-1'].nodes[0:14981]+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].nodes[0:1063]+\
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].nodes[0:4069]+\
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].nodes[0:4069]+\
    mdb.models['Model-1'].rootAssembly.instances['Insulation-2'].nodes[0:14981]+\
    mdb.models['Model-1'].rootAssembly.instances['Insulation-3'].nodes[0:14981]+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].nodes[0:1063]+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].nodes[0:1063]+\
    mdb.models['Model-1'].rootAssembly.instances['Frame-1'].nodes[0:710]+\
    mdb.models['Model-1'].rootAssembly.instances['Frame-2'].nodes[0:710]+\
    mdb.models['Model-1'].rootAssembly.instances['HEA_incl_connection-1'].nodes[0:2125]+\
    mdb.models['Model-1'].rootAssembly.instances['HEA_incl_connection-2'].nodes[0:2125])
### create sets failure check ###
mdb.models['Model-1'].parts['Inner_plate'].Set(name='ALL_NODES_INNER', nodes=
    mdb.models['Model-1'].parts['Inner_plate'].nodes[0:4069])	
mod.parts['Outer_plate'].Set(name='TOP_NODE', nodes=
    mod.parts['Outer_plate'].nodes[189:190])
mod.parts['Outer_plate'].Set(name='BOTTOM_NODE', nodes=
    mod.parts['Outer_plate'].nodes[180:181])
### Sets for deactivating panels ###
mdb.models['Model-1'].rootAssembly.Set(cells=
    mdb.models['Model-1'].rootAssembly.instances['Insulation-1'].cells.findAt((
    (0.9, 0.053783, 2.4), )), edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((0.05105, -0.000675, 
    3.54375), ), ((0.05105, -0.000675, 0.05625), ), ((2.0325, 0.06, 0.0), ), ((
    2.0325, 0.06, 0.1), ), ((2.0325, 0.06, 0.2), ), ((2.0325, 0.06, 0.3), ), ((
    2.0325, 0.06, 0.4), ), ((2.0325, 0.06, 0.5), ), ((2.0325, 0.06, 0.6), ), ((
    2.0325, 0.06, 0.7), ), ((2.0325, 0.06, 0.8), ), ((2.0325, 0.06, 0.9), ), ((
    2.0325, 0.06, 1.0), ), ((2.0325, 0.06, 1.1), ), ((2.0325, 0.06, 1.2), ), ((
    2.0325, 0.06, 1.3), ), ((2.0325, 0.06, 1.4), ), ((2.0325, 0.06, 1.5), ), ((
    2.0325, 0.06, 1.6), ), ((2.0325, 0.06, 1.7), ), ((2.0325, 0.06, 1.8), ), ((
    2.0325, 0.06, 1.9), ), ((2.0325, 0.06, 2.0), ), ((2.0325, 0.06, 2.1), ), ((
    2.0325, 0.06, 2.2), ), ((2.0325, 0.06, 2.3), ), ((2.0325, 0.06, 2.4), ), ((
    2.0325, 0.06, 2.5), ), ((2.0325, 0.06, 2.6), ), ((2.0325, 0.06, 2.7), ), ((
    2.0325, 0.06, 2.8), ), ((2.0325, 0.06, 2.9), ), ((2.0325, 0.06, 3.0), ), ((
    2.0325, 0.06, 3.1), ), ((2.0325, 0.06, 3.2), ), ((2.0325, 0.06, 3.3), ), ((
    2.0325, 0.06, 3.4), ), ((2.0325, 0.06, 3.5), ), ((2.0325, 0.06, 3.6), ), ((
    0.90125, 0.060338, 0.0), ), ((0.90125, 0.060338, 0.1), ), ((0.90125, 
    0.060338, 0.2), ), ((0.90125, 0.060338, 0.3), ), ((0.90125, 0.060338, 0.4), 
    ), ((0.90125, 0.060338, 0.5), ), ((0.90125, 0.060338, 0.6), ), ((0.90125, 
    0.060338, 0.7), ), ((0.90125, 0.060338, 0.8), ), ((0.90125, 0.060338, 0.9), 
    ), ((0.90125, 0.060338, 1.0), ), ((0.90125, 0.060338, 1.1), ), ((0.90125, 
    0.060338, 1.2), ), ((0.90125, 0.060338, 1.3), ), ((0.90125, 0.060338, 1.4), 
    ), ((0.90125, 0.060338, 1.5), ), ((0.90125, 0.060338, 1.6), ), ((0.90125, 
    0.060338, 1.7), ), ((0.90125, 0.060338, 1.8), ), ((0.90125, 0.060338, 1.9), 
    ), ((0.90125, 0.060338, 2.0), ), ((0.90125, 0.060338, 2.1), ), ((0.90125, 
    0.060338, 2.2), ), ((0.90125, 0.060338, 2.3), ), ((0.90125, 0.060338, 2.4), 
    ), ((0.90125, 0.060338, 2.5), ), ((0.90125, 0.060338, 2.6), ), ((0.90125, 
    0.060338, 2.7), ), ((0.90125, 0.060338, 2.8), ), ((0.90125, 0.060338, 2.9), 
    ), ((0.90125, 0.060338, 3.0), ), ((0.90125, 0.060338, 3.1), ), ((0.90125, 
    0.060338, 3.2), ), ((0.90125, 0.060338, 3.3), ), ((0.90125, 0.060338, 3.4), 
    ), ((0.90125, 0.060338, 3.5), ), ((0.90125, 0.060338, 3.6), ), ), faces=
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-1'].faces.findAt(
    ((0.283333, 0.0, 0.316667), (0.0, -1.0, 0.0)), ((0.316667, 0.0, 3.566667), 
    (0.0, -1.0, 0.0)), ((0.866667, 0.0, 0.016667), (0.0, -1.0, 0.0)), ((
    0.033333, 0.0, 0.033333), (0.0, -1.0, 0.0)), ((0.033333, 0.0, 3.583333), (
    0.0, -1.0, 0.0)), ((0.866667, 0.0, 3.566667), (0.0, -1.0, 0.0)), ((
    0.583333, 0.0, 0.033333), (0.0, -1.0, 0.0)), )+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-1'].faces.findAt(
    ((0.6, 0.08045, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-1') 
mdb.models['Model-1'].rootAssembly.Set(cells=
    mdb.models['Model-1'].rootAssembly.instances['Insulation-2'].cells.findAt((
    (1.805, 0.053783, 2.4), )), edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((0.955543, -0.000675, 
    3.54375), ), ((0.955543, -0.000675, 0.05625), ), ((1.80625, 0.06, 0.0), ), 
    ((1.80625, 0.06, 0.1), ), ((1.80625, 0.06, 0.2), ), ((1.80625, 0.06, 0.3), 
    ), ((1.80625, 0.06, 0.4), ), ((1.80625, 0.06, 0.5), ), ((1.80625, 0.06, 
    0.6), ), ((1.80625, 0.06, 0.7), ), ((1.80625, 0.06, 0.8), ), ((1.80625, 
    0.06, 0.9), ), ((1.80625, 0.06, 1.0), ), ((1.80625, 0.06, 1.1), ), ((
    1.80625, 0.06, 1.2), ), ((1.80625, 0.06, 1.3), ), ((1.80625, 0.06, 1.4), ), 
    ((1.80625, 0.06, 1.5), ), ((1.80625, 0.06, 1.6), ), ((1.80625, 0.06, 1.7), 
    ), ((1.80625, 0.06, 1.8), ), ((1.80625, 0.06, 1.9), ), ((1.80625, 0.06, 
    2.0), ), ((1.80625, 0.06, 2.1), ), ((1.80625, 0.06, 2.2), ), ((1.80625, 
    0.06, 2.3), ), ((1.80625, 0.06, 2.4), ), ((1.80625, 0.06, 2.5), ), ((
    1.80625, 0.06, 2.6), ), ((1.80625, 0.06, 2.7), ), ((1.80625, 0.06, 2.8), ), 
    ((1.80625, 0.06, 2.9), ), ((1.80625, 0.06, 3.0), ), ((1.80625, 0.06, 3.1), 
    ), ((1.80625, 0.06, 3.2), ), ((1.80625, 0.06, 3.3), ), ((1.80625, 0.06, 
    3.4), ), ((1.80625, 0.06, 3.5), ), ((1.80625, 0.06, 3.6), ), ((0.90125, 
    0.060338, 0.0), ), ((0.90125, 0.060338, 0.1), ), ((0.90125, 0.060338, 0.2), 
    ), ((0.90125, 0.060338, 0.3), ), ((0.90125, 0.060338, 0.4), ), ((0.90125, 
    0.060338, 0.5), ), ((0.90125, 0.060338, 0.6), ), ((0.90125, 0.060338, 0.7), 
    ), ((0.90125, 0.060338, 0.8), ), ((0.90125, 0.060338, 0.9), ), ((0.90125, 
    0.060338, 1.0), ), ((0.90125, 0.060338, 1.1), ), ((0.90125, 0.060338, 1.2), 
    ), ((0.90125, 0.060338, 1.3), ), ((0.90125, 0.060338, 1.4), ), ((0.90125, 
    0.060338, 1.5), ), ((0.90125, 0.060338, 1.6), ), ((0.90125, 0.060338, 1.7), 
    ), ((0.90125, 0.060338, 1.8), ), ((0.90125, 0.060338, 1.9), ), ((0.90125, 
    0.060338, 2.0), ), ((0.90125, 0.060338, 2.1), ), ((0.90125, 0.060338, 2.2), 
    ), ((0.90125, 0.060338, 2.3), ), ((0.90125, 0.060338, 2.4), ), ((0.90125, 
    0.060338, 2.5), ), ((0.90125, 0.060338, 2.6), ), ((0.90125, 0.060338, 2.7), 
    ), ((0.90125, 0.060338, 2.8), ), ((0.90125, 0.060338, 2.9), ), ((0.90125, 
    0.060338, 3.0), ), ((0.90125, 0.060338, 3.1), ), ((0.90125, 0.060338, 3.2), 
    ), ((0.90125, 0.060338, 3.3), ), ((0.90125, 0.060338, 3.4), ), ((0.90125, 
    0.060338, 3.5), ), ((0.90125, 0.060338, 3.6), ), ), faces=
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-2'].faces.findAt(
    ((1.188333, 0.0, 0.316667), (0.0, -1.0, 0.0)), ((1.221667, 0.0, 3.566667), 
    (0.0, -1.0, 0.0)), ((1.771667, 0.0, 0.016667), (0.0, -1.0, 0.0)), ((
    0.938333, 0.0, 0.033333), (0.0, -1.0, 0.0)), ((0.938333, 0.0, 3.583333), (
    0.0, -1.0, 0.0)), ((1.771667, 0.0, 3.566667), (0.0, -1.0, 0.0)), ((
    1.488333, 0.0, 0.033333), (0.0, -1.0, 0.0)), )+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-2'].faces.findAt(
    ((1.505, 0.08, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-2')
mdb.models['Model-1'].rootAssembly.Set(cells=
    mdb.models['Model-1'].rootAssembly.instances['Insulation-3'].cells.findAt((
    (2.71, 0.053783, 2.4), )), edges=
    mdb.models['Model-1'].rootAssembly.edges.findAt(((1.857779, -0.000675, 
    3.54375), ), ((1.857779, -0.000675, 0.05625), ), ((2.0325, 0.06, 0.0), ), (
    (2.0325, 0.06, 0.1), ), ((2.0325, 0.06, 0.2), ), ((2.0325, 0.06, 0.3), ), (
    (2.0325, 0.06, 0.4), ), ((2.0325, 0.06, 0.5), ), ((2.0325, 0.06, 0.6), ), (
    (2.0325, 0.06, 0.7), ), ((2.0325, 0.06, 0.8), ), ((2.0325, 0.06, 0.9), ), (
    (2.0325, 0.06, 1.0), ), ((2.0325, 0.06, 1.1), ), ((2.0325, 0.06, 1.2), ), (
    (2.0325, 0.06, 1.3), ), ((2.0325, 0.06, 1.4), ), ((2.0325, 0.06, 1.5), ), (
    (2.0325, 0.06, 1.6), ), ((2.0325, 0.06, 1.7), ), ((2.0325, 0.06, 1.8), ), (
    (2.0325, 0.06, 1.9), ), ((2.0325, 0.06, 2.0), ), ((2.0325, 0.06, 2.1), ), (
    (2.0325, 0.06, 2.2), ), ((2.0325, 0.06, 2.3), ), ((2.0325, 0.06, 2.4), ), (
    (2.0325, 0.06, 2.5), ), ((2.0325, 0.06, 2.6), ), ((2.0325, 0.06, 2.7), ), (
    (2.0325, 0.06, 2.8), ), ((2.0325, 0.06, 2.9), ), ((2.0325, 0.06, 3.0), ), (
    (2.0325, 0.06, 3.1), ), ((2.0325, 0.06, 3.2), ), ((2.0325, 0.06, 3.3), ), (
    (2.0325, 0.06, 3.4), ), ((2.0325, 0.06, 3.5), ), ((2.0325, 0.06, 3.6), ), (
    (1.80625, 0.06, 0.0), ), ((1.80625, 0.06, 0.1), ), ((1.80625, 0.06, 0.2), 
    ), ((1.80625, 0.06, 0.3), ), ((1.80625, 0.06, 0.4), ), ((1.80625, 0.06, 
    0.5), ), ((1.80625, 0.06, 0.6), ), ((1.80625, 0.06, 0.7), ), ((1.80625, 
    0.06, 0.8), ), ((1.80625, 0.06, 0.9), ), ((1.80625, 0.06, 1.0), ), ((
    1.80625, 0.06, 1.1), ), ((1.80625, 0.06, 1.2), ), ((1.80625, 0.06, 1.3), ), 
    ((1.80625, 0.06, 1.4), ), ((1.80625, 0.06, 1.5), ), ((1.80625, 0.06, 1.6), 
    ), ((1.80625, 0.06, 1.7), ), ((1.80625, 0.06, 1.8), ), ((1.80625, 0.06, 
    1.9), ), ((1.80625, 0.06, 2.0), ), ((1.80625, 0.06, 2.1), ), ((1.80625, 
    0.06, 2.2), ), ((1.80625, 0.06, 2.3), ), ((1.80625, 0.06, 2.4), ), ((
    1.80625, 0.06, 2.5), ), ((1.80625, 0.06, 2.6), ), ((1.80625, 0.06, 2.7), ), 
    ((1.80625, 0.06, 2.8), ), ((1.80625, 0.06, 2.9), ), ((1.80625, 0.06, 3.0), 
    ), ((1.80625, 0.06, 3.1), ), ((1.80625, 0.06, 3.2), ), ((1.80625, 0.06, 
    3.3), ), ((1.80625, 0.06, 3.4), ), ((1.80625, 0.06, 3.5), ), ((1.80625, 
    0.06, 3.6), ), ), faces=
    mdb.models['Model-1'].rootAssembly.instances['Inner_plate-3'].faces.findAt(
    ((2.093333, 0.0, 0.316667), (0.0, -1.0, 0.0)), ((2.126667, 0.0, 3.566667), 
    (0.0, -1.0, 0.0)), ((2.676667, 0.0, 0.016667), (0.0, -1.0, 0.0)), ((
    1.843333, 0.0, 0.033333), (0.0, -1.0, 0.0)), ((1.843333, 0.0, 3.583333), (
    0.0, -1.0, 0.0)), ((2.676667, 0.0, 3.566667), (0.0, -1.0, 0.0)), ((
    2.393333, 0.0, 0.033333), (0.0, -1.0, 0.0)), )+\
    mdb.models['Model-1'].rootAssembly.instances['Outer_plate-3'].faces.findAt(
    ((2.41, 0.08, 2.4), (0.0, -1.0, 0.0)), ), name='Panel-3')
# ### Initial conditions ###
# modKey = mod.keywordBlock
# modKey.synchVersions(storeNodesAndElements=False)
# modKey.insert(361,'\n*INITIAL CONDITIONS, TYPE=TEMPERATURE\nNall, 20\n\n*Imperfection, file=i0_buc-Job, step=1\n1, 0.003')
### REGENERATE ASSEMBLY ###
modRa.regenerate()
########################## End of HT_basicModel ###########################
################### Additional Lines Added by upGeomHT ####################